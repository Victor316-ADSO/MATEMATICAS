<?php
include 'api/api.php';
require_once 'config/urls.php';

// Iniciar sesión al principio del script
    session_start();

// Verificar si se recibió un ID de cuestionario
if (!isset($_GET['id'])) {
    header("Location: " . getUrlDashboard());
    exit();
}

    $id_cuestionario = $_GET['id'];

// Si hay un error en la URL, mostrarlo
if (isset($_GET['error'])) {
    $error = $_SESSION['error_mensaje'] ?? "Error desconocido";
    unset($_SESSION['error_mensaje']);
}

// Redirigir a la vista React
header("Location: " . getUrlLinksystem($id_cuestionario));
        exit();