<?php
include './api/api.php';
require_once './model/conection.php';
verificar_sesion();

$database = new Database();
$db = $database->connect();

// Procesar formulario de creación/edición de periodo
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Obtener y sanitizar datos del formulario
        $nombre = sanitize_input($_POST['nombre']);
        $fecha_inicio = sanitize_input($_POST['fecha_inicio']);
        $fecha_fin = sanitize_input($_POST['fecha_fin']);

        if ($_POST['action'] === 'create') {
            // Crear nuevo periodo
            $query = "INSERT INTO periodo (nombre, fecha_inicio, fecha_fin) VALUES (:nombre, :fecha_inicio, :fecha_fin)";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':fecha_inicio', $fecha_inicio);
            $stmt->bindParam(':fecha_fin', $fecha_fin);
            
            if ($stmt->execute()) {
                $mensaje = "Periodo creado correctamente.";
                $tipo_mensaje = "success";
            } else {
                $mensaje = "Error al crear el periodo.";
                $tipo_mensaje = "danger";
            }
        } elseif ($_POST['action'] === 'edit' && isset($_POST['id'])) {
            // Editar periodo existente
            $id = sanitize_input($_POST['id']);
            $query = "UPDATE periodo SET nombre = :nombre, fecha_inicio = :fecha_inicio, fecha_fin = :fecha_fin WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':fecha_inicio', $fecha_inicio);
            $stmt->bindParam(':fecha_fin', $fecha_fin);
            $stmt->bindParam(':id', $id);
            
            if ($stmt->execute()) {
                $mensaje = "Periodo actualizado correctamente.";
                $tipo_mensaje = "success";
            } else {
                $mensaje = "Error al actualizar el periodo.";
                $tipo_mensaje = "danger";
            }
        }
    } elseif (isset($_POST['delete']) && isset($_POST['id'])) {
        // Eliminar periodo
        $id = sanitize_input($_POST['id']);
        
        // Verificar si el periodo está siendo utilizado en aperturas
        $check_query = "SELECT COUNT(*) as count FROM apertura WHERE id_periodo = :id";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->bindParam(':id', $id);
        $check_stmt->execute();
        $result = $check_stmt->fetch();
        
        if ($result['count'] > 0) {
            $mensaje = "No se puede eliminar el periodo porque está siendo utilizado en aperturas de cuestionarios.";
            $tipo_mensaje = "warning";
        } else {
            $query = "DELETE FROM periodo WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':id', $id);
            
            if ($stmt->execute()) {
                $mensaje = "Periodo eliminado correctamente.";
                $tipo_mensaje = "success";
            } else {
                $mensaje = "Error al eliminar el periodo.";
                $tipo_mensaje = "danger";
            }
        }
    }
}

// Obtener todos los periodos
$query = "SELECT * FROM periodo ORDER BY fecha_inicio DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$periodos = $stmt->fetchAll();

// Obtener periodo para editar si se ha solicitado
$periodo_editar = null;
if (isset($_GET['edit']) && !empty($_GET['edit'])) {
    $id = sanitize_input($_GET['edit']);
    $query = "SELECT * FROM periodo WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $periodo_editar = $stmt->fetch();
}