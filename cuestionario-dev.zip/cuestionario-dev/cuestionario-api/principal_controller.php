<?php
// Evitar cualquier output antes del JSON
error_reporting(E_ALL);
ini_set('display_errors', 0); // No mostrar errores en pantalla
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Capturar cualquier output no deseado
ob_start();

header('Content-Type: application/json');

// Configuración de CORS
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

session_start();

include_once 'model/conection.php';

// Obtener los datos JSON del cuerpo de la petición
$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

try {
    if (!isset($_SESSION['usuario_id'])) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'error' => 'No hay sesión activa'
        ]);
        exit();
    }

    $usuario_id = $_SESSION['usuario_id'];
    
    // También obtener del JSON si está disponible (para compatibilidad)
    if (!$usuario_id && isset($data['usuario_id'])) {
        $usuario_id = $data['usuario_id'];
    }

    // Crear conexión a la base de datos
    $pdo = Conection::conectar();

    if (!$pdo) {
        throw new Exception('Error de conexión a la base de datos');
    }

    // Obtener mis cuestionarios (usando la estructura real de la DB)
    $sql_mis = "
        SELECT DISTINCT rcp.id, c.titulo, c.descripcion, 'creado' as estado,
               COALESCE(respuestas.total_respuestas, 0) as respuestas
        FROM cuestionario c
        INNER JOIN relacion_cuestionario_programa rcp ON c.id = rcp.id_cuestionario
        LEFT JOIN (
            SELECT id_cuestionario, COUNT(*) as total_respuestas
            FROM respuesta_estudiante
            GROUP BY id_cuestionario
        ) respuestas ON c.id = respuestas.id_cuestionario
        LEFT JOIN apertura a ON rcp.id = a.id_relacion_cuestionario_programa
        WHERE rcp.id_docente = ? AND rcp.activo = 1 AND a.id IS NULL
        ORDER BY rcp.id DESC
        LIMIT 5
    ";

    $stmt_mis = $pdo->prepare($sql_mis);
    $stmt_mis->execute([$usuario_id]);
    $mis_cuestionarios = $stmt_mis->fetchAll(PDO::FETCH_ASSOC);

    // Obtener cuestionarios abiertos del profesor logueado
    $sql_abiertos = "
        SELECT DISTINCT c.id, c.titulo, c.descripcion, 'abierto' as estado,
               p.nombre as periodo_nombre, p.fecha_inicio, p.fecha_fin,
               d.nombre as creador_nombre, prog.nombre as programa_nombre,
               a.id as apertura_id, c.id as cuestionario_id
        FROM cuestionario c
        INNER JOIN relacion_cuestionario_programa rcp ON c.id = rcp.id_cuestionario
        INNER JOIN apertura a ON rcp.id = a.id_relacion_cuestionario_programa
        INNER JOIN periodo p ON a.id_periodo = p.id
        INNER JOIN docente d ON rcp.id_docente = d.id
        INNER JOIN programa prog ON rcp.id_programa = prog.id
        WHERE rcp.id_docente = ? AND rcp.activo = 1
        AND (p.fecha_inicio IS NULL OR p.fecha_inicio <= NOW())
        AND (p.fecha_fin IS NULL OR p.fecha_fin >= NOW())
        ORDER BY c.id DESC
        LIMIT 5
    ";

    $stmt_abiertos = $pdo->prepare($sql_abiertos);
    $stmt_abiertos->execute([$usuario_id]);
    $cuestionarios_abiertos = $stmt_abiertos->fetchAll(PDO::FETCH_ASSOC);

    // Limpiar cualquier output buffer antes de enviar JSON
    ob_clean();
    


    // Respuesta exitosa
    $response = [
        'success' => true,
        'mis_cuestionarios' => $mis_cuestionarios,
        'cuestionarios_abiertos' => $cuestionarios_abiertos,
        'misCuestionarios' => $mis_cuestionarios, // Para compatibilidad
        'cuestionariosAbiertos' => $cuestionarios_abiertos // Para compatibilidad
    ];
    
    echo json_encode($response);

} catch (Exception $e) {
    // Limpiar cualquier output buffer antes de enviar JSON
    ob_clean();
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error del servidor: ' . $e->getMessage()
    ]);
}

// Terminar el output buffer
ob_end_flush();
?>