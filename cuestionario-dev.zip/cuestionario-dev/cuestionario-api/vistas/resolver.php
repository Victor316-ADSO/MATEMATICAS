<?php
include '../../src/Controllers/resolver_controller.php';

// Depuración temporal
//     if (!empty($preguntas)) {
//         foreach ($preguntas as $pregunta) {
//             if (!empty($pregunta['opciones'])) {
//                 echo '<pre>';
//                 var_dump($pregunta['opciones'][0]);
//                 echo '</pre>';
//                 break;
//             }
//         }
//     }
// 
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resolver Cuestionario</title>
    <link rel="icon" type="image/png" href="../../Resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="../../Resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="../../Resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="../../Resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="../../site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .pregunta-imagen {
            max-width: 100%;
            max-height: 300px;
            margin: 10px 0;
            border-radius: 5px;
        }

        .opcion-imagen {
            max-width: 150px;
            max-height: 150px;
            margin: 5px 0;
            border-radius: 5px;
        }
    </style>
</head>

<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a href="principal.php" class="navbar-brand">
                <i class="fas fa-arrow-left"></i> Volver al Dashboard
            </a>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h3><i class="fas fa-clipboard-question"></i> <?php echo htmlspecialchars($cuestionario['titulo']); ?></h3>
                    </div>
                    <div class="card-body">
                        <p class="lead"><?php echo htmlspecialchars($cuestionario['descripcion']); ?></p>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <strong>Creado por:</strong> <?php echo htmlspecialchars($cuestionario['creador_nombre']); ?>
                            </div>
                            <div class="col-md-6">
                                <strong>Programa:</strong> <?php echo htmlspecialchars($cuestionario['programa_nombre']); ?> -
                                <?php echo htmlspecialchars($cuestionario['nivel_nombre']); ?>
                            </div>
                        </div>

                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <div class="mb-3">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i>
                                <strong>Instrucciones:</strong> Selecciona una respuesta para cada pregunta y presiona "Enviar Respuestas" al finalizar.
                                <p class="mb-0 mt-2">Total de preguntas: <?php echo count($preguntas); ?></p>
                            </div>
                        </div>

                        <form method="POST" id="cuestionarioForm">
                            <?php $pregunta_num = 1; ?>
                            <?php foreach ($preguntas as $pregunta_id => $pregunta): ?>
                                <div class="card mb-4">
                                    <div class="card-header d-flex justify-content-between align-items-center">
                                        <h6 class="mb-0">Pregunta <?php echo $pregunta_num; ?></h6>
                                        <span class="badge bg-info">Valor: <?php echo $pregunta['peso_pregunta']; ?> puntos</span>
                                    </div>
                                    <div class="card-body">
                                        <p><strong><?php echo htmlspecialchars($pregunta['texto_pregunta']); ?></strong></p>

                                        <?php if (!empty($pregunta['imagen_pregunta'])): ?>
                                            <div class="text-center">
                                                <img src="data:image/jpeg;base64,<?php echo base64_encode($pregunta['imagen_pregunta']); ?>"
                                                    alt="Imagen de la pregunta" class="pregunta-imagen">
                                            </div>
                                        <?php endif; ?>

                                        <?php foreach ($pregunta['opciones'] as $opcion): ?>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input" type="radio"
                                                    name="respuestas[<?php echo $pregunta_id; ?>]"
                                                    value="<?php echo $opcion['id']; ?>"
                                                    id="opcion_<?php echo $opcion['id']; ?>" required>
                                                <label class="form-check-label" for="opcion_<?php echo $opcion['id']; ?>">
                                                    <?php echo htmlspecialchars($opcion['texto_opcion']); ?>
                                                </label>

                                                <?php if (!empty($opcion['imagen_opcion'])): ?>
                                                    <div class="mt-1">
                                                        <img src="data:image/jpeg;base64,<?php echo base64_encode($opcion['imagen_opcion']); ?>"
                                                            alt="Imagen de la opción" class="opcion-imagen">
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php $pregunta_num++; ?>
                            <?php endforeach; ?>

                            <div class="mt-4 text-center">
                                <button type="submit" class="btn btn-success btn-lg" onclick="return confirmarEnvio()">
                                    <i class="fas fa-paper-plane"></i> Enviar Respuestas
                                </button>
                                <button type="button" class="btn btn-secondary btn-lg" data-bs-toggle="modal" data-bs-target="#modalCancelar">Cancelar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Confirmación para Cancelar -->
    <div class="modal fade" id="modalCancelar" tabindex="-1" aria-labelledby="modalCancelarLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title" id="modalCancelarLabel"><i class="fas fa-exclamation-triangle"></i> Confirmar Cancelación</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>¿Estás seguro de que deseas cancelar este cuestionario?</p>
                    <p>Se cerrará el cuestionario y tendras que volver a dar click en el link del correo para poder volver a resolverlo.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, continuar</button>
                    <button type="button" class="btn btn-danger" onclick="cancelarCuestionario()">Sí, cancelar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function confirmarEnvio() {
            const form = document.getElementById('cuestionarioForm');
            const preguntas = form.querySelectorAll('input[type="radio"]');
            const preguntasRespondidas = new Set();

            preguntas.forEach(input => {
                if (input.checked) {
                    preguntasRespondidas.add(input.name);
                }
            });

            const totalPreguntas = <?php echo count($preguntas); ?>;

            if (preguntasRespondidas.size < totalPreguntas) {
                alert('Por favor responde todas las preguntas antes de enviar.');
                return false;
            }

            return confirm('¿Estás seguro de que quieres enviar tus respuestas? No podrás cambiarlas después.');
        }

        function cancelarCuestionario() {
            // Crear un formulario para enviar la solicitud de cierre de sesión
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '../../src/Controllers/logoutEstudiantes_controller.php';

            // Agregar un campo oculto para indicar la redirección
            const redirectInput = document.createElement('input');
            redirectInput.type = 'hidden';
            redirectInput.name = 'redirect';
            redirectInput.value = 'https://www.uninunez.edu.co/estudiantes.html';
            form.appendChild(redirectInput);

            // Agregar el formulario al documento y enviarlo
            document.body.appendChild(form);
            form.submit();
        }
    </script>
</body>

</html>