<?php
include './controller/estudiante_controller.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Estudiantes</title>
    <link rel="icon" type="image/png" href="./resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="./resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="./resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="./resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="/site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="principal.php">Sistema de Cuestionarios</a>
            <div class="navbar-nav">
                <span class="nav-text text-white me-3">Bienvenido, <?php echo $_SESSION['usuario_nombre']; ?></span>
                <a href="../logout_controller.php" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row mb-4">
            <div class="col-md-6">
                <h2>Gestión de Estudiantes</h2>
            </div>
            <div class="col-md-6 text-end">
                <a href="asignacionManage.php" class="btn btn-primary">
                    <i class="fas fa-clipboard-list"></i> Asignaciones
                </a>
                <a href="principal.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Volver
                </a>
            </div>
        </div>

        <?php if (isset($mensaje)): ?>
            <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show" role="alert">
                <?php echo $mensaje; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <!-- Formulario para agregar estudiante -->
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5><i class="fas fa-user-plus"></i> Agregar Estudiante</h5>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="mb-3">
                                <label for="nombre" class="form-label">Nombre completo:</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="identificacion" class="form-label">Identificación:</label>
                                <input type="text" class="form-control" id="identificacion" name="identificacion" required>
                            </div>
                            <div class="mb-3">
                                <label for="programa_id" class="form-label">Programa:</label>
                                <select class="form-select" id="programa_id" name="programa_id" required>
                                    <option value="">-- Seleccione un programa --</option>
                                    <?php foreach ($programas as $programa): ?>
                                        <option value="<?php echo $programa['id']; ?>"><?php echo htmlspecialchars($programa['nombre']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <button type="submit" name="agregar_estudiante" class="btn btn-success w-100">
                                <i class="fas fa-save"></i> Guardar Estudiante
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Importar estudiantes -->
                <div class="card mt-4">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-file-import"></i> Importar Estudiantes</h5>
                    </div>
                    <div class="card-body">
                        <form action="asignacionManage.php" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="archivo_estudiantes" class="form-label">Archivo CSV:</label>
                                <input type="file" class="form-control" id="archivo_estudiantes" name="archivo_estudiantes" accept=".csv" required>
                                <div class="form-text">Formato: nombre,email,identificacion,id_programa</div>
                            </div>
                            <button type="submit" name="importar_estudiantes" class="btn btn-info w-100">
                                <i class="fas fa-upload"></i> Importar CSV
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Lista de estudiantes -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5><i class="fas fa-users"></i> Estudiantes Registrados</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($estudiantes)): ?>
                            <div class="alert alert-warning">
                                <p class="mb-0">No hay estudiantes registrados en el sistema.</p>
                            </div>
                        <?php else: ?>
                            <div class="mb-3">
                                <input type="text" id="buscar_estudiante" class="form-control" placeholder="Buscar estudiantes...">
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <!-- <th>ID</th> -->
                                            <th>Nombre</th>
                                            <th>Email</th>
                                            <th>Identificación</th>
                                            <th>Programa</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($estudiantes as $estudiante): ?>
                                            <tr class="estudiante-fila">
                                                <!-- <td><?php //echo $estudiante['id']; ?></td> -->
                                                <td><?php echo htmlspecialchars($estudiante['nombre']); ?></td>
                                                <td><?php echo htmlspecialchars($estudiante['email']); ?></td>
                                                <td><?php echo htmlspecialchars($estudiante['identificacion']); ?></td>
                                                <td><?php echo htmlspecialchars($estudiante['programa_nombre']); ?></td>
                                                <td>
                                                    <button class="btn btn-sm btn-danger eliminar-estudiante" data-id="<?php echo $estudiante['id']; ?>">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Buscar estudiantes
            const buscarInput = document.getElementById('buscar_estudiante');
            if (buscarInput) {
                buscarInput.addEventListener('input', function() {
                    const filtro = this.value.toLowerCase();
                    const filas = document.querySelectorAll('.estudiante-fila');
                    
                    filas.forEach(fila => {
                        const texto = fila.textContent.toLowerCase();
                        if (texto.includes(filtro)) {
                            fila.style.display = '';
                        } else {
                            fila.style.display = 'none';
                        }
                    });
                });
            }
            
            // Eliminar estudiante
            const botonesEliminar = document.querySelectorAll('.eliminar-estudiante');
            botonesEliminar.forEach(boton => {
                boton.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    if (confirm('¿Está seguro de eliminar este estudiante? Esta acción no se puede deshacer.')) {
                        window.location.href = `estudiantes.php?eliminar=${id}`;
                    }
                });
            });
        });
    </script>
</body>
</html> 