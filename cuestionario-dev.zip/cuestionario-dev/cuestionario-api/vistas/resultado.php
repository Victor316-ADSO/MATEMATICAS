<?php
include '../../src/Controllers/resultado_controller.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado del Cuestionario</title>
    <link rel="icon" type="image/png" href="../../Resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="../../Resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="../../Resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="../../Resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="../../site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Estilos para impresión */
        @media print {
            .no-print {
                display: none !important;
            }

            body {
                background-color: white !important;
            }

            .card {
                border: 1px solid #ddd !important;
                box-shadow: none !important;
                break-inside: avoid;
            }

            .container {
                width: 100% !important;
                max-width: 100% !important;
                padding: 0 !important;
                margin: 0 !important;
            }

            .bg-primary {
                background-color: #0d6efd !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .bg-success {
                background-color: #198754 !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .bg-warning {
                background-color: #ffc107 !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .bg-danger {
                background-color: #dc3545 !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .bg-info {
                background-color: #0dcaf0 !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .bg-secondary {
                background-color: #6c757d !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .text-white {
                color: white !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .alert {
                border: 1px solid #ddd !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            /* Añadir un encabezado para la versión impresa */
            .print-header {
                display: block !important;
                text-align: center;
                margin-bottom: 20px;
            }
        }

        /* Ocultar encabezado de impresión en la vista normal */
        .print-header {
            display: none;
        }

        /* Estilos para imágenes */
        .pregunta-imagen {
            max-width: 100%;
            max-height: 300px;
            margin: 10px 0;
            border-radius: 5px;
        }

        .opcion-imagen {
            max-width: 150px;
            max-height: 150px;
            margin: 5px 0;
            border-radius: 5px;
        }
    </style>
</head>

<body class="bg-light">
    <!-- Encabezado para versión impresa -->
    <div class="print-header">
        <img src="../../Resource/favicon/favicon-96x96.png" alt="Logo" style="height: 50px;">
        <h2>Sistema de Cuestionarios - Resultados</h2>
        <p>Fecha de impresión: <?php echo date('d/m/Y H:i'); ?></p>
    </div>

    <nav class="navbar navbar-dark bg-primary no-print">
        <div class="container">
            <a href="src/Controllers/logout_controller.php" class="btn btn-outline-light">
                <i class="fas fa-arrow-left"></i> Salir
            </a>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <!-- Resultado General -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white text-center">
                        <h3><i class="fas fa-trophy"></i> Resultado del Cuestionario</h3>
                        <h4><?php echo htmlspecialchars($resultado['titulo']); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <strong>Resuelto por:</strong> <?php echo $_SESSION['usuario_nombre']; ?> <br>
                                <strong>Programa:</strong> <?php echo htmlspecialchars($resultado['programa_nombre']); ?> -
                                <?php echo htmlspecialchars($resultado['nivel_nombre']); ?>
                            </div>
                            <div class="col-md-6">
                                <strong>Creado por:</strong> Docente <?php echo htmlspecialchars($resultado['creador_nombre']); ?>
                            </div>
                        </div>

                        <div class="row text-center">
                            <div class="col-md-3">
                                <div class="card bg-primary text-white">
                                    <div class="card-body">
                                        <h5>Puntaje</h5>
                                        <h2><?php echo number_format($resultado['puntaje_obtenido'], 2); ?>/<?php echo number_format($resultado['puntaje_total'], 2); ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-<?php echo $resultado['porcentaje'] >= 70 ? 'success' : ($resultado['porcentaje'] >= 50 ? 'warning' : 'danger'); ?> text-white">
                                    <div class="card-body">
                                        <h5>Porcentaje</h5>
                                        <h2><?php echo $resultado['porcentaje']; ?>%</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-info text-white">
                                    <div class="card-body">
                                        <h5>Correctas</h5>
                                        <h2><?php echo $resultado['respuestas_correctas']; ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-secondary text-white">
                                    <div class="card-body">
                                        <h5>Incorrectas</h5>
                                        <h2><?php echo $resultado['total_respondidas'] - $resultado['respuestas_correctas']; ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4">
                            <?php if ($resultado['porcentaje'] >= 70): ?>
                                <div class="alert alert-success">
                                    <i class="fas fa-check-circle"></i> ¡Excelente trabajo! Has aprobado el cuestionario.
                                </div>
                            <?php elseif ($resultado['porcentaje'] >= 50): ?>
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle"></i> Buen intento. Puedes mejorar revisando las respuestas incorrectas.
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    <i class="fas fa-times-circle"></i> Necesitas estudiar más el tema. Revisa las respuestas correctas.
                                </div>
                            <?php endif; ?>
                        </div>

                        <small class="text-muted">
                            Completado el: <?php echo date('d/m/Y H:i', strtotime($resultado['fecha_completado'])); ?>
                        </small>
                    </div>
                </div>

                <!-- Detalles de Respuestas -->
                <div class="card">
                    <div class="card-header bg-light">
                        <h5><i class="fas fa-list"></i> Revisión de Respuestas</h5>
                    </div>
                    <div class="card-body">
                        <?php $pregunta_num = 1; ?>
                        <?php foreach ($detalles as $detalle): ?>
                            <div class="card mb-3 border-<?php echo $detalle['usuario_correcto'] ? 'success' : 'danger'; ?>">
                                <div class="card-header bg-<?php echo $detalle['usuario_correcto'] ? 'success' : 'danger'; ?> text-white">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h6 class="mb-0">Pregunta <?php echo $pregunta_num; ?></h6>
                                        <div>
                                            <span class="badge bg-light text-dark me-2">
                                                Valor: <?php echo number_format($detalle['peso_pregunta'], 2); ?> puntos
                                            </span>
                                            <span class="badge bg-light text-dark">
                                                <?php echo $detalle['usuario_correcto'] ? 'Correcta' : 'Incorrecta'; ?>
                                                <?php echo $detalle['usuario_correcto'] ? '<i class="fas fa-check"></i>' : '<i class="fas fa-times"></i>'; ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <p><strong><?php echo htmlspecialchars($detalle['texto_pregunta']); ?></strong></p>

                                    <?php if (!empty($detalle['imagen_pregunta'])): ?>
                                        <div class="text-center mb-3">
                                            <img src="data:image/jpeg;base64,<?php echo base64_encode($detalle['imagen_pregunta']); ?>"
                                                alt="Imagen de la pregunta" class="pregunta-imagen">
                                        </div>
                                    <?php endif; ?>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="alert alert-<?php echo $detalle['usuario_correcto'] ? 'success' : 'danger'; ?> mb-0">
                                                <strong>Tu respuesta:</strong><br>
                                                <?php echo htmlspecialchars($detalle['respuesta_usuario']); ?>

                                                <?php if (!empty($detalle['imagen_respuesta_usuario'])): ?>
                                                    <div class="mt-2">
                                                        <img src="data:image/jpeg;base64,<?php echo base64_encode($detalle['imagen_respuesta_usuario']); ?>"
                                                            alt="Imagen de tu respuesta" class="opcion-imagen">
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <?php if (!$detalle['usuario_correcto']): ?>
                                            <div class="col-md-6">
                                                <div class="alert alert-success mb-0">
                                                    <strong>Respuesta correcta:</strong><br>
                                                    <?php echo htmlspecialchars($detalle['respuesta_correcta']); ?>

                                                    <?php if (!empty($detalle['imagen_respuesta_correcta'])): ?>
                                                        <div class="mt-2">
                                                            <img src="data:image/jpeg;base64,<?php echo base64_encode($detalle['imagen_respuesta_correcta']); ?>"
                                                                alt="Imagen de la respuesta correcta" class="opcion-imagen">
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php $pregunta_num++; ?>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <a href="../../src/Controllers/logoutEstudiantes_controller.php" class="btn btn-primary btn-lg no-print">
                        <i class="fas fa-home"></i> CERRAR
                    </a>
                    <button onclick="printResults()" class="btn btn-success btn-lg no-print ms-2">
                        <i class="fas fa-print"></i> Imprimir / Guardar PDF
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function printResults() {
            // Mostrar diálogo de impresión
            window.print();
        }
    </script>
</body>

</html>