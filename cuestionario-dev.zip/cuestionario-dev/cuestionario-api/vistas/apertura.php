<?php
include 'controller/apertura_controller.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apertura de Cuestionarios</title>
    <link rel="icon" type="image/png" href="./resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="./resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="./resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="./resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="/site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <span class="navbar-brand">Sistema de Cuestionarios</span>
            <div class="navbar-nav">
                <span class="nav-text text-white me-3">Bienvenido, <?php echo $_SESSION['usuario_nombre']; ?></span>
                <a href="../logout_controller.php" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <!-- Contenido Principal -->
    <div class="container mt-4">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-unlock-alt"></i> Apertura de Cuestionarios</h2>
            </div>
            <div class="col-md-4 text-end">
                <a href="MenuCuestionarios.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left"></i> Volver al Menú de Cuestionarios
                </a>
            </div>
        </div>

        <?php if (isset($mensaje)): ?>
            <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show" role="alert">
                <?php echo $mensaje; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <!-- Formulario de Apertura -->
            <div class="col-md-5">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5><i class="fas fa-calendar-plus"></i> Programar Apertura</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="apertura.php">
                            <div class="mb-3">
                                <label for="cuestionario_id" class="form-label">Cuestionario</label>
                                <select class="form-select" id="cuestionario_id" name="cuestionario_id" required>
                                    <option value="">Seleccione un cuestionario</option>
                                    <?php foreach ($mis_cuestionarios as $cuestionario): ?>
                                        <option value="<?php echo $cuestionario['id']; ?>">
                                            <?php echo htmlspecialchars($cuestionario['titulo']); ?> - 
                                            <?php echo htmlspecialchars($cuestionario['programa_nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="periodo_id" class="form-label">Periodo</label>
                                <select class="form-select" id="periodo_id" name="periodo_id" required>
                                    <option value="">Seleccione un periodo</option>
                                    <?php foreach ($periodos as $periodo): ?>
                                        <option value="<?php echo $periodo['id']; ?>">
                                            <?php echo htmlspecialchars($periodo['nombre']); ?> 
                                            (<?php echo date('d/m/Y', strtotime($periodo['fecha_inicio'])); ?> - 
                                            <?php echo date('d/m/Y', strtotime($periodo['fecha_fin'])); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-success" name="crear_apertura">
                                    <i class="fas fa-unlock-alt"></i> Abrir Cuestionario
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Lista de Aperturas -->
            <div class="col-md-7">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-list"></i> Cuestionarios Abiertos</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($aperturas)): ?>
                            <p class="text-muted">No hay cuestionarios abiertos actualmente.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Cuestionario</th>
                                            <th>Programa</th>
                                            <th>Periodo</th>
                                            <th>Fecha Inicio</th>
                                            <th>Fecha Fin</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($aperturas as $apertura): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($apertura['titulo']); ?></td>
                                                <td><?php echo htmlspecialchars($apertura['programa_nombre']); ?></td>
                                                <td><?php echo htmlspecialchars($apertura['periodo_nombre']); ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($apertura['fecha_inicio'])); ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($apertura['fecha_fin'])); ?></td>
                                                <td>
                                                    <a href="asignacionManage.php?apertura_id=<?php echo $apertura['id']; ?>" class="btn btn-sm btn-warning" title="Asignar a estudiantes">
                                                        <i class="fas fa-user-plus"></i>
                                                    </a>
                                                    <button type="button" class="btn btn-sm btn-danger" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#eliminarModal<?php echo $apertura['id']; ?>" 
                                                            title="Eliminar apertura">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                    
                                                    <!-- Modal de confirmación para eliminar -->
                                                    <div class="modal fade" id="eliminarModal<?php echo $apertura['id']; ?>" tabindex="-1" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header bg-danger text-white">
                                                                    <h5 class="modal-title">Confirmar Eliminación</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <p>¿Está seguro que desea eliminar la apertura del cuestionario <strong><?php echo htmlspecialchars($apertura['titulo']); ?></strong>?</p>
                                                                    <p class="text-danger"><i class="fas fa-exclamation-triangle"></i> Esta acción eliminará todas las asignaciones asociadas.</p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                                    <a href="apertura.php?eliminar=<?php echo $apertura['id']; ?>" class="btn btn-danger">Eliminar</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
