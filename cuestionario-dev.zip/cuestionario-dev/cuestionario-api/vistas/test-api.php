<?php
// Configuración CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header('Content-Type: application/json');

// Responder inmediatamente a las solicitudes OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// Datos de prueba
$programas = [
    [
        'id' => 1,
        'nombre' => 'Ingeniería de Software',
        'nivel_nombre' => 'Licenciatura',
        'campus_nombre' => 'Campus Principal'
    ],
    [
        'id' => 2,
        'nombre' => 'Administración de Empresas',
        'nivel_nombre' => 'Licenciatura',
        'campus_nombre' => 'Campus Norte'
    ],
    [
        'id' => 3,
        'nombre' => 'Maestría en Ciencias de la Computación',
        'nivel_nombre' => 'Posgrado',
        'campus_nombre' => 'Campus Principal'
    ]
];

$periodos = [
    [
        'id' => 1,
        'nombre' => 'Semestre 2023-1',
        'fecha_inicio' => '2023-01-15',
        'fecha_fin' => '2023-06-30'
    ],
    [
        'id' => 2,
        'nombre' => 'Semestre 2023-2',
        'fecha_inicio' => '2023-08-01',
        'fecha_fin' => '2023-12-15'
    ],
    [
        'id' => 3,
        'nombre' => 'Semestre 2024-1',
        'fecha_inicio' => '2024-01-15',
        'fecha_fin' => '2024-06-30'
    ]
];

echo json_encode([
    'success' => true,
    'programas' => $programas,
    'periodos' => $periodos
]);
?> 