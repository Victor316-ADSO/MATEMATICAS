<?php
include '../../src/Controllers/ver_respuestas_controller.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Respuestas del Estudiante</title>
    <link rel="icon" type="image/png" href="../../Resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="../../Resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="../../Resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="../../Resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="../../site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .pregunta-imagen {
            max-width: 100%;
            max-height: 300px;
            margin: 10px 0;
            border-radius: 5px;
            object-fit: contain;
        }

        .opcion-imagen {
            max-width: 100%;
            max-height: 150px;
            margin: 5px 0;
            border-radius: 5px;
            object-fit: contain;
        }
    </style>
</head>

<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="btn btn-outline-light" href="javascript:history.back()">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
            <span class="navbar-brand">Respuestas del Estudiante</span>
            <div class="navbar-nav">
                <span class="nav-text text-white me-3">Bienvenido, <?php echo $_SESSION['usuario_nombre']; ?></span>
                <a href="src/Controllers/logout_controller.php" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <!-- Contenido Principal -->
    <div class="container mt-4">
        <!-- Información del Estudiante y Cuestionario -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5><i class="fas fa-user-graduate"></i> Información del Estudiante</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h4><?php echo htmlspecialchars($estudiante['nombre']); ?></h4>
                        <p><strong>Identificación:</strong> <?php echo htmlspecialchars($estudiante['identificacion']); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($estudiante['email']); ?></p>
                        <p><strong>Programa:</strong> <?php echo htmlspecialchars($estudiante['programa_nombre']); ?></p>
                    </div>
                    <div class="col-md-6">
                        <h5><?php echo htmlspecialchars($cuestionario['titulo']); ?></h5>
                        <p class="text-muted"><?php echo htmlspecialchars($cuestionario['descripcion']); ?></p>
                        <p><strong>Fecha de realización:</strong> <?php echo date('d/m/Y H:i', strtotime($fecha_respuesta)); ?></p>
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <strong>Puntaje:</strong> <?php echo $puntaje_obtenido; ?> / <?php echo $puntaje_total; ?>
                                (<?php echo $porcentaje; ?>%)
                            </div>
                            <div class="progress" style="width: 150px;">
                                <div class="progress-bar <?php echo $porcentaje >= 70 ? 'bg-success' : ($porcentaje >= 40 ? 'bg-warning' : 'bg-danger'); ?>" role="progressbar" style="width: <?php echo $porcentaje; ?>%;" aria-valuenow="<?php echo $porcentaje; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Respuestas del Estudiante -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5><i class="fas fa-list-check"></i> Respuestas</h5>
            </div>
            <div class="card-body">
                <?php if (empty($respuestas)): ?>
                    <p class="text-center">No se encontraron respuestas para este estudiante.</p>
                <?php else: ?>
                    <div class="accordion" id="respuestasAccordion">
                        <?php foreach ($respuestas as $index => $respuesta): ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo $index; ?>">
                                    <button class="accordion-button <?php echo $index > 0 ? 'collapsed' : ''; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $index; ?>" aria-expanded="<?php echo $index === 0 ? 'true' : 'false'; ?>" aria-controls="collapse<?php echo $index; ?>">
                                        <div class="d-flex w-100 justify-content-between align-items-center">
                                            <span>
                                                Pregunta <?php echo $index + 1; ?>:
                                                <?php echo htmlspecialchars(substr($respuesta['texto_pregunta'], 0, 50)); ?>
                                                <?php echo strlen($respuesta['texto_pregunta']) > 50 ? '...' : ''; ?>
                                            </span>
                                            <?php if ($respuesta['es_correcta']): ?>
                                                <span class="badge bg-success ms-2">Correcta</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger ms-2">Incorrecta</span>
                                            <?php endif; ?>
                                        </div>
                                    </button>
                                </h2>
                                <div id="collapse<?php echo $index; ?>" class="accordion-collapse collapse <?php echo $index === 0 ? 'show' : ''; ?>" aria-labelledby="heading<?php echo $index; ?>" data-bs-parent="#respuestasAccordion">
                                    <div class="accordion-body">
                                        <p class="fw-bold"><?php echo htmlspecialchars($respuesta['texto_pregunta']); ?></p>

                                        <?php if (!empty($respuesta['imagen_pregunta'])): ?>
                                            <div class="text-center mb-3">
                                                <img src="data:image/jpeg;base64,<?php echo base64_encode($respuesta['imagen_pregunta']); ?>"
                                                    alt="Imagen de la pregunta" class="pregunta-imagen">
                                            </div>
                                        <?php endif; ?>

                                        <p><strong>Peso de la pregunta:</strong> <?php echo $respuesta['peso_pregunta']; ?> puntos</p>

                                        <div class="mt-3">
                                            <p><strong>Opciones:</strong></p>
                                            <ul class="list-group">
                                                <?php foreach ($respuesta['opciones'] as $opcion): ?>
                                                    <li class="list-group-item <?php echo $opcion['id'] == $respuesta['id_opcion_seleccionada'] ? ($opcion['es_correcta'] ? 'list-group-item-success' : 'list-group-item-danger') : ($opcion['es_correcta'] ? 'list-group-item-info' : ''); ?>">
                                                        <?php echo htmlspecialchars($opcion['texto_opcion']); ?>

                                                        <?php if ($opcion['id'] == $respuesta['id_opcion_seleccionada']): ?>
                                                            <span class="badge bg-primary float-end">Seleccionada</span>
                                                        <?php endif; ?>

                                                        <?php if ($opcion['es_correcta']): ?>
                                                            <span class="badge bg-success float-end me-2">Correcta</span>
                                                        <?php endif; ?>

                                                        <?php if (!empty($opcion['imagen_opcion'])): ?>
                                                            <div class="mt-2">
                                                                <img src="data:image/jpeg;base64,<?php echo base64_encode($opcion['imagen_opcion']); ?>"
                                                                    alt="Imagen de la opción" class="opcion-imagen">
                                                            </div>
                                                        <?php endif; ?>
                                                    </li>
                                                <?php endforeach; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>