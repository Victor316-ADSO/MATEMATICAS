<?php
include 'controller/seguimiento_controller.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seguimiento de Cuestionario</title>
    <link rel="icon" type="image/png" href="./resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="./resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="./resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="./resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="/site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="btn btn-outline-light" href="principal.php">
                <i class="fas fa-arrow-left"></i> Volver al Menú
            </a>
            <span class="navbar-brand">Seguimiento de Cuestionario</span>
            <div class="navbar-nav">
                <span class="nav-text text-white me-3">Bienvenido, <?php echo $_SESSION['usuario_nombre']; ?></span>
                <a href="../logout_controller.php" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <!-- Contenido Principal -->
    <div class="container mt-4">
        <?php if (isset($mensaje)): ?>
            <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show" role="alert">
                <?php echo $mensaje; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Información del Cuestionario -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5><i class="fas fa-info-circle"></i> Información del Cuestionario</h5>
            </div>
            <div class="card-body">
                <h4><?php echo htmlspecialchars($cuestionario['titulo']); ?></h4>
                <p class="text-muted"><?php echo htmlspecialchars($cuestionario['descripcion']); ?></p>
                
                <div class="row">
                    <div class="col-md-4">
                        <p><strong>Programa:</strong> <?php echo htmlspecialchars($cuestionario['programa_nombre']); ?></p>
                    </div>
                    <div class="col-md-4">
                        <p><strong>Periodo:</strong> <?php echo htmlspecialchars($cuestionario['periodo_nombre']); ?></p>
                    </div>
                    <div class="col-md-4">
                        <p><strong>Fechas:</strong> <?php echo date('d/m/Y', strtotime($cuestionario['fecha_inicio'])); ?> - <?php echo date('d/m/Y', strtotime($cuestionario['fecha_fin'])); ?></p>
                    </div>
                </div>

                <div class="mt-3">
                    <div class="progress mb-2">
                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $porcentaje_completado; ?>%;" aria-valuenow="<?php echo $porcentaje_completado; ?>" aria-valuemin="0" aria-valuemax="100"><?php echo $porcentaje_completado; ?>%</div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="badge bg-info">
                            <i class="fas fa-users"></i> Asignados: <?php echo count($estudiantes); ?>
                        </span>
                        <span class="badge bg-success">
                            <i class="fas fa-check-circle"></i> Completados: <?php echo $estudiantes_completados; ?>
                        </span>
                        <span class="badge bg-warning">
                            <i class="fas fa-hourglass-half"></i> Pendientes: <?php echo count($estudiantes) - $estudiantes_completados; ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lista de Estudiantes -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5><i class="fas fa-users"></i> Estudiantes Asignados</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Identificación</th>
                                <th>Email</th>
                                <th>Estado</th>
                                <th>Fecha de Realización</th>
                                <th>Puntaje</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($estudiantes)): ?>
                                <tr>
                                    <td colspan="7" class="text-center">No hay estudiantes asignados a este cuestionario.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($estudiantes as $estudiante): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($estudiante['nombre']); ?></td>
                                        <td><?php echo htmlspecialchars($estudiante['identificacion']); ?></td>
                                        <td><?php echo htmlspecialchars($estudiante['email']); ?></td>
                                        <td>
                                            <?php if ($estudiante['completado']): ?>
                                                <span class="badge bg-success">Completado</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning">Pendiente</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo $estudiante['fecha_respuesta'] ? date('d/m/Y H:i', strtotime($estudiante['fecha_respuesta'])) : 'N/A'; ?>
                                        </td>
                                        <td>
                                            <?php if ($estudiante['completado']): ?>
                                                <?php echo $estudiante['puntaje_obtenido']; ?> / <?php echo $estudiante['puntaje_total']; ?>
                                                (<?php echo $estudiante['porcentaje']; ?>%)
                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($estudiante['completado']): ?>
                                                <a href="ver_respuestas.php?estudiante_id=<?php echo $estudiante['id']; ?>&cuestionario_id=<?php echo $cuestionario['id']; ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i> Ver Respuestas
                                                </a>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-secondary" disabled>
                                                    <i class="fas fa-eye-slash"></i> Sin Respuestas
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html> 