<?php
include 'controller/seguimiento_lista_controller.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seguimiento de Cuestionarios</title>
    <link rel="icon" type="image/png" href="./resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="./resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="./resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="./resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="/site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="btn btn-outline-light" href="principal.php">
                <i class="fas fa-arrow-left"></i> Volver al Inicio
            </a>
            <span class="navbar-brand">Seguimiento de Cuestionarios</span>
            <div class="navbar-nav">
                <span class="nav-text text-white me-3">Bienvenido, <?php echo $_SESSION['usuario_nombre']; ?></span>
                <a href="../logout_controller.php" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <!-- Contenido Principal -->
    <div class="container mt-4">
        <?php if (isset($mensaje)): ?>
            <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show" role="alert">
                <?php echo $mensaje; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Tarjetas de información -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title">Total Cuestionarios</h6>
                                <h2><?php echo count($cuestionarios_seguimiento); ?></h2>
                            </div>
                            <i class="fas fa-clipboard-list fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title">Estudiantes Asignados</h6>
                                <h2><?php echo $total_estudiantes_asignados; ?></h2>
                            </div>
                            <i class="fas fa-users fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title">Completados</h6>
                                <h2><?php echo $total_estudiantes_completados; ?> (<?php echo $porcentaje_global; ?>%)</h2>
                            </div>
                            <i class="fas fa-check-circle fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lista de Cuestionarios para Seguimiento -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5><i class="fas fa-chart-bar"></i> Cuestionarios Asignados</h5>
            </div>
            <div class="card-body">
                <?php if (empty($cuestionarios_seguimiento)): ?>
                    <p class="text-muted text-center">No hay cuestionarios asignados para seguimiento actualmente.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Título</th>
                                    <th>Programa</th>
                                    <th>Periodo</th>
                                    <th>Fechas</th>
                                    <th>Progreso</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cuestionarios_seguimiento as $cuestionario): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($cuestionario['titulo']); ?></strong>
                                            <div class="text-muted small"><?php echo htmlspecialchars(substr($cuestionario['descripcion'], 0, 50)); ?><?php echo strlen($cuestionario['descripcion']) > 50 ? '...' : ''; ?></div>
                                        </td>
                                        <td><?php echo htmlspecialchars($cuestionario['programa_nombre']); ?></td>
                                        <td><?php echo htmlspecialchars($cuestionario['periodo_nombre']); ?></td>
                                        <td>
                                            <div class="small">
                                                <i class="fas fa-calendar-day"></i> <?php echo date('d/m/Y', strtotime($cuestionario['fecha_inicio'])); ?>
                                                <br>
                                                <i class="fas fa-calendar-day"></i> <?php echo date('d/m/Y', strtotime($cuestionario['fecha_fin'])); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php 
                                                $total_asignados = $cuestionario['total_estudiantes_asignados'];
                                                $total_completados = $cuestionario['total_estudiantes_completados'];
                                                $porcentaje = ($total_asignados > 0) ? round(($total_completados / $total_asignados) * 100) : 0;
                                            ?>
                                            <div class="progress" style="height: 20px;">
                                                <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $porcentaje; ?>%;" aria-valuenow="<?php echo $porcentaje; ?>" aria-valuemin="0" aria-valuemax="100">
                                                    <?php echo $porcentaje; ?>%
                                                </div>
                                            </div>
                                            <div class="small mt-1">
                                                <span class="text-success"><?php echo $total_completados; ?></span> / <?php echo $total_asignados; ?> estudiantes
                                            </div>
                                        </td>
                                        <td>
                                            <a href="seguimiento_detalle.php?apertura_id=<?php echo $cuestionario['apertura_id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-chart-bar"></i> Ver Detalles
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html> 