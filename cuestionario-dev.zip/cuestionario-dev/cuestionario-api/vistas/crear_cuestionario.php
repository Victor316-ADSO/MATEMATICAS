<?php
include '../../src/Controllers/crearCuestionario_controller.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Cuestionario</title>
    <link rel="icon" type="image/png" href="../../Resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="../../Resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="../../Resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="../../Resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="../../site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a href="MenuCuestionarios.php" class="btn btn-outline-light">
                <i class="fas fa-arrow-left"></i> Volver al Menú de Cuestionarios
            </a>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-plus"></i> Crear Nuevo Cuestionario</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($mensaje): ?>
                            <div class="alert alert-success">
                                <?php echo $mensaje; ?>
                                <a href="principal.php" class="btn btn-sm btn-primary ms-2">Ir al Dashboard</a>
                            </div>
                        <?php endif; ?>

                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <form method="POST" id="cuestionarioForm" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="titulo" class="form-label">Título del Cuestionario</label>
                                <input type="text" class="form-control" id="titulo" name="titulo" required>
                            </div>

                            <div class="mb-3">
                                <label for="descripcion" class="form-label">Descripción</label>
                                <textarea class="form-control" id="descripcion" name="descripcion" rows="3"></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="programa_id" class="form-label">Programa</label>
                                <select class="form-select" id="programa_id" name="programa_id" required>
                                    <option value="">Seleccione un programa</option>
                                    <?php foreach ($programas as $programa): ?>
                                        <option value="<?php echo $programa['id']; ?>">
                                            <?php echo htmlspecialchars($programa['nombre']); ?> - 
                                            <?php echo htmlspecialchars($programa['nivel_nombre']); ?> - 
                                            <?php echo htmlspecialchars($programa['campus_nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <hr>

                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5>Preguntas</h5>
                                <button type="button" class="btn btn-success" onclick="agregarPregunta()">
                                    <i class="fas fa-plus"></i> Agregar Pregunta
                                </button>
                            </div>

                            <div id="preguntasContainer">
                                <!-- Las preguntas se agregarán dinámicamente aquí -->
                            </div>

                            <div class="mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Crear Cuestionario
                                </button>
                                <a href="MenuCuestionarios.php" class="btn btn-secondary">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let preguntaCounter = 0;

        function agregarPregunta() {
            const container = document.getElementById('preguntasContainer');
            const preguntaDiv = document.createElement('div');
            preguntaDiv.className = 'card mb-3';
            preguntaDiv.innerHTML = `
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h6>Pregunta ${preguntaCounter + 1}</h6>
                        <button type="button" class="btn btn-sm btn-danger" onclick="eliminarPregunta(this)">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Texto de la pregunta</label>
                        <input type="text" class="form-control" name="preguntas[${preguntaCounter}][texto]" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Imagen de la pregunta (opcional)</label>
                        <input type="file" class="form-control" name="preguntas[${preguntaCounter}][imagen]" accept="image/jpeg,image/png,image/gif">
                        <small class="text-muted">Formatos aceptados: JPG, PNG, GIF (máx. 2MB)</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Peso de la pregunta</label>
                        <input type="number" class="form-control" name="preguntas[${preguntaCounter}][peso]" value="1.00" step="0.01" min="0.01" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Opciones de respuesta</label>
                        <div class="opciones-container">
                            ${generarOpciones(preguntaCounter)}
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" onclick="agregarOpcion(this, ${preguntaCounter})">
                            <i class="fas fa-plus"></i> Agregar Opción
                        </button>
                    </div>
                </div>
            `;
            container.appendChild(preguntaDiv);
            preguntaCounter++;
        }

        function generarOpciones(preguntaIndex) {
            let opciones = '';
            for (let i = 0; i < 2; i++) {
                opciones += `
                    <div class="input-group mb-2 opcion-item">
                        <div class="input-group-text">
                            <input type="radio" name="preguntas[${preguntaIndex}][correcta]" value="${i}" required>
                        </div>
                        <input type="text" class="form-control" name="preguntas[${preguntaIndex}][opciones][${i}][texto]" placeholder="Opción ${i + 1}" required>
                        <button type="button" class="btn btn-outline-danger" onclick="eliminarOpcion(this)" ${i < 2 ? 'disabled' : ''}>
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Imagen para opción ${i + 1} (opcional)</label>
                        <input type="file" class="form-control form-control-sm" name="preguntas[${preguntaIndex}][opciones][${i}][imagen]" accept="image/jpeg,image/png,image/gif">
                    </div>
                `;
            }
            return opciones;
        }

        function agregarOpcion(button, preguntaIndex) {
            const container = button.previousElementSibling;
            const opcionesCount = container.querySelectorAll('.opcion-item').length;

            const opcionDiv = document.createElement('div');
            opcionDiv.innerHTML = `
                <div class="input-group mb-2 opcion-item">
                    <div class="input-group-text">
                        <input type="radio" name="preguntas[${preguntaIndex}][correcta]" value="${opcionesCount}" required>
                    </div>
                    <input type="text" class="form-control" name="preguntas[${preguntaIndex}][opciones][${opcionesCount}][texto]" placeholder="Opción ${opcionesCount + 1}" required>
                    <button type="button" class="btn btn-outline-danger" onclick="eliminarOpcion(this)">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="mb-2">
                    <label class="form-label small">Imagen para opción ${opcionesCount + 1} (opcional)</label>
                    <input type="file" class="form-control form-control-sm" name="preguntas[${preguntaIndex}][opciones][${opcionesCount}][imagen]" accept="image/jpeg,image/png,image/gif">
                </div>
            `;
            container.appendChild(opcionDiv);
        }

        function eliminarOpcion(button) {
            const container = button.closest('.opciones-container');
            const opcionItem = button.closest('.opcion-item');
            const imagenDiv = opcionItem.nextElementSibling;
            
            // Contar cuántas opciones hay actualmente
            const opciones = container.querySelectorAll('.opcion-item');

            if (opciones.length > 2) {
                // Eliminar tanto la opción como su div de imagen
                opcionItem.remove();
                if (imagenDiv) {
                    imagenDiv.remove();
                }
            } else {
                alert('Debe haber al menos 2 opciones por pregunta');
            }
        }

        function eliminarPregunta(button) {
            if (confirm('¿Estás seguro de que quieres eliminar esta pregunta?')) {
                button.closest('.card').remove();
            }
        }

        // Agregar una pregunta inicial
        document.addEventListener('DOMContentLoaded', function() {
            agregarPregunta();
        });
    </script>
</body>

</html>