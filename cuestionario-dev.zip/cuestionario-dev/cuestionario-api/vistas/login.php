<?php
// Deshabilitar la visualización de errores
error_reporting(0);
ini_set('display_errors', 0);

// Incluir el manejo de CORS primero
require_once __DIR__ . '/api/cors.php';

session_start();
header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . '/api/api.php';
require_once __DIR__ . '/model/conection.php';

try {
    $input = json_decode(file_get_contents("php://input"), true);
    if (!$input) {
        throw new Exception('No se recibieron datos.');
    }

    $email = sanitize_input($input['email']);
    $password = $input['password'];

    $database = new Database();
    $db = $database->connect();

    $query = "SELECT id, nombre, email, password FROM docente WHERE email = :email";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() == 1) {
        $user = $stmt->fetch();
        if (password_verify($password, $user['password']) || $password === $user['password']) {
            $_SESSION['usuario_id'] = $user['id'];
            $_SESSION['usuario_nombre'] = $user['nombre'];
            $_SESSION['usuario_email'] = $user['email'];

            echo json_encode([
                'status' => 'ok',
                'usuario' => [
                    'id' => $user['id'],
                    'nombre' => $user['nombre'],
                    'email' => $user['email']
                ]
            ]);
        } else {
            throw new Exception('Credenciales incorrectas.');
        }
    } else {
        throw new Exception('Usuario no encontrado.');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'mensaje' => $e->getMessage()
    ]);
}