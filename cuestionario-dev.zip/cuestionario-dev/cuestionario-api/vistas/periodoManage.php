<?php
include 'controller/periodoManage_controller.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Periodos</title>
    <link rel="icon" type="image/png" href="./resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="./resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="./resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="./resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="/site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <span class="navbar-brand">Sistema de Cuestionarios</span>
            <div class="navbar-nav">
                <span class="nav-text text-white me-3">Bienvenido, <?php echo $_SESSION['usuario_nombre']; ?></span>
                <a href="../logout_controller.php" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <!-- Contenido Principal -->
    <div class="container mt-4">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-calendar-alt"></i> Gestión de Periodos</h2>
            </div>
            <div class="col-md-4 text-end">
                <a href="principal.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left"></i> Volver al Inicio
                </a>
            </div>
        </div>

        <?php if (isset($mensaje)): ?>
            <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show" role="alert">
                <?php echo $mensaje; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <!-- Formulario de Creación/Edición -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <?php if ($periodo_editar): ?>
                            <h5><i class="fas fa-edit"></i> Editar Periodo</h5>
                        <?php else: ?>
                            <h5><i class="fas fa-plus"></i> Nuevo Periodo</h5>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="periodoManage.php">
                            <?php if ($periodo_editar): ?>
                                <input type="hidden" name="action" value="edit">
                                <input type="hidden" name="id" value="<?php echo $periodo_editar['id']; ?>">
                            <?php else: ?>
                                <input type="hidden" name="action" value="create">
                            <?php endif; ?>

                            <div class="mb-3">
                                <label for="nombre" class="form-label">Nombre del Periodo</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" 
                                       value="<?php echo $periodo_editar ? $periodo_editar['nombre'] : ''; ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="fecha_inicio" class="form-label">Fecha de Inicio</label>
                                <input type="date" class="form-control" id="fecha_inicio" name="fecha_inicio" 
                                       value="<?php echo $periodo_editar ? $periodo_editar['fecha_inicio'] : ''; ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="fecha_fin" class="form-label">Fecha de Fin</label>
                                <input type="date" class="form-control" id="fecha_fin" name="fecha_fin" 
                                       value="<?php echo $periodo_editar ? $periodo_editar['fecha_fin'] : ''; ?>" required>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo $periodo_editar ? '<i class="fas fa-save"></i> Actualizar' : '<i class="fas fa-plus"></i> Crear'; ?>
                                </button>
                                <?php if ($periodo_editar): ?>
                                    <a href="periodoManage.php" class="btn btn-secondary">Cancelar</a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Lista de Periodos -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-list"></i> Periodos Existentes</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($periodos)): ?>
                            <p class="text-muted">No hay periodos registrados.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nombre</th>
                                            <th>Fecha Inicio</th>
                                            <th>Fecha Fin</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($periodos as $periodo): ?>
                                            <tr>
                                                <td><?php echo $periodo['id']; ?></td>
                                                <td><?php echo htmlspecialchars($periodo['nombre']); ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($periodo['fecha_inicio'])); ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($periodo['fecha_fin'])); ?></td>
                                                <td>
                                                    <a href="periodoManage.php?edit=<?php echo $periodo['id']; ?>" class="btn btn-sm btn-warning">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $periodo['id']; ?>">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                    
                                                    <!-- Modal de Confirmación de Eliminación -->
                                                    <div class="modal fade" id="deleteModal<?php echo $periodo['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo $periodo['id']; ?>" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header bg-danger text-white">
                                                                    <h5 class="modal-title" id="deleteModalLabel<?php echo $periodo['id']; ?>">Confirmar Eliminación</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    ¿Está seguro que desea eliminar el periodo <strong><?php echo htmlspecialchars($periodo['nombre']); ?></strong>?
                                                                    <p class="text-danger mt-2">
                                                                        <i class="fas fa-exclamation-triangle"></i> Esta acción no se puede deshacer.
                                                                    </p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                                    <form method="POST" action="periodoManage.php" style="display: inline;">
                                                                        <input type="hidden" name="delete" value="1">
                                                                        <input type="hidden" name="id" value="<?php echo $periodo['id']; ?>">
                                                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>