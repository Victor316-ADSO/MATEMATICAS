<?php
    include 'controller/ver_controller.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cuestionario - Preguntas y Respuestas</title>
    <link rel="icon" type="image/png" href="./resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="./resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="./resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="./resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="/site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a href="principal.php" class="navbar-brand">
                <i class="fas fa-arrow-left"></i> Volver al Dashboard
            </a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
                <p><a href="principal.php" class="btn btn-primary mt-2">Volver al Dashboard</a></p>
            </div>
        <?php else: ?>
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h2><?php echo htmlspecialchars($cuestionario['titulo']); ?></h2>
                </div>
                <div class="card-body">
                    <?php if (!empty($cuestionario['descripcion'])): ?>
                        <p class="lead"><?php echo htmlspecialchars($cuestionario['descripcion']); ?></p>
                    <?php endif; ?>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Creado por:</strong> <?php echo htmlspecialchars($cuestionario['creador_nombre']); ?>
                        </div>
                        <div class="col-md-6">
                            <strong>Programa:</strong> <?php echo htmlspecialchars($cuestionario['programa_nombre']); ?> - 
                            <?php echo htmlspecialchars($cuestionario['nivel_nombre']); ?> - 
                            <?php echo htmlspecialchars($cuestionario['campus_nombre']); ?>
                        </div>
                    </div>
                    
                    <small class="text-muted">ID del Cuestionario: <?php echo $cuestionario_id; ?></small>
                </div>
            </div>

            <?php
            // Mostrar las preguntas y opciones
            if (empty($preguntas_con_opciones)) {
                echo '<div class="alert alert-warning">Este cuestionario no tiene preguntas disponibles.</div>';
            } else {
                foreach ($preguntas_con_opciones as $pregunta) {
                    ?>
                    <div class="card mb-3">
                        <div class="card-header">
                            <strong>Pregunta <?php echo ($pregunta['orden_pregunta'] + 1); ?>:</strong> 
                            <?php echo htmlspecialchars($pregunta['texto_pregunta']); ?>
                            <span class="badge bg-info float-end">Valor: <?php echo $pregunta['peso_pregunta']; ?> puntos</span>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($pregunta['opciones'])): ?>
                                <ul class="list-group">
                                    <?php foreach ($pregunta['opciones'] as $opcion): ?>
                                        <li class="list-group-item <?php echo $opcion['es_correcta'] ? 'list-group-item-success' : ''; ?>">
                                            <?php echo htmlspecialchars($opcion['texto_opcion']); ?>
                                            <?php if ($opcion['es_correcta']): ?>
                                                <span class="badge bg-success float-end">Respuesta correcta</span>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <div class="alert alert-warning">No hay opciones disponibles para esta pregunta</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
            
            <div class="mt-4">
                <a href="principal.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left"></i> Volver al Dashboard
                </a>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>