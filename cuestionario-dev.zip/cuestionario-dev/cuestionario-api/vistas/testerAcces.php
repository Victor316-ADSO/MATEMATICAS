<?php
require_once '../model/conection.php';
$database = new Database();
$db = $database->connect();

$query = "SELECT id, nombre, email, password FROM usuarios WHERE email = 'tester' ";
$stmt = $db->prepare($query);
$stmt->execute();
$user = $stmt->fetch();
$_SESSION['usuario_id'] = $user['id'];
$_SESSION['usuario_nombre'] = $user['nombre'];
$_SESSION['usuario_email'] = $user['email'];
header("Location: principal.php");