<?php
include 'controller/principal_controller.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Cuestionarios</title>
    <link rel="icon" type="image/png" href="./resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="./resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="./resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="./resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="/site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="btn btn-warning" href="adminSwitch.php">Admin</a>
            <a class="btn btn-danger" href="testSwitch.php">Tester</a>
            <span class="navbar-brand">Sistema de Cuestionarios</span>
            <div class="navbar-nav">
                <span class="nav-text text-white me-3">Bienvenido, <?php echo $_SESSION['usuario_nombre']; ?></span>
                <a href="../logout_controller.php" class="btn btn-outline-light btn-sm">Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <!-- Contenido Principal -->
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header bg-success text-white">
                        <h5><i class="fas fa-plus"></i> Crear Nuevo Cuestionario</h5>
                    </div>
                    <div class="card-body text-center">
                        <p>Crea un nuevo cuestionario con preguntas de opción múltiple</p>
                        <a href="crear_cuestionario.php" class="btn btn-success">
                            <i class="fas fa-plus"></i> Crear Cuestionario
                        </a>
                    </div>
                </div>
            </div>


            <!-- Periodo Manage -->
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-calendar-alt"></i> Periodo Manage</h5>
                    </div>
                    <div class="card-body text-center">
                        <p>Gestiona los periodos académicos o de cuestionarios.</p>
                        <a href="periodoManage.php" class="btn btn-info">
                            <i class="fas fa-cog"></i> Periodo Manage
                        </a>
                    </div>
                </div>
            </div>

            <!-- Mis Cuestionarios -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="mis-cuestionarios-tab" data-bs-toggle="tab" data-bs-target="#mis-cuestionarios" type="button">
                                    Mis Cuestionarios (<?php echo count($mis_cuestionarios); ?>)
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="disponibles-tab" data-bs-toggle="tab" data-bs-target="#disponibles" type="button">
                                    Disponibles (<?php echo count($otros_cuestionarios); ?>)
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="resultados-tab" data-bs-toggle="tab" data-bs-target="#resultados" type="button">
                                    Mis Resultados (<?php echo count($resultados); ?>)
                                </button>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content" id="myTabContent">
                            <!-- Mis Cuestionarios -->
                            <div class="tab-pane fade show active" id="mis-cuestionarios">
                                <?php if (empty($mis_cuestionarios)): ?>
                                    <p class="text-muted">No has creado ningún cuestionario aún.</p>
                                <?php else: ?>
                                    <?php foreach ($mis_cuestionarios as $cuestionario): ?>
                                        <div class="border rounded p-3 mb-3">
                                            <h6><?php echo isset($cuestionario['titulo']) ? htmlspecialchars($cuestionario['titulo']) : 'Sin título'; ?></h6>
                                            <p class="text-muted mb-2"><?php echo isset($cuestionario['descripcion']) ? htmlspecialchars($cuestionario['descripcion']) : 'Sin descripción'; ?></p>
                                            <small class="text-muted">ID: <?php echo isset($cuestionario['id']) ? $cuestionario['id'] : 'Desconocido'; ?></small>
                                            <button class="btn btn-sm btn-outline-secondary ms-2 copy-link" data-id="<?php echo $cuestionario['id']; ?>">
                                                <i class="fas fa-link"></i> Copiar enlace
                                            </button>
                                            <div class="mt-2">
                                                <a href="ver.php?id=<?php echo $cuestionario['id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-eye"></i> Ver
                                                </a>
                                                <!-- <a href="editar_cuestionario.php?id=<?php echo $cuestionario['id']; ?>" class="btn btn-sm btn-warning">
                                                    <i class="fas fa-edit"></i> Editar -->
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>

                            <!-- Cuestionarios Disponibles -->
                            <div class="tab-pane fade" id="disponibles">
                                <?php if (empty($all_others_cuestionarios)): ?>
                                    <p class="text-muted">No hay cuestionarios de otros usuarios.</p>
                                <?php else: ?>
                                    <?php
                                    $current_time = new DateTime(); // Obtener la hora actual
                                    ?>
                                    <?php foreach ($all_others_cuestionarios as $cuestionario): ?>
                                        <div class="border rounded p-3 mb-3">
                                            <h6><?php echo isset($cuestionario['titulo']) ? htmlspecialchars($cuestionario['titulo']) : 'Sin título'; ?></h6>
                                            <p class="text-muted mb-2"><?php echo isset($cuestionario['descripcion']) ? htmlspecialchars($cuestionario['descripcion']) : 'Sin descripción'; ?></p><br>
                                            <small class="text-muted">
                                                Creado por: <?php echo isset($cuestionario['creador_nombre']) ? htmlspecialchars($cuestionario['creador_nombre']) : 'Desconocido'; ?>
                                            </small>
                                            <div class="mt-2">
                                                <?php
                                                $fecha_inicio = !empty($cuestionario['fecha_inicio']) ? new DateTime($cuestionario['fecha_inicio']) : null;
                                                $fecha_fin = !empty($cuestionario['fecha_fin']) ? new DateTime($cuestionario['fecha_fin']) : null;
                                                $current_time = new DateTime(); // Obtener la hora actual

                                                $is_available = true;
                                                $availability_message = '';
                                                $button_class = 'btn-success';
                                                $button_icon = 'fas fa-play';
                                                $button_text = 'Resolver';
                                                $button_disabled = '';

                                                if ($fecha_inicio && $current_time < $fecha_inicio) {
                                                    $is_available = false;
                                                    $availability_message = ' (Disponible a partir de: ' . $fecha_inicio->format('d/m/Y H:i') . ')';
                                                    $button_class = 'btn-warning';
                                                    $button_icon = 'fas fa-calendar-alt';
                                                    $button_text = 'Programado';
                                                    $button_disabled = 'disabled';
                                                } elseif ($fecha_fin && $current_time > $fecha_fin) {
                                                    $is_available = false;
                                                    $availability_message = ' (Expirado el: ' . $fecha_fin->format('d/m/Y H:i') . ')';
                                                    $button_class = 'btn-danger';
                                                    $button_icon = 'fa-solid fa-circle-xmark';
                                                    $button_text = 'Expirado';
                                                    $button_disabled = 'disabled';
                                                }
                                                ?>

                                                <?php if ($is_available): ?>
                                                    <a href="resolver.php?id=<?php echo $cuestionario['id']; ?>" class="btn btn-sm <?php echo $button_class; ?>">
                                                        <i class="<?php echo $button_icon; ?>"></i> <?php echo $button_text; ?>
                                                    </a>
                                                <?php else: ?>
                                                    <button type="button" class="btn btn-sm <?php echo $button_class; ?>" <?php echo $button_disabled; ?>>
                                                        <i class="<?php echo $button_icon; ?>"></i> <?php echo $button_text; ?>
                                                    </button>
                                                <?php endif; ?>
                                                <span class="text-muted ms-2"><?php echo $availability_message; ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>

                            <!-- Mis Resultados -->
                            <div class="tab-pane fade" id="resultados">
                                <?php if (empty($resultados)): ?>
                                    <p class="text-muted">No has resuelto ningún cuestionario aún.</p>
                                <?php else: ?>
                                    <?php foreach ($resultados as $resultado): ?>
                                        <div class="border rounded p-3 mb-3">
                                            <h6><?php echo isset($resultado['cuestionario_titulo']) ? htmlspecialchars($resultado['cuestionario_titulo']) : 'Sin título'; ?></h6>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <span class="badge bg-<?php echo (isset($resultado['porcentaje']) && $resultado['porcentaje'] >= 70) ? 'success' : 'warning'; ?>">
                                                        <?php echo isset($resultado['puntaje_obtenido']) ? $resultado['puntaje_obtenido'] : '0'; ?>/<?php echo isset($resultado['puntaje_total']) ? $resultado['puntaje_total'] : '0'; ?>
                                                        (<?php echo isset($resultado['porcentaje']) ? $resultado['porcentaje'] : '0'; ?>%)
                                                    </span>
                                                </div>
                                                <div class="col-md-6">
                                                    <small class="text-muted">
                                                        Completado: <?php echo isset($resultado['fecha_respuesta']) ? date('d/m/Y H:i', strtotime($resultado['fecha_respuesta'])) : 'Fecha desconocida'; ?>
                                                    </small>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Script para copiar enlaces al portapapeles
        document.addEventListener('DOMContentLoaded', function() {
            const copyButtons = document.querySelectorAll('.copy-link');
            
            copyButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    const link = `http://localhost/proyectos/cuestionario-backend/linksystem.php?id=${id}`;
                    
                    // Crear un elemento temporal para copiar el texto
                    const tempInput = document.createElement('input');
                    tempInput.value = link;
                    document.body.appendChild(tempInput);
                    tempInput.select();
                    document.execCommand('copy');
                    document.body.removeChild(tempInput);
                    
                    // Cambiar el texto del botón temporalmente para dar feedback
                    const originalText = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-check"></i> ¡Copiado!';
                    
                    setTimeout(() => {
                        this.innerHTML = originalText;
                    }, 2000);
                });
            });
        });
    </script>
</body>

</html>