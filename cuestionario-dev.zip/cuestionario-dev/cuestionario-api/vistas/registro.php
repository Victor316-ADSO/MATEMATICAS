<?php
include 'controller/registro_controller.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Sistema de Cuestionarios</title>
    <link rel="icon" type="image/png" href="./resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="./resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="./resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="./resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="/site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Registro de Usuario</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($mensaje): ?>
                            <div class="alert alert-success"><?php echo $mensaje; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" id="registroForm">
                            <div class="mb-3">
                                <label for="nombre" class="form-label">Nombre Completo</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" required>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="text" class="form-control" id="email" name="email" required>
                            </div>

                            <div class="mb-3">
                                <label for="identificacion" class="form-label">Identificación</label>
                                <input type="text" class="form-control" id="identificacion" name="identificacion" required>
                            </div>

                            <div class="mb-3">
                                <label for="programa_id" class="form-label">Programa</label>
                                <select class="form-select" id="programa_id" name="programa_id" required>
                                    <option value="">Selecciona un programa</option>
                                    <?php foreach ($programas as $programa): ?>
                                        <option value="<?php echo $programa['id']; ?>"><?php echo $programa['nombre']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Contraseña</label>
                                <input type="password" class="form-control" id="password" name="password" required minlength="8">
                                <div class="form-text">La contraseña debe tener al menos 8 caracteres.</div>
                            </div>

                            <div class="mb-3">
                                <label for="confirmar_password" class="form-label">Confirmar Contraseña</label>
                                <input type="password" class="form-control" id="confirmar_password" name="confirmar_password" required minlength="8">
                            </div>

                            

                            <button type="submit" class="btn btn-primary w-100">Registrarse</button>
                        </form>
                        
                        <div class="text-center mt-3">
                            <p>¿Ya tienes cuenta? <a href="login.php">Inicia sesión aquí</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.getElementById('registroForm').addEventListener('submit', function(event) {
        const password = document.getElementById('password').value;
        const confirmarPassword = document.getElementById('confirmar_password').value;
        const programaId = document.getElementById('programa_id').value;
        
        if (password.length < 8) {
            alert('La contraseña debe tener al menos 8 caracteres');
            event.preventDefault();
            return false;
        }
        
        if (password !== confirmarPassword) {
            alert('Las contraseñas no coinciden');
            event.preventDefault();
            return false;
        }
        
        if (!programaId) {
            alert('Debes seleccionar un programa');
            event.preventDefault();
            return false;
        }
        
        return true;
    });
    </script>
</body>
</html>