<?php
include 'controller/linksystem_controller.php';
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validacion de datos</title>
    <link rel="icon" type="image/png" href="./resource/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="./resource/favicon/favicon.svg" />
    <link rel="shortcut icon" href="./resource/favicon/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="./resource/favicon/apple-touch-icon.png" />
    <meta name="apple-mobile-web-app-title" content="Cuestionario" />
    <link rel="manifest" href="/site.cuestionario" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Verificar datos</h3>
                    </div>
                    <!-- <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?> -->

                        <form method="POST">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="text" class="form-control" id="email" name="email" required>
                            </div>
                            <!-- <div class="mb-3">
                                <label for="email" class="form-label">Nombre y Apellido</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" required>
                            </div> -->
                            <div class="mb-3">
                                <label for="password" class="form-label">Documento</label>
                                <input type="text" class="form-control" id="documento" name="documento" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Realizar cuestionario</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
