<?php

// URL base del frontend React
define('FRONTEND_URL', 'http://localhost:5173');

// URLs específicas
function getUrlCuestionario($id) {
    return FRONTEND_URL . "/realizar-cuestionario/" . $id;
}

function getUrlLinksystem($id) {
    return FRONTEND_URL . "/linksystem?id=" . $id;
}

function getUrlResultado($id) {
    return FRONTEND_URL . "/resultado/" . $id;
}

function getUrlDashboard() {
    return FRONTEND_URL . "/dashboard";
}

function getUrlLogin() {
    return FRONTEND_URL . "/login";
} 