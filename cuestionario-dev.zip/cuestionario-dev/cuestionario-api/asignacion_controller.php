<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

require_once './model/conection.php';

// Crear conexión a la base de datos
$database = new Database();
$conn = $database->connect();

// Procesar eliminación de asignación
if (isset($_GET['eliminar']) && is_numeric($_GET['eliminar'])) {
    $id_asignacion = $_GET['eliminar'];
    
    // Verificar que la asignación pertenezca al docente actual
    $sql_verificar = "SELECT a.id 
                     FROM asignacion a
                     JOIN apertura ap ON a.id_apertura = ap.id
                     JOIN relacion_cuestionario_programa rcp ON ap.id_relacion_cuestionario_programa = rcp.id
                     WHERE a.id = ? AND rcp.id_docente = ?";
    
    $stmt = $conn->prepare($sql_verificar);
    $stmt->bindParam(1, $id_asignacion, PDO::PARAM_INT);
    $stmt->bindParam(2, $_SESSION['usuario_id'], PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        // La asignación existe y pertenece al docente
        $sql_eliminar = "DELETE FROM asignacion WHERE id = ?";
        $stmt = $conn->prepare($sql_eliminar);
        $stmt->bindParam(1, $id_asignacion, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            $mensaje = "Asignación eliminada con éxito.";
            $tipo_mensaje = "success";
        } else {
            $mensaje = "Error al eliminar la asignación.";
            $tipo_mensaje = "danger";
        }
    } else {
        $mensaje = "No tiene permisos para eliminar esta asignación o no existe.";
        $tipo_mensaje = "warning";
    }
}

// Obtener aperturas de cuestionarios disponibles
$sql_aperturas = "SELECT a.id, c.titulo, c.descripcion, p.nombre as periodo_nombre, 
                 p.fecha_inicio, p.fecha_fin, pr.nombre as programa_nombre
                 FROM apertura a
                 JOIN relacion_cuestionario_programa rcp ON a.id_relacion_cuestionario_programa = rcp.id
                 JOIN cuestionario c ON rcp.id_cuestionario = c.id
                 JOIN periodo p ON a.id_periodo = p.id
                 JOIN programa pr ON rcp.id_programa = pr.id
                 WHERE rcp.id_docente = :docente_id";

$stmt = $conn->prepare($sql_aperturas);
$stmt->bindParam(':docente_id', $_SESSION['usuario_id'], PDO::PARAM_INT);
$stmt->execute();
$aperturas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Verificar si la variable de sesión usuario_programa existe
$programa_docente = isset($_SESSION['usuario_programa']) ? $_SESSION['usuario_programa'] : null;

// Obtener estudiantes que pertenecen al mismo programa que el docente
// Si es admin o no tiene programa asignado, muestra todos los estudiantes
$es_admin = ($_SESSION['usuario_email'] === 'admin');

if ($es_admin || $programa_docente === null) {
    $sql_estudiantes = "SELECT e.id, e.nombre, e.email, e.identificacion, p.nombre as programa_nombre
                      FROM estudiante e
                      JOIN programa p ON e.id_programa = p.id
                      ORDER BY e.nombre";
    $stmt = $conn->prepare($sql_estudiantes);
} else {
    $sql_estudiantes = "SELECT e.id, e.nombre, e.email, e.identificacion, p.nombre as programa_nombre
                      FROM estudiante e
                      JOIN programa p ON e.id_programa = p.id
                      WHERE e.id_programa = :programa_id
                      ORDER BY e.nombre";
    $stmt = $conn->prepare($sql_estudiantes);
    $stmt->bindParam(':programa_id', $programa_docente, PDO::PARAM_INT);
}

$stmt->execute();
$estudiantes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Procesar la asignación si se envía el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Depuración
    error_log("POST recibido: " . print_r($_POST, true));
    
    if (isset($_POST['asignar'])) {
        $apertura_id = $_POST['apertura_id'];
        $estudiante_ids = isset($_POST['estudiante_ids']) ? $_POST['estudiante_ids'] : [];
        
        // Depuración
        error_log("Apertura ID: " . $apertura_id);
        error_log("Estudiantes seleccionados: " . print_r($estudiante_ids, true));
        
        if (!empty($estudiante_ids) && !empty($apertura_id)) {
            // Preparar la consulta para insertar asignaciones
            $stmt = $conn->prepare("INSERT IGNORE INTO asignacion (id_apertura, id_estudiante) VALUES (:apertura_id, :estudiante_id)");
            
            $exito = true;
            $conn->beginTransaction();
            
            try {
                foreach ($estudiante_ids as $estudiante_id) {
                    $stmt->bindParam(':apertura_id', $apertura_id, PDO::PARAM_INT);
                    $stmt->bindParam(':estudiante_id', $estudiante_id, PDO::PARAM_INT);
                    $stmt->execute();
                }
                
                $conn->commit();
                $mensaje = "Asignación realizada con éxito.";
                $tipo_mensaje = "success";
            } catch (PDOException $e) {
                $conn->rollBack();
                $mensaje = "Error al realizar las asignaciones: " . $e->getMessage();
                $tipo_mensaje = "danger";
                $exito = false;
            }
        } else {
            $mensaje = "Debe seleccionar al menos un estudiante y un cuestionario.";
            $tipo_mensaje = "warning";
        }
    } elseif (isset($_POST['importar_estudiantes']) && isset($_FILES['archivo_estudiantes'])) {
        // Procesar archivo CSV de estudiantes
        $archivo = $_FILES['archivo_estudiantes'];
        
        // Depuración
        error_log("Archivo recibido: " . print_r($archivo, true));
        
        // Verificar si el archivo es CSV o tiene otro tipo MIME aceptable
        $tipos_aceptados = ['text/csv', 'application/vnd.ms-excel', 'text/plain', 'application/octet-stream'];
        
        if ($archivo['error'] === UPLOAD_ERR_OK && (in_array($archivo['type'], $tipos_aceptados) || pathinfo($archivo['name'], PATHINFO_EXTENSION) === 'csv')) {
            $handle = fopen($archivo['tmp_name'], "r");
            
            if ($handle !== FALSE) {
                // Preparar la consulta para insertar estudiantes
                $stmt = $conn->prepare("INSERT INTO estudiante (nombre, email, identificacion, id_programa) 
                                      VALUES (:nombre, :email, :identificacion, :programa_id) 
                                      ON DUPLICATE KEY UPDATE nombre = VALUES(nombre)");
                
                $contador = 0;
                $errores = [];
                
                // Intentar detectar el delimitador
                $primera_linea = fgets($handle);
                rewind($handle);
                
                $delimitador = ';'; // Delimitador por defecto
                if (strpos($primera_linea, ',') !== false && strpos($primera_linea, ';') === false) {
                    $delimitador = ',';
                }
                
                error_log("Usando delimitador: " . $delimitador);
                
                // Saltar la primera línea (encabezados)
                fgetcsv($handle, 1000, $delimitador);
                
                $conn->beginTransaction();
                
                try {
                    while (($data = fgetcsv($handle, 1000, $delimitador)) !== FALSE) {
                        error_log("Fila leída: " . print_r($data, true));
                        
                        if (count($data) >= 4) {
                            $nombre = trim($data[0]);
                            $email = trim($data[1]);
                            $identificacion = trim($data[2]);
                            $programa_id = trim($data[3]);
                            
                            if (empty($nombre) || empty($email) || empty($identificacion) || empty($programa_id)) {
                                $errores[] = "Fila con datos incompletos: " . implode(", ", $data);
                                continue;
                            }
                            
                            $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
                            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
                            $stmt->bindParam(':identificacion', $identificacion, PDO::PARAM_STR);
                            $stmt->bindParam(':programa_id', $programa_id, PDO::PARAM_INT);
                            
                            try {
                                $stmt->execute();
                                
                                if ($stmt->rowCount() > 0) {
                                    $contador++;
                                }
                            } catch (PDOException $e) {
                                $errores[] = "Error en fila: " . implode(", ", $data) . " - " . $e->getMessage();
                                error_log("Error al insertar estudiante: " . $e->getMessage());
                            }
                        } else {
                            $errores[] = "Fila con formato incorrecto: " . implode(", ", $data);
                        }
                    }
                    
                    $conn->commit();
                    $mensaje = "Se importaron $contador estudiantes correctamente.";
                    if (!empty($errores)) {
                        $mensaje .= " Hubo " . count($errores) . " errores. " . print_r($errores, true);
                        error_log("Errores de importación: " . print_r($errores, true));
                    }
                    $tipo_mensaje = "success";
                } catch (PDOException $e) {
                    $conn->rollBack();
                    $mensaje = "Error al importar estudiantes: " . $e->getMessage();
                    $tipo_mensaje = "danger";
                    error_log("Error de transacción: " . $e->getMessage());
                }
                
                fclose($handle);
                
                // Actualizar la lista de estudiantes
                $stmt = $conn->prepare($sql_estudiantes);
                $stmt->execute();
                $estudiantes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } else {
                $mensaje = "Error al abrir el archivo.";
                $tipo_mensaje = "danger";
                error_log("No se pudo abrir el archivo: " . $archivo['tmp_name']);
            }
        } else {
            $mensaje = "El archivo debe ser de tipo CSV. Tipo detectado: " . $archivo['type'];
            $tipo_mensaje = "warning";
            error_log("Tipo de archivo no aceptado: " . $archivo['type']);
        }
    }
}

// Obtener asignaciones existentes
$sql_asignaciones = "SELECT a.id, a.id_apertura, a.id_estudiante, 
                    e.nombre as estudiante_nombre, e.email,
                    c.titulo as cuestionario_titulo, p.nombre as periodo_nombre
                    FROM asignacion a
                    JOIN estudiante e ON a.id_estudiante = e.id
                    JOIN apertura ap ON a.id_apertura = ap.id
                    JOIN relacion_cuestionario_programa rcp ON ap.id_relacion_cuestionario_programa = rcp.id
                    JOIN cuestionario c ON rcp.id_cuestionario = c.id
                    JOIN periodo p ON ap.id_periodo = p.id
                    WHERE rcp.id_docente = :docente_id";

$stmt = $conn->prepare($sql_asignaciones);
$stmt->bindParam(':docente_id', $_SESSION['usuario_id'], PDO::PARAM_INT);
$stmt->execute();
$asignaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
