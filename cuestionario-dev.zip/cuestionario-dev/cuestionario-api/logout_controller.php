<?php
// ==== CORS HEADERS ====
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// ==== PREVENT OPTIONS ====
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// ==== ERRORES ====
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// ==== INICIAR SESIÓN ====
session_start();

// Registrar información de depuración
error_log("Logout iniciado - Session ID: " . session_id());
error_log("Datos de sesión antes de logout: " . print_r($_SESSION, true));

// ==== DESTRUIR SESIÓN ====
// Eliminar todas las variables de sesión
$_SESSION = array();

// Eliminar la cookie de sesión si existe
if (isset($_COOKIE[session_name()])) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
    error_log("Cookie de sesión eliminada");
}

// Destruir la sesión
session_destroy();
error_log("Sesión destruida");

// ==== RESPUESTA ====
echo json_encode([
    'success' => true,
    'message' => 'Sesión cerrada correctamente'
]);
exit();
?>