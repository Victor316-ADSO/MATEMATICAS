<?php
// Limpiar cualquier salida previa y prevenir salida HTML accidental
while (ob_get_level() > 0) {
    ob_end_clean();
}
ob_start();

// Asegurar que siempre se envíe contenido JSON
header('Content-Type: application/json; charset=utf-8');

// Manejar errores fatales
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Error interno del servidor',
            'redirect' => '/linksystem'
        ], JSON_UNESCAPED_UNICODE);
    }
});

require_once dirname(__DIR__) . '/model/conection.php';

// Headers CORS
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: " . $_SERVER['HTTP_ORIGIN']);
} else {
    header("Access-Control-Allow-Origin: http://localhost:5173");
}
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");

// Manejar peticiones OPTIONS (preflight)
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Verificar si ya hay sesión activa antes de iniciar
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Log de depuración
file_put_contents(__DIR__ . "/debug_resolver.txt", 
    "Request Method: " . (isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'CLI') . "\n" .
    "Session ID: " . session_id() . "\n" .
    "Session Data: " . json_encode($_SESSION) . "\n" .
    "Cookie Header: " . (isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : 'No cookie') . "\n",
    FILE_APPEND
);

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    // Limpiar completamente el buffer de salida
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    $response = [
        'success' => false,
        'error' => 'Sesión no iniciada - debes iniciar sesión como estudiante',
        'redirect' => '/linksystem'
    ];
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit();
}

// Verificar si es estudiante
if (!isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] !== 'estudiante') {
    http_response_code(403);
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    $response = [
        'success' => false,
        'error' => 'Acceso no autorizado - solo estudiantes pueden acceder',
        'redirect' => '/linksystem'
    ];
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit();
}

$db = Conection::conectar();

$cuestionario_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Debug adicional
file_put_contents(__DIR__ . "/debug_resolver.txt", 
    "Cuestionario ID: " . $cuestionario_id . "\n" .
    "GET Request para cargar cuestionario\n",
    FILE_APPEND
);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Verificar que el cuestionario existe y está activo (query simplificada)
        $query_cuestionario = "
            SELECT 
                c.id, 
                c.titulo, 
                c.descripcion,
                COALESCE(d.nombre, 'Sin asignar') as creador_nombre,
                COALESCE(pr.nombre, 'Sin asignar') as programa_nombre,
                COALESCE(n.nombre, 'Sin asignar') as nivel_nombre,
                COALESCE(ca.nombre, 'Sin asignar') as campus_nombre
            FROM 
                cuestionario c
            LEFT JOIN relacion_cuestionario_programa rcp ON c.id = rcp.id_cuestionario
            LEFT JOIN docente d ON rcp.id_docente = d.id
            LEFT JOIN programa pr ON rcp.id_programa = pr.id
            LEFT JOIN nivel n ON pr.id_nivel = n.id
            LEFT JOIN campus ca ON pr.id_campus = ca.id
            WHERE 
                c.id = :id 
            LIMIT 1
        ";

        file_put_contents(__DIR__ . "/debug_resolver.txt", 
            "Ejecutando query para cuestionario: " . $query_cuestionario . "\n",
            FILE_APPEND
        );

        $stmt_cuestionario = $db->prepare($query_cuestionario);
        $stmt_cuestionario->bindParam(':id', $cuestionario_id);
        $stmt_cuestionario->execute();

    if ($stmt_cuestionario->rowCount() == 0) {
        http_response_code(404);
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'error' => 'Cuestionario no encontrado'
        ]);
        exit();
    }

    $cuestionario = $stmt_cuestionario->fetch(PDO::FETCH_ASSOC);

    // Verificar si ya resolvió este cuestionario
    $query_verificar = "
        SELECT re.id 
        FROM respuesta_estudiante re
        WHERE re.id_estudiante = :usuario_id 
        AND re.id_cuestionario = :cuestionario_id
        LIMIT 1
    ";
    $stmt_verificar = $db->prepare($query_verificar);
    $stmt_verificar->bindParam(':usuario_id', $_SESSION['usuario_id']);
    $stmt_verificar->bindParam(':cuestionario_id', $cuestionario_id);
    $stmt_verificar->execute();

    if ($stmt_verificar->rowCount() > 0) {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'yaResuelto' => true
        ]);
        exit();
    }

    // Obtener preguntas y opciones (sin incluir datos binarios de imágenes)
    $query_preguntas = "
        SELECT 
            p.id as id,
            p.texto_pregunta,
            p.orden_pregunta,
            p.peso_pregunta,
            CASE WHEN p.imagen_pregunta IS NOT NULL THEN 1 ELSE 0 END as tiene_imagen_pregunta,
            o.id as opcion_id,
            o.texto_opcion,
            CASE WHEN o.imagen_opcion IS NOT NULL THEN 1 ELSE 0 END as tiene_imagen_opcion,
            o.orden as orden_opcion
        FROM preguntas p
        LEFT JOIN opcion_respuesta o ON p.id = o.id_pregunta
        WHERE p.id_cuestionario = :cuestionario_id
        ORDER BY p.orden_pregunta, o.orden
    ";
    $stmt_preguntas = $db->prepare($query_preguntas);
    $stmt_preguntas->bindParam(':cuestionario_id', $cuestionario_id);
    $stmt_preguntas->execute();

    $preguntas_raw = $stmt_preguntas->fetchAll(PDO::FETCH_ASSOC);
    $preguntas = [];

    foreach ($preguntas_raw as $row) {
        if (!isset($preguntas[$row['id']])) {
            $preguntas[$row['id']] = [
                'id' => $row['id'],
                'texto_pregunta' => $row['texto_pregunta'],
                'orden_pregunta' => $row['orden_pregunta'],
                'peso_pregunta' => $row['peso_pregunta'],
                'imagen_pregunta' => $row['tiene_imagen_pregunta'] ? true : null,
                'opciones' => []
            ];
        }
        
        if ($row['opcion_id']) {
            $preguntas[$row['id']]['opciones'][] = [
                'id' => $row['opcion_id'],
                'texto_opcion' => $row['texto_opcion'],
                'imagen_opcion' => $row['tiene_imagen_opcion'] ? true : null,
                'orden' => $row['orden_opcion']
            ];
        }
    }

    // Convertir el array asociativo a array indexado
    $preguntas_array = array_values($preguntas);

    file_put_contents(__DIR__ . "/debug_resolver.txt", 
        "Respuesta exitosa - Cuestionario: " . $cuestionario['titulo'] . ", Preguntas: " . count($preguntas_array) . "\n",
        FILE_APPEND
    );

    // Limpiar completamente el buffer y enviar respuesta
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // Asegurar que no hay salida previa
    header('Content-Type: application/json');
    
    $response = json_encode([
        'success' => true,
        'cuestionario' => $cuestionario,
        'preguntas' => $preguntas_array
    ]);
    
    file_put_contents(__DIR__ . "/debug_resolver.txt", 
        "JSON generado: " . substr($response, 0, 100) . "...\n",
        FILE_APPEND
    );
    
    echo $response;
    exit();
    
    } catch (Exception $e) {
        file_put_contents(__DIR__ . "/debug_resolver.txt", 
            "Error en GET: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n",
            FILE_APPEND
        );
        
        http_response_code(500);
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'error' => 'Error interno del servidor',
            'debug' => $e->getMessage()
        ]);
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Inicializar respuestas como array vacío si no se proporciona
    if (!isset($data['respuestas']) || !is_array($data['respuestas'])) {
        $data['respuestas'] = [];
    }
    
    $es_timeout = isset($data['timeout']) && $data['timeout'] === true;

    try {
        $db->beginTransaction();
        
        // Buscar o crear apertura
        $query_apertura = "
            SELECT a.id 
            FROM apertura a
            JOIN relacion_cuestionario_programa rcp ON a.id_relacion_cuestionario_programa = rcp.id
            WHERE rcp.id_cuestionario = :cuestionario_id
            LIMIT 1
        ";
        $stmt_apertura = $db->prepare($query_apertura);
        $stmt_apertura->bindParam(':cuestionario_id', $cuestionario_id);
        $stmt_apertura->execute();
        
        if ($stmt_apertura->rowCount() > 0) {
            $apertura = $stmt_apertura->fetch();
            $apertura_id = $apertura['id'];
        } else {
            // Crear apertura con el periodo actual
            $query_periodo = "SELECT id FROM periodo WHERE NOW() BETWEEN fecha_inicio AND fecha_fin LIMIT 1";
            $stmt_periodo = $db->prepare($query_periodo);
            $stmt_periodo->execute();
            
            if ($stmt_periodo->rowCount() > 0) {
                $periodo = $stmt_periodo->fetch();
                $periodo_id = $periodo['id'];
            } else {
                throw new Exception("No hay periodo activo");
            }
            
            // Obtener relacion_id
            $query_relacion = "SELECT id FROM relacion_cuestionario_programa WHERE id_cuestionario = :cuestionario_id LIMIT 1";
            $stmt_relacion = $db->prepare($query_relacion);
            $stmt_relacion->bindParam(':cuestionario_id', $cuestionario_id);
            $stmt_relacion->execute();
            
            if ($stmt_relacion->rowCount() == 0) {
                throw new Exception("No se encontró la relación del cuestionario");
            }
            
            $relacion = $stmt_relacion->fetch();
            
            // Crear apertura
            $query_nueva_apertura = "
                INSERT INTO apertura (id_periodo, id_relacion_cuestionario_programa) 
                VALUES (:id_periodo, :id_relacion)
            ";
            $stmt_nueva_apertura = $db->prepare($query_nueva_apertura);
            $stmt_nueva_apertura->bindParam(':id_periodo', $periodo_id);
            $stmt_nueva_apertura->bindParam(':id_relacion', $relacion['id']);
            $stmt_nueva_apertura->execute();
            
            $apertura_id = $db->lastInsertId();
        }
        
        // Crear asignación
        $query_asignacion = "
            INSERT INTO asignacion (id_apertura, id_estudiante)
            VALUES (:id_apertura, :id_estudiante)
            ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)
        ";
        $stmt_asignacion = $db->prepare($query_asignacion);
        $stmt_asignacion->bindParam(':id_apertura', $apertura_id);
        $stmt_asignacion->bindParam(':id_estudiante', $_SESSION['usuario_id']);
        $stmt_asignacion->execute();
        
        if ($es_timeout) {
            // CASO ESPECIAL: TIMEOUT - Solo guardar las respuestas que existen
            // No crear registros para las no respondidas, el frontend las manejará
            
            if (!empty($data['respuestas'])) {
                foreach ($data['respuestas'] as $pregunta_id => $opcion_id) {
                    $query_respuesta = "
                        INSERT INTO respuesta_estudiante (
                            id_estudiante, 
                            id_cuestionario, 
                            id_pregunta, 
                            id_opcion_seleccionada, 
                            fecha_respuesta
                        ) VALUES (
                            :id_estudiante,
                            :id_cuestionario,
                            :id_pregunta,
                            :id_opcion,
                            NOW()
                        )
                    ";
                    $stmt_respuesta = $db->prepare($query_respuesta);
                    $stmt_respuesta->bindParam(':id_estudiante', $_SESSION['usuario_id']);
                    $stmt_respuesta->bindParam(':id_cuestionario', $cuestionario_id);
                    $stmt_respuesta->bindParam(':id_pregunta', $pregunta_id);
                    $stmt_respuesta->bindParam(':id_opcion', $opcion_id);
                    $stmt_respuesta->execute();
                }
            }
            
            // Crear un registro mínimo para indicar que se intentó el cuestionario por timeout
            // Solo si no existe ningún registro previo
            $query_verificar_intento = "SELECT id FROM respuesta_estudiante WHERE id_estudiante = :usuario_id AND id_cuestionario = :cuestionario_id LIMIT 1";
            $stmt_verificar_intento = $db->prepare($query_verificar_intento);
            $stmt_verificar_intento->bindParam(':usuario_id', $_SESSION['usuario_id']);
            $stmt_verificar_intento->bindParam(':cuestionario_id', $cuestionario_id);
            $stmt_verificar_intento->execute();
            
            if ($stmt_verificar_intento->rowCount() == 0) {
                // Crear un registro especial para marcar el intento por timeout
                $query_primera_pregunta = "SELECT id FROM preguntas WHERE id_cuestionario = :cuestionario_id ORDER BY orden_pregunta LIMIT 1";
                $stmt_primera = $db->prepare($query_primera_pregunta);
                $stmt_primera->bindParam(':cuestionario_id', $cuestionario_id);
                $stmt_primera->execute();
                
                if ($stmt_primera->rowCount() > 0) {
                    $primera_pregunta = $stmt_primera->fetch();
                    
                    // Crear opción especial para marcar intento por timeout
                    $query_crear_opcion_timeout = "
                        INSERT IGNORE INTO opcion_respuesta (
                            id_pregunta, 
                            texto_opcion, 
                            opcion_correcta, 
                            orden
                        ) VALUES (
                            :id_pregunta,
                            'INTENTO_TIMEOUT',
                            0,
                            999
                        )
                    ";
                    $stmt_opcion_timeout = $db->prepare($query_crear_opcion_timeout);
                    $stmt_opcion_timeout->bindParam(':id_pregunta', $primera_pregunta['id']);
                    $stmt_opcion_timeout->execute();
                    
                    // Obtener el ID de la opción especial
                    $query_obtener_opcion = "SELECT id FROM opcion_respuesta WHERE id_pregunta = :id_pregunta AND texto_opcion = 'INTENTO_TIMEOUT'";
                    $stmt_obtener = $db->prepare($query_obtener_opcion);
                    $stmt_obtener->bindParam(':id_pregunta', $primera_pregunta['id']);
                    $stmt_obtener->execute();
                    $opcion_especial = $stmt_obtener->fetch();
                    
                    // Crear el registro de intento por timeout
                    $query_intento_timeout = "
                        INSERT INTO respuesta_estudiante (
                            id_estudiante, 
                            id_cuestionario, 
                            id_pregunta, 
                            id_opcion_seleccionada, 
                            fecha_respuesta
                        ) VALUES (
                            :id_estudiante,
                            :id_cuestionario,
                            :id_pregunta,
                            :id_opcion,
                            NOW()
                        )
                    ";
                    $stmt_intento = $db->prepare($query_intento_timeout);
                    $stmt_intento->bindParam(':id_estudiante', $_SESSION['usuario_id']);
                    $stmt_intento->bindParam(':id_cuestionario', $cuestionario_id);
                    $stmt_intento->bindParam(':id_pregunta', $primera_pregunta['id']);
                    $stmt_intento->bindParam(':id_opcion', $opcion_especial['id']);
                    $stmt_intento->execute();
                }
            }
        } else {
            // CASO NORMAL: Envío manual - solo guardar las respuestas que existen
            
            // Guardar respuestas (solo si hay respuestas para guardar)
            if (!empty($data['respuestas'])) {
                foreach ($data['respuestas'] as $pregunta_id => $opcion_id) {
                    $query_respuesta = "
                        INSERT INTO respuesta_estudiante (
                            id_estudiante, 
                            id_cuestionario, 
                            id_pregunta, 
                            id_opcion_seleccionada, 
                            fecha_respuesta
                        ) VALUES (
                            :id_estudiante,
                            :id_cuestionario,
                            :id_pregunta,
                            :id_opcion,
                            NOW()
                        )
                    ";
                    $stmt_respuesta = $db->prepare($query_respuesta);
                    $stmt_respuesta->bindParam(':id_estudiante', $_SESSION['usuario_id']);
                    $stmt_respuesta->bindParam(':id_cuestionario', $cuestionario_id);
                    $stmt_respuesta->bindParam(':id_pregunta', $pregunta_id);
                    $stmt_respuesta->bindParam(':id_opcion', $opcion_id);
                    $stmt_respuesta->execute();
                }
            } else {
                // Si no hay respuestas en envío manual, crear un registro mínimo
                $query_primera_pregunta = "SELECT id FROM preguntas WHERE id_cuestionario = :cuestionario_id ORDER BY orden_pregunta LIMIT 1";
                $stmt_primera = $db->prepare($query_primera_pregunta);
                $stmt_primera->bindParam(':cuestionario_id', $cuestionario_id);
                $stmt_primera->execute();
                
                if ($stmt_primera->rowCount() > 0) {
                    $primera_pregunta = $stmt_primera->fetch();
                    
                    // Verificar si ya existe un registro para este estudiante y cuestionario
                    $query_verificar = "SELECT id FROM respuesta_estudiante WHERE id_estudiante = :usuario_id AND id_cuestionario = :cuestionario_id LIMIT 1";
                    $stmt_verificar = $db->prepare($query_verificar);
                    $stmt_verificar->bindParam(':usuario_id', $_SESSION['usuario_id']);
                    $stmt_verificar->bindParam(':cuestionario_id', $cuestionario_id);
                    $stmt_verificar->execute();
                    
                    if ($stmt_verificar->rowCount() == 0) {
                        // Crear una opción especial para intento sin respuestas
                        $query_crear_opcion_especial = "
                            INSERT IGNORE INTO opcion_respuesta (
                                id_pregunta, 
                                texto_opcion, 
                                opcion_correcta, 
                                orden
                            ) VALUES (
                                :id_pregunta,
                                'SIN_RESPUESTA_INTENTO',
                                0,
                                999
                            )
                        ";
                        $stmt_opcion_especial = $db->prepare($query_crear_opcion_especial);
                        $stmt_opcion_especial->bindParam(':id_pregunta', $primera_pregunta['id']);
                        $stmt_opcion_especial->execute();
                        
                        // Obtener el ID de la opción especial
                        $query_obtener_opcion = "SELECT id FROM opcion_respuesta WHERE id_pregunta = :id_pregunta AND texto_opcion = 'SIN_RESPUESTA_INTENTO'";
                        $stmt_obtener = $db->prepare($query_obtener_opcion);
                        $stmt_obtener->bindParam(':id_pregunta', $primera_pregunta['id']);
                        $stmt_obtener->execute();
                        $opcion_especial = $stmt_obtener->fetch();
                        
                        // Crear el registro de intento
                        $query_registro_intento = "
                            INSERT INTO respuesta_estudiante (
                                id_estudiante, 
                                id_cuestionario, 
                                id_pregunta, 
                                id_opcion_seleccionada, 
                                fecha_respuesta
                            ) VALUES (
                                :id_estudiante,
                                :id_cuestionario,
                                :id_pregunta,
                                :id_opcion,
                                NOW()
                            )
                        ";
                        $stmt_intento = $db->prepare($query_registro_intento);
                        $stmt_intento->bindParam(':id_estudiante', $_SESSION['usuario_id']);
                        $stmt_intento->bindParam(':id_cuestionario', $cuestionario_id);
                        $stmt_intento->bindParam(':id_pregunta', $primera_pregunta['id']);
                        $stmt_intento->bindParam(':id_opcion', $opcion_especial['id']);
                        $stmt_intento->execute();
                    }
                }
            }
        }
        
        $db->commit();
        ob_clean(); // Limpiar buffer antes de enviar JSON
        echo json_encode(['success' => true]);
        
    } catch (Exception $e) {
        $db->rollBack();
        http_response_code(500);
        ob_clean(); // Limpiar buffer antes de enviar JSON
        echo json_encode(['error' => $e->getMessage()]);
        
        // Log del error para debug
        file_put_contents(__DIR__ . "/debug_resolver.txt", 
            "Error en POST: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n",
            FILE_APPEND
        );
    }
    exit();
}

// Método no permitido
http_response_code(405);
while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: application/json; charset=utf-8');
$response = [
    'success' => false,
    'error' => 'Método no permitido',
    'method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
    'cuestionario_id' => $_GET['id'] ?? 'no id'
];
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit(); 