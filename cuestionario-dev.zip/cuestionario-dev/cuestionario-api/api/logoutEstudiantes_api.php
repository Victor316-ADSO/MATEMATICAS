<?php
// Configuración de errores
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Iniciar sesión
session_start();

// Log de depuración
error_log("Logout request received");
error_log("Session before logout: " . print_r($_SESSION, true));
error_log("Request method: " . $_SERVER['REQUEST_METHOD']);

// Configuración de CORS
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

// Si es una solicitud OPTIONS (preflight), terminar aquí
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

try {
    // Verificar que sea una solicitud POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Método no permitido");
    }

    // Obtener el body de la solicitud
    $jsonData = json_decode(file_get_contents('php://input'), true);
    error_log("Request body: " . print_r($jsonData, true));

    // Solo proceder con el logout si es una solicitud explícita
    if (isset($jsonData['action']) && $jsonData['action'] === 'logout') {
        // Limpiar todas las variables de sesión
        $_SESSION = array();

        // Destruir la cookie de sesión si existe
        if (isset($_COOKIE[session_name()])) {
            setcookie(session_name(), '', time() - 3600, '/');
        }

        // Destruir la sesión
        session_destroy();
        
        error_log("Session destroyed successfully");
    } else {
        error_log("Logout skipped - no explicit action requested");
    }

    echo json_encode([
        'success' => true,
        'message' => 'Operación completada correctamente'
    ]);

} catch (Exception $e) {
    error_log("Error en logoutEstudiantes_api.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} 