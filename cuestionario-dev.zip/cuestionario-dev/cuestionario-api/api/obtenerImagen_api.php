<?php
// Configuración de errores
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Iniciar sesión
session_start();

// Incluir dependencias
require_once __DIR__ . '/../api/api.php';
require_once __DIR__ . '/../model/conection.php';

try {
    // Verificar si hay sesión activa (requerido para acceder a imágenes)
    if (!isset($_SESSION['usuario_id'])) {
        // Para imágenes, es mejor devolver una imagen de error o 404 que JSON
        header('HTTP/1.1 404 Not Found');
        header('Content-Type: text/plain');
        echo 'Imagen no disponible - sesión requerida';
        exit();
    }
    
    // Validar parámetros
    $tipo = isset($_GET['tipo']) ? $_GET['tipo'] : null; // 'pregunta' o 'opcion'
    $id = isset($_GET['id']) ? intval($_GET['id']) : null;
    
    if (!$tipo || !$id) {
        throw new Exception('Parámetros incompletos');
    }
    
    if (!in_array($tipo, ['pregunta', 'opcion'])) {
        throw new Exception('Tipo de imagen no válido');
    }
    
    $db = Conection::conectar();
    
    // Preparar la consulta según el tipo
    if ($tipo === 'pregunta') {
        $query = "SELECT imagen_pregunta as imagen, nombre_imagen_pregunta as nombre 
                 FROM preguntas WHERE id = :id";
    } else {
        $query = "SELECT imagen_opcion as imagen, nombre_imagen_opcion as nombre 
                 FROM opcion_respuesta WHERE id = :id";
    }
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$resultado || !$resultado['imagen']) {
        throw new Exception('Imagen no encontrada');
    }
    
    // Obtener el tipo MIME basado en la extensión del archivo
    $extension = strtolower(pathinfo($resultado['nombre'], PATHINFO_EXTENSION));
    $mime_types = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif'
    ];
    
    $mime_type = isset($mime_types[$extension]) ? $mime_types[$extension] : 'application/octet-stream';
    
    // Enviar la imagen
    header('Content-Type: ' . $mime_type);
    header('Content-Length: ' . strlen($resultado['imagen']));
    echo $resultado['imagen'];
    
} catch (Exception $e) {
    error_log("Error en obtenerImagen_api.php: " . $e->getMessage());
    // Para APIs de imagen, devolver error HTTP en lugar de JSON
    header('HTTP/1.1 404 Not Found');
    header('Content-Type: text/plain');
    echo 'Error: ' . $e->getMessage();
} 