<?php

// --- CORS HEADERS ---
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// --- OPCIONAL: salta si es una solicitud preflight OPTIONS ---
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Ensure error reporting is properly configured
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Helper functions
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function json_response($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}

function check_session() {
    if (!isset($_SESSION['usuario_id'])) {
        json_response([
            'success' => false,
            'error' => 'Sesión no iniciada',
            'session_id' => session_id(),
            'session_data' => $_SESSION
        ], 401);
    }
    return true;
}

// Log session data for debugging
function log_session_data($context = '') {
    file_put_contents(__DIR__ . '/session_debug.log', 
        date('Y-m-d H:i:s') . " [$context]\n" .
        "Session ID: " . session_id() . "\n" .
        "Session Data: " . json_encode($_SESSION) . "\n" .
        "Request: " . (isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'CLI') . " " . (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : 'N/A') . "\n" .
        "----------------------------------------\n", 
        FILE_APPEND
    );
}

// Log session data on every request
log_session_data('api_request');

// Función para manejar solicitudes JSON
function handle_json_request() {
    $json = file_get_contents('php://input');
    if (!empty($json)) {
        return json_decode($json, true);
    }
    return null;
}
?>
