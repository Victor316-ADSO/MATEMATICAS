<?php
// Limpiar cualquier salida previa
while (ob_get_level() > 0) {
    ob_end_clean();
}
ob_start();

// Configuración de errores
error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once dirname(__FILE__) . '/cors.php';
require_once dirname(__FILE__) . '/../model/conection.php';

try {
    $db = Conection::conectar();
    
    // Obtener todos los programas
    $query = "SELECT id, nombre FROM programa ORDER BY nombre";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $programas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    ob_clean();
    http_response_code(200);
    echo json_encode([
        'status' => 'ok',
        'programas' => $programas
    ]);
    
} catch (Exception $e) {
    ob_clean();
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'mensaje' => 'Error al obtener programas'
    ]);
} 