<?php
// Asegurarnos de que no se haya enviado ningún output antes
ob_start();

// Para depuración
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Configuración de CORS y headers
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-Requested-With, Authorization");
header('Content-Type: application/json; charset=utf-8');

// Responder inmediatamente a las solicitudes OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(['success' => true]);
    exit();
}

// Función para manejar errores y devolver siempre JSON
function handleError($errno, $errstr, $errfile, $errline) {
    $error = [
        'success' => false,
        'error' => 'Error del servidor: ' . $errstr,
        'details' => [
            'file' => $errfile,
            'line' => $errline
        ]
    ];
    
    // Limpiar cualquier output previo
    if (ob_get_length()) ob_clean();
    
    // Asegurar headers JSON
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($error);
    exit(1);
}

// Establecer el manejador de errores
set_error_handler('handleError');

try {
    require_once __DIR__ . '/cors.php';
    require_once __DIR__ . '/../model/conection.php';

    // Verificar si el usuario está autenticado
    $usuario_id = isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : null;

    // Si no hay sesión, intentar obtener el usuario del localStorage a través de un parámetro
    if (!$usuario_id && isset($_GET['usuario_id'])) {
        $usuario_id = $_GET['usuario_id'];
    } else if (!$usuario_id && isset($_POST['usuario_id'])) {
        $usuario_id = $_POST['usuario_id'];
    }

    // Para desarrollo, si aún no hay usuario_id, usar un ID por defecto
    if (!$usuario_id) {
        $usuario_id = 3; // ID de usuario para desarrollo
    }
    
    // Log para depuración
    error_log("periodoManage_api.php - Usuario ID: " . $usuario_id);

    // Obtener el contenido JSON de la solicitud
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // Si hay usuario_id en los datos JSON, usarlo
    if (isset($data['usuario_id'])) {
        $usuario_id = $data['usuario_id'];
    }

    $conn = Conection::conectar();

    // Función para sanitizar input
    function sanitize_input($data) {
        return htmlspecialchars(strip_tags(trim($data)));
    }

    // Manejar la solicitud
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($data['action'])) {
            if ($data['action'] === 'create' || $data['action'] === 'edit') {
                // Validar datos requeridos
                if (!isset($data['nombre']) || !isset($data['fecha_inicio']) || !isset($data['fecha_fin'])) {
                    throw new Exception('Faltan datos requeridos');
                }

                // Sanitizar datos
                $nombre = sanitize_input($data['nombre']);
                $fecha_inicio = sanitize_input($data['fecha_inicio']);
                $fecha_fin = sanitize_input($data['fecha_fin']);

                if ($data['action'] === 'create') {
                    $query = "INSERT INTO periodo (nombre, fecha_inicio, fecha_fin) VALUES (:nombre, :fecha_inicio, :fecha_fin)";
                    $stmt = $conn->prepare($query);
                } else {
                    if (!isset($data['id'])) {
                        throw new Exception('ID requerido para editar');
                    }
                    $id = sanitize_input($data['id']);
                    $query = "UPDATE periodo SET nombre = :nombre, fecha_inicio = :fecha_inicio, fecha_fin = :fecha_fin WHERE id = :id";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':id', $id);
                }

                $stmt->bindParam(':nombre', $nombre);
                $stmt->bindParam(':fecha_inicio', $fecha_inicio);
                $stmt->bindParam(':fecha_fin', $fecha_fin);
                
                if (!$stmt->execute()) {
                    throw new Exception('Error en la operación de base de datos');
                }
                
                echo json_encode([
                    'success' => true, 
                    'message' => $data['action'] === 'create' ? 'Periodo creado correctamente' : 'Periodo actualizado correctamente'
                ]);
                
            } elseif ($data['action'] === 'delete') {
                if (!isset($data['id'])) {
                    throw new Exception('ID requerido para eliminar');
                }

                $id = sanitize_input($data['id']);
                
                // Verificar si el periodo está siendo utilizado
                $check_query = "SELECT COUNT(*) as count FROM apertura WHERE id_periodo = :id";
                $check_stmt = $conn->prepare($check_query);
                $check_stmt->bindParam(':id', $id);
                $check_stmt->execute();
                $result = $check_stmt->fetch();
                
                if ($result['count'] > 0) {
                    throw new Exception('No se puede eliminar el periodo porque está siendo utilizado');
                }

                $query = "DELETE FROM periodo WHERE id = :id";
                $stmt = $conn->prepare($query);
                $stmt->bindParam(':id', $id);
                
                if (!$stmt->execute()) {
                    throw new Exception('Error al eliminar el periodo');
                }
                
                echo json_encode(['success' => true, 'message' => 'Periodo eliminado correctamente']);
                
            } else {
                // Si no hay acción específica, devolver todos los periodos
                $query = "SELECT * FROM periodo ORDER BY fecha_inicio DESC";
                $stmt = $conn->prepare($query);
                $stmt->execute();
                $periodos = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode(['success' => true, 'periodos' => $periodos]);
            }
        } else {
            // Si no hay acción, devolver todos los periodos
            $query = "SELECT * FROM periodo ORDER BY fecha_inicio DESC";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $periodos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'periodos' => $periodos]);
        }
    } else {
        throw new Exception('Método no permitido');
    }
    
} catch (Exception $e) {
    // Limpiar cualquier output previo
    if (ob_get_length()) ob_clean();
    
    // Asegurar headers JSON
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

// Asegurarse de que todo el output sea enviado y limpiar el buffer
ob_end_flush(); 