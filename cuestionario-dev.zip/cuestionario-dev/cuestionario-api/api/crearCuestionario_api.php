<?php
// Asegurar que no se envíen errores PHP al navegador
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Iniciar sesión antes de cualquier salida
session_start();

// Configuración de CORS
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

// Si es una solicitud OPTIONS (preflight), terminar aquí
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// Incluir dependencias usando rutas absolutas
require_once __DIR__ . '/../api/api.php';
require_once __DIR__ . '/../model/conection.php';

try {
    $db = Conection::conectar();
    $db->beginTransaction();

    // Obtener datos: puede ser JSON o FormData
    $rawInput = file_get_contents('php://input');
    $jsonData = null;
    
    if (!empty($rawInput)) {
        $jsonData = json_decode($rawInput, true);
    }
    
    // Si no es JSON, usar $_POST (FormData) y reconstruir estructura
    if ($jsonData === null) {
        $jsonData = $_POST;
        
        // Reconstruir estructura de preguntas desde FormData
        if (!isset($jsonData['preguntas'])) {
            $jsonData['preguntas'] = [];
            
            // Buscar todas las preguntas en $_POST
            foreach ($_POST as $key => $value) {
                if (preg_match('/^preguntas\[(\d+)\]\[(\w+)\]$/', $key, $matches)) {
                    $preguntaIndex = intval($matches[1]);
                    $campo = $matches[2];
                    
                    if (!isset($jsonData['preguntas'][$preguntaIndex])) {
                        $jsonData['preguntas'][$preguntaIndex] = ['opciones' => []];
                    }
                    
                    $jsonData['preguntas'][$preguntaIndex][$campo] = $value;
                }
                // Buscar opciones
                elseif (preg_match('/^preguntas\[(\d+)\]\[opciones\]\[(\d+)\]\[(\w+)\]$/', $key, $matches)) {
                    $preguntaIndex = intval($matches[1]);
                    $opcionIndex = intval($matches[2]);
                    $campo = $matches[3];
                    
                    if (!isset($jsonData['preguntas'][$preguntaIndex])) {
                        $jsonData['preguntas'][$preguntaIndex] = ['opciones' => []];
                    }
                    
                    if (!isset($jsonData['preguntas'][$preguntaIndex]['opciones'][$opcionIndex])) {
                        $jsonData['preguntas'][$preguntaIndex]['opciones'][$opcionIndex] = [];
                    }
                    
                    $jsonData['preguntas'][$preguntaIndex]['opciones'][$opcionIndex][$campo] = $value;
                }
            }
            
            // Reindexar arrays para que sean secuenciales
            $jsonData['preguntas'] = array_values($jsonData['preguntas']);
            foreach ($jsonData['preguntas'] as &$pregunta) {
                $pregunta['opciones'] = array_values($pregunta['opciones']);
                
                // Convertir tipos
                if (isset($pregunta['peso'])) {
                    $pregunta['peso'] = floatval($pregunta['peso']);
                }
                if (isset($pregunta['correcta']) && $pregunta['correcta'] !== '') {
                    $pregunta['correcta'] = intval($pregunta['correcta']);
                }
            }
        }
    }
    
    // Convertir campos principales a tipos correctos
    if (isset($jsonData['programa_id'])) {
        $jsonData['programa_id'] = intval($jsonData['programa_id']);
    }
    if (isset($jsonData['id_docente'])) {
        $jsonData['id_docente'] = intval($jsonData['id_docente']);
    }
    
    // Debug: Log de datos recibidos (temporal)
    file_put_contents(__DIR__ . '/debug_crear_cuestionario.log', 
        date('Y-m-d H:i:s') . " - Datos recibidos: " . json_encode([
            'titulo' => $jsonData['titulo'] ?? 'no_definido',
            'descripcion' => $jsonData['descripcion'] ?? 'no_definido',
            'num_preguntas' => count($jsonData['preguntas'] ?? []),
            'tiene_archivos' => !empty($_FILES),
            'files_keys' => array_keys($_FILES),
            'post_keys' => array_keys($_POST),
            'files_completo' => $_FILES // Para ver la estructura completa
        ]) . "\n", FILE_APPEND);
    
    // Validar campos requeridos
    if (empty($jsonData['titulo'])) {
        throw new Exception("El título es requerido");
    }
    
    if (empty($jsonData['descripcion'])) {
        throw new Exception("La descripción es requerida");
    }
    
    if (empty($jsonData['preguntas']) || !is_array($jsonData['preguntas'])) {
        throw new Exception("Se requiere al menos una pregunta");
    }

    // Insertar cuestionario
    $query_cuestionario = "INSERT INTO cuestionario (titulo, descripcion) VALUES (:titulo, :descripcion)";
    $stmt_cuestionario = $db->prepare($query_cuestionario);
    $stmt_cuestionario->bindParam(':titulo', $jsonData['titulo']);
    $stmt_cuestionario->bindParam(':descripcion', $jsonData['descripcion']);
    $stmt_cuestionario->execute();
    $cuestionario_id = $db->lastInsertId();

    // Crear relación cuestionario-programa
    if (!empty($jsonData['programa_id'])) {
        $query_relacion = "INSERT INTO relacion_cuestionario_programa (id_cuestionario, id_programa, id_docente, activo) 
                          VALUES (:id_cuestionario, :id_programa, :id_docente, 1)";
        $stmt_relacion = $db->prepare($query_relacion);
        $stmt_relacion->bindParam(':id_cuestionario', $cuestionario_id);
        $stmt_relacion->bindParam(':id_programa', $jsonData['programa_id']);
        $stmt_relacion->bindParam(':id_docente', $jsonData['id_docente']);
        $stmt_relacion->execute();
    }

    // Insertar preguntas y opciones
    foreach ($jsonData['preguntas'] as $index => $pregunta) {
        // Validar pregunta
        if (empty($pregunta['texto'])) {
            throw new Exception("El texto de la pregunta " . ($index + 1) . " es requerido");
        }
        
        if (empty($pregunta['opciones']) || !is_array($pregunta['opciones']) || count($pregunta['opciones']) < 2) {
            throw new Exception("La pregunta " . ($index + 1) . " debe tener al menos 2 opciones");
        }

        if (!isset($pregunta['peso']) || !is_numeric($pregunta['peso']) || $pregunta['peso'] <= 0) {
            throw new Exception("El peso de la pregunta " . ($index + 1) . " debe ser un número mayor a 0");
        }

        // Procesar imagen de la pregunta si existe
        $imagen_pregunta = null;
        $nombre_imagen_pregunta = null;
        
        // Verificar si hay estructura de archivos anidada (FormData con arrays)
        if (isset($_FILES['preguntas']['tmp_name'][$index]['imagen']) && 
            $_FILES['preguntas']['error'][$index]['imagen'] === UPLOAD_ERR_OK) {
            
            $tmp_name = $_FILES['preguntas']['tmp_name'][$index]['imagen'];
            $name = $_FILES['preguntas']['name'][$index]['imagen'];
            $imagen_pregunta = file_get_contents($tmp_name);
            $nombre_imagen_pregunta = $name;
            
            // Debug imagen pregunta
            file_put_contents(__DIR__ . '/debug_crear_cuestionario.log', 
                date('Y-m-d H:i:s') . " - Imagen pregunta procesada desde estructura anidada: {$name}, tamaño: " . strlen($imagen_pregunta) . " bytes\n", FILE_APPEND);
        } else {
            // Fallback: buscar con la estructura tradicional
            $imagen_key = "preguntas[{$index}][imagen]";
            if (isset($_FILES[$imagen_key]) && $_FILES[$imagen_key]['error'] === UPLOAD_ERR_OK) {
                $archivo = $_FILES[$imagen_key];
                $imagen_pregunta = file_get_contents($archivo['tmp_name']);
                $nombre_imagen_pregunta = $archivo['name'];
                
                file_put_contents(__DIR__ . '/debug_crear_cuestionario.log', 
                    date('Y-m-d H:i:s') . " - Imagen pregunta procesada estructura tradicional: {$imagen_key}, tamaño: " . strlen($imagen_pregunta) . " bytes\n", FILE_APPEND);
            } else {
                file_put_contents(__DIR__ . '/debug_crear_cuestionario.log', 
                    date('Y-m-d H:i:s') . " - No hay imagen para pregunta {$index}\n", FILE_APPEND);
            }
        }

        // Insertar pregunta
        $query_pregunta = "INSERT INTO preguntas (id_cuestionario, texto_pregunta, orden_pregunta, peso_pregunta, imagen_pregunta, nombre_imagen_pregunta) 
                          VALUES (:id_cuestionario, :texto_pregunta, :orden_pregunta, :peso_pregunta, :imagen_pregunta, :nombre_imagen_pregunta)";
        $stmt_pregunta = $db->prepare($query_pregunta);
        $stmt_pregunta->bindParam(':id_cuestionario', $cuestionario_id);
        $stmt_pregunta->bindParam(':texto_pregunta', $pregunta['texto']);
        $stmt_pregunta->bindParam(':orden_pregunta', $index);
        $stmt_pregunta->bindParam(':peso_pregunta', $pregunta['peso']);
        $stmt_pregunta->bindParam(':imagen_pregunta', $imagen_pregunta, PDO::PARAM_LOB);
        $stmt_pregunta->bindParam(':nombre_imagen_pregunta', $nombre_imagen_pregunta);
        $stmt_pregunta->execute();
        $pregunta_id = $db->lastInsertId();

        // Insertar opciones
        foreach ($pregunta['opciones'] as $oIndex => $opcion) {
            // Validar opción
            if (empty($opcion['texto'])) {
                throw new Exception("El texto de la opción " . ($oIndex + 1) . " de la pregunta " . ($index + 1) . " es requerido");
            }

            // Procesar imagen de la opción si existe
            $imagen_opcion = null;
            $nombre_imagen_opcion = null;
            
            // Verificar si hay estructura de archivos anidada (FormData con arrays)
            if (isset($_FILES['preguntas']['tmp_name'][$index]['opciones'][$oIndex]['imagen']) && 
                $_FILES['preguntas']['error'][$index]['opciones'][$oIndex]['imagen'] === UPLOAD_ERR_OK) {
                
                $tmp_name = $_FILES['preguntas']['tmp_name'][$index]['opciones'][$oIndex]['imagen'];
                $name = $_FILES['preguntas']['name'][$index]['opciones'][$oIndex]['imagen'];
                $imagen_opcion = file_get_contents($tmp_name);
                $nombre_imagen_opcion = $name;
                
                // Debug imagen opción
                file_put_contents(__DIR__ . '/debug_crear_cuestionario.log', 
                    date('Y-m-d H:i:s') . " - Imagen opción procesada desde estructura anidada: {$name}, tamaño: " . strlen($imagen_opcion) . " bytes\n", FILE_APPEND);
            } else {
                // Fallback: buscar con la estructura tradicional
                $imagen_opcion_key = "preguntas[{$index}][opciones][{$oIndex}][imagen]";
                if (isset($_FILES[$imagen_opcion_key]) && $_FILES[$imagen_opcion_key]['error'] === UPLOAD_ERR_OK) {
                    $archivo = $_FILES[$imagen_opcion_key];
                    $imagen_opcion = file_get_contents($archivo['tmp_name']);
                    $nombre_imagen_opcion = $archivo['name'];
                    
                    file_put_contents(__DIR__ . '/debug_crear_cuestionario.log', 
                        date('Y-m-d H:i:s') . " - Imagen opción procesada estructura tradicional: {$imagen_opcion_key}, tamaño: " . strlen($imagen_opcion) . " bytes\n", FILE_APPEND);
                }
            }

            $es_correcta = ($pregunta['correcta'] == $oIndex) ? 1 : 0;
            
            $query_opcion = "INSERT INTO opcion_respuesta (id_pregunta, texto_opcion, opcion_correcta, orden, imagen_opcion, nombre_imagen_opcion) 
                            VALUES (:id_pregunta, :texto_opcion, :opcion_correcta, :orden, :imagen_opcion, :nombre_imagen_opcion)";
            $stmt_opcion = $db->prepare($query_opcion);
            $stmt_opcion->bindParam(':id_pregunta', $pregunta_id);
            $stmt_opcion->bindParam(':texto_opcion', $opcion['texto']);
            $stmt_opcion->bindParam(':opcion_correcta', $es_correcta);
            $stmt_opcion->bindParam(':orden', $oIndex);
            $stmt_opcion->bindParam(':imagen_opcion', $imagen_opcion, PDO::PARAM_LOB);
            $stmt_opcion->bindParam(':nombre_imagen_opcion', $nombre_imagen_opcion);
            $stmt_opcion->execute();
        }
    }

    $db->commit();
    echo json_encode([
        'success' => true, 
        'message' => 'Cuestionario creado exitosamente',
        'cuestionario_id' => $cuestionario_id
    ]);

} catch (Exception $e) {
    if (isset($db)) {
        $db->rollBack();
    }
    error_log("Error en crearCuestionario_api.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Error al crear el cuestionario',
        'debug_message' => $e->getMessage()
    ]);
} 