<?php
// Limpiar cualquier salida previa
while (ob_get_level() > 0) {
    ob_end_clean();
}
ob_start();

// Desactivar la salida de errores HTML
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', dirname(__FILE__) . '/registro_error.log');

// Manejar errores fatales
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'error', 
            'mensaje' => 'Error interno del servidor. Por favor, intenta nuevamente.'
        ]);
        exit();
    }
});

try {
    require_once dirname(__FILE__) . '/cors.php';
    require_once dirname(__FILE__) . '/../model/conection.php';
} catch (Exception $e) {
    ob_clean();
    http_response_code(500);
    echo json_encode(['status' => 'error', 'mensaje' => 'Error de configuración del servidor']);
    exit();
}

// Función para sanitizar entrada
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Solo aceptar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'mensaje' => 'Método no permitido']);
    exit();
}

// Obtener los datos JSON del body
$input = file_get_contents('php://input');
error_log("Datos recibidos: " . $input);

$json_data = json_decode($input, true);

if (!$json_data) {
    error_log("Error al decodificar JSON: " . json_last_error_msg());
    http_response_code(400);
    echo json_encode(['status' => 'error', 'mensaje' => 'Datos JSON inválidos: ' . json_last_error_msg()]);
    exit();
}

// Extraer y validar datos
$nombre = isset($json_data['nombre']) ? sanitize_input($json_data['nombre']) : '';
$email = isset($json_data['email']) ? sanitize_input($json_data['email']) : '';
$identificacion = isset($json_data['identificacion']) ? sanitize_input($json_data['identificacion']) : '';
$password = isset($json_data['password']) ? $json_data['password'] : '';
$confirmar_password = isset($json_data['confirmar_password']) ? $json_data['confirmar_password'] : '';
$programa_id = isset($json_data['programa_id']) ? intval($json_data['programa_id']) : null;

// Validaciones
if (empty($nombre) || empty($email) || empty($password) || empty($confirmar_password)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'mensaje' => 'Todos los campos son obligatorios']);
    exit();
}

if ($password !== $confirmar_password) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'mensaje' => 'Las contraseñas no coinciden']);
    exit();
}

if (strlen($password) < 8) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'mensaje' => 'La contraseña debe tener al menos 8 caracteres']);
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'mensaje' => 'Email inválido']);
    exit();
}

try {
    $db = Conection::conectar();
    
    // Si no se proporciona programa_id, obtener el primero disponible
    if (!$programa_id) {
        $query_programa = "SELECT id FROM programa ORDER BY id LIMIT 1";
        $stmt_programa = $db->prepare($query_programa);
        $stmt_programa->execute();
        $programa_default = $stmt_programa->fetch(PDO::FETCH_ASSOC);
        
        if ($programa_default) {
            $programa_id = $programa_default['id'];
        } else {
            // Si no hay programas, crear uno por defecto
            $query_insert_programa = "INSERT INTO programa (nombre, id_nivel, id_campus) VALUES ('General', 1, 1)";
            $stmt_insert = $db->prepare($query_insert_programa);
            
            try {
                $stmt_insert->execute();
                $programa_id = $db->lastInsertId();
            } catch (Exception $e) {
                // Si falla la inserción, intentar con valores NULL si son permitidos
                error_log("No se pudo crear programa por defecto: " . $e->getMessage());
                $programa_id = 1; // Último intento con ID 1
            }
        }
    }
    
    // Verificar si el email ya existe
    $query_verificar = "SELECT id FROM docente WHERE email = :email";
    $stmt_verificar = $db->prepare($query_verificar);
    $stmt_verificar->bindParam(':email', $email);
    $stmt_verificar->execute();
    
    if ($stmt_verificar->rowCount() > 0) {
        http_response_code(409);
        echo json_encode(['status' => 'error', 'mensaje' => 'El email ya está registrado']);
        exit();
    }
    
    // Crear nuevo usuario
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    $query_insertar = "INSERT INTO docente (nombre, email, identificacion, password, programa_id) 
                       VALUES (:nombre, :email, :identificacion, :password, :programa_id)";
    $stmt_insertar = $db->prepare($query_insertar);
    $stmt_insertar->bindParam(':nombre', $nombre);
    $stmt_insertar->bindParam(':email', $email);
    $stmt_insertar->bindParam(':identificacion', $identificacion);
    $stmt_insertar->bindParam(':password', $password_hash);
    $stmt_insertar->bindParam(':programa_id', $programa_id);
    
    if ($stmt_insertar->execute()) {
        http_response_code(201);
        echo json_encode([
            'status' => 'ok', 
            'mensaje' => 'Usuario registrado exitosamente. Puedes iniciar sesión ahora.',
            'docente_id' => $db->lastInsertId()
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'mensaje' => 'Error al registrar el usuario']);
    }
    
} catch (Exception $e) {
    error_log("Error en registro: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'mensaje' => 'Error interno del servidor']);
} 