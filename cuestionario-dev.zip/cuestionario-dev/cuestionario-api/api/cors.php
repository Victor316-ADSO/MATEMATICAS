<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept");
header("Access-Control-Max-Age: 3600");
// Iniciar la sesión antes de cualquier salida
if (session_status() === PHP_SESSION_NONE) {
    // Configurar el dominio de la cookie para que coincida con el dominio de la API
    $domain = 'localhost';
    
    // Configurar parámetros de la sesión
    ini_set('session.cookie_secure', 'false'); // false para desarrollo local sin HTTPS
    ini_set('session.cookie_httponly', 'true');
    ini_set('session.cookie_samesite', 'Lax'); // Cambiado de 'None' a 'Lax' para mejor compatibilidad
    ini_set('session.cookie_domain', $domain);
    ini_set('session.cookie_path', '/');
    ini_set('session.use_cookies', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', '86400'); // 24 horas de duración de sesión
    
    session_name('PHPSESSID');
    session_start();
}

// Permitir solicitudes desde el origen específico


// Para solicitudes OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit();
}

// Establecer el tipo de contenido por defecto para respuestas JSON
if ($_SERVER['REQUEST_METHOD'] !== 'OPTIONS') {
    header("Content-Type: application/json; charset=UTF-8");
}

// Para depuración
file_put_contents(__DIR__ . "/debug_headers.txt", 
    "Request Headers: " . json_encode(getallheaders()) . "\n" .
    "Session ID: " . session_id() . "\n" .
    "Session Data: " . json_encode($_SESSION) . "\n" .
    "Cookie Header: " . (isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : 'No cookie') . "\n",
    FILE_APPEND
);

