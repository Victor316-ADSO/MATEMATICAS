<?php
// Configuración de errores
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Iniciar sesión
session_start();

// Configuración de CORS
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

// Si es una solicitud OPTIONS (preflight), terminar aquí
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../api/api.php';
require_once __DIR__ . '/../model/conection.php';

try {
    $db = Conection::conectar();
    
    // Verificar método de petición
    if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'GET') {
        // Petición GET: Solo verificar si el cuestionario existe y está disponible
        $cuestionario_id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        if (!$cuestionario_id) {
            throw new Exception("ID del cuestionario es requerido");
        }
        
        // Verificar que el cuestionario existe y tiene aperturas activas
        $query_cuestionario = "
            SELECT c.id, c.titulo 
            FROM cuestionario c
            JOIN relacion_cuestionario_programa rcp ON c.id = rcp.id_cuestionario
            JOIN apertura ap ON rcp.id = ap.id_relacion_cuestionario_programa
            WHERE c.id = :id_cuestionario 
            AND ap.activo = 1
            LIMIT 1
        ";
        
        $stmt_cuestionario = $db->prepare($query_cuestionario);
        $stmt_cuestionario->bindParam(':id_cuestionario', $cuestionario_id);
        $stmt_cuestionario->execute();
        
        if ($stmt_cuestionario->rowCount() == 0) {
            echo json_encode([
                'success' => false,
                'acceso_valido' => false,
                'error' => 'Cuestionario no disponible'
            ]);
            exit;
        }
        
        echo json_encode([
            'success' => true,
            'acceso_valido' => true,
            'cuestionario' => $stmt_cuestionario->fetch(PDO::FETCH_ASSOC)
        ]);
        exit;
    }
    
    // Petición POST: Procesar login de estudiante
    $jsonData = json_decode(file_get_contents('php://input'), true);
    
    if (empty($jsonData['email'])) {
        throw new Exception("El correo electrónico es requerido");
    }
    
    if (empty($jsonData['documento'])) {
        throw new Exception("El documento de identidad es requerido");
    }
    
    if (empty($jsonData['id'])) {
        throw new Exception("El ID del cuestionario es requerido");
    }

    // Verificar estudiante
    $query = "SELECT e.* FROM estudiante e WHERE e.email = :email AND e.identificacion = :documento LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':email', $jsonData['email']);
    $stmt->bindParam(':documento', $jsonData['documento']);
    $stmt->execute();

    if ($stmt->rowCount() == 0) {
        throw new Exception("Credenciales inválidas");
    }

    $estudiante = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verificar asignación
    $query_asignacion = "
        SELECT a.id 
        FROM asignacion a
        JOIN apertura ap ON a.id_apertura = ap.id
        JOIN relacion_cuestionario_programa rcp ON ap.id_relacion_cuestionario_programa = rcp.id
        WHERE rcp.id_cuestionario = :id_cuestionario 
        AND a.id_estudiante = :id_estudiante
        LIMIT 1
    ";
    
    $stmt_asignacion = $db->prepare($query_asignacion);
    $stmt_asignacion->bindParam(':id_cuestionario', $jsonData['id']);
    $stmt_asignacion->bindParam(':id_estudiante', $estudiante['id']);
    $stmt_asignacion->execute();

    if ($stmt_asignacion->rowCount() == 0) {
        throw new Exception("No estás habilitado para realizar este cuestionario");
    }

    // Verificar si ya realizó el cuestionario
    $query_verificar = "
        SELECT re.id 
        FROM respuesta_estudiante re
        WHERE re.id_estudiante = :id_estudiante 
        AND re.id_cuestionario = :id_cuestionario
        LIMIT 1
    ";
    
    $stmt_verificar = $db->prepare($query_verificar);
    $stmt_verificar->bindParam(':id_estudiante', $estudiante['id']);
    $stmt_verificar->bindParam(':id_cuestionario', $jsonData['id']);
    $stmt_verificar->execute();

    if ($stmt_verificar->rowCount() > 0) {
        throw new Exception("Ya has realizado este cuestionario");
    }

    // Guardar datos en la sesión
    $_SESSION['usuario_id'] = $estudiante['id'];
    $_SESSION['usuario_nombre'] = $estudiante['nombre'];
    $_SESSION['usuario_email'] = $estudiante['email'];
    $_SESSION['usuario_rol'] = 'estudiante'; // Cambié usuario_tipo por usuario_rol para consistencia

    echo json_encode([
        'success' => true,
        'message' => 'Acceso concedido',
        'estudiante' => [
            'id' => $estudiante['id'],
            'nombre' => $estudiante['nombre'],
            'email' => $estudiante['email']
        ]
    ]);

} catch (Exception $e) {
    error_log("Error en linksystem_api.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} 