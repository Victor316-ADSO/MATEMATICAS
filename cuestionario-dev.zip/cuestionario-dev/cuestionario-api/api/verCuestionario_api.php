<?php
// Configuración de errores
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Limpiar cualquier salida previa
ob_start();

// Iniciar sesión solo si no está activa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configuración de CORS
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

// Si es una solicitud OPTIONS (preflight), terminar aquí
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// Incluir dependencias
require_once __DIR__ . '/../api/api.php';
require_once __DIR__ . '/../model/conection.php';

try {
    $db = Conection::conectar();
    
    // Obtener el ID del cuestionario de la URL
    $cuestionario_id = isset($_GET['id']) ? intval($_GET['id']) : null;
    
    if (!$cuestionario_id) {
        throw new Exception('ID de cuestionario no proporcionado');
    }
    
    // Obtener información del cuestionario
    $query_cuestionario = "SELECT c.*, rcp.id_programa, rcp.id_docente 
                          FROM cuestionario c 
                          LEFT JOIN relacion_cuestionario_programa rcp ON c.id = rcp.id_cuestionario 
                          WHERE c.id = :id";
    $stmt_cuestionario = $db->prepare($query_cuestionario);
    $stmt_cuestionario->bindParam(':id', $cuestionario_id);
    $stmt_cuestionario->execute();
    $cuestionario = $stmt_cuestionario->fetch(PDO::FETCH_ASSOC);
    
    if (!$cuestionario) {
        throw new Exception('Cuestionario no encontrado');
    }
    
    // Obtener preguntas
    $query_preguntas = "SELECT id, texto_pregunta, orden_pregunta, peso_pregunta, 
                        imagen_pregunta,
                        nombre_imagen_pregunta,
                        CASE WHEN imagen_pregunta IS NOT NULL THEN 1 ELSE 0 END as tiene_imagen
                        FROM preguntas 
                        WHERE id_cuestionario = :id_cuestionario 
                        ORDER BY orden_pregunta";
    $stmt_preguntas = $db->prepare($query_preguntas);
    $stmt_preguntas->bindParam(':id_cuestionario', $cuestionario_id);
    $stmt_preguntas->execute();
    $preguntas = $stmt_preguntas->fetchAll(PDO::FETCH_ASSOC);
    
    // Para cada pregunta, obtener sus opciones
    foreach ($preguntas as &$pregunta) {
        $query_opciones = "SELECT id, texto_opcion, opcion_correcta, orden,
                          imagen_opcion,
                          nombre_imagen_opcion,
                          CASE WHEN imagen_opcion IS NOT NULL THEN 1 ELSE 0 END as tiene_imagen
                          FROM opcion_respuesta 
                          WHERE id_pregunta = :id_pregunta 
                          ORDER BY orden";
        $stmt_opciones = $db->prepare($query_opciones);
        $stmt_opciones->bindParam(':id_pregunta', $pregunta['id']);
        $stmt_opciones->execute();
        $opciones = $stmt_opciones->fetchAll(PDO::FETCH_ASSOC);
        
        // Limpiar datos binarios de imagen para la respuesta JSON (solo mantener info si tiene imagen)
        foreach ($opciones as &$opcion) {
            unset($opcion['imagen_opcion']); // No enviar datos binarios en JSON
        }
        
        $pregunta['opciones'] = $opciones;
        
        // Limpiar datos binarios de imagen de pregunta también
        unset($pregunta['imagen_pregunta']);
    }
    
    // Preparar la respuesta
    $response = [
        'success' => true,
        'cuestionario' => [
            'id' => $cuestionario['id'],
            'titulo' => $cuestionario['titulo'],
            'descripcion' => $cuestionario['descripcion'],
            'programa_id' => $cuestionario['id_programa'],
            'docente_id' => $cuestionario['id_docente'],
            'preguntas' => $preguntas
        ]
    ];
    
    // Limpiar buffer y enviar respuesta
    ob_clean();
    echo json_encode($response);
    
} catch (Exception $e) {
    error_log("Error en verCuestionario_api.php: " . $e->getMessage());
    ob_clean();
    echo json_encode([
        'success' => false,
        'error' => 'Error al obtener el cuestionario',
        'debug_message' => $e->getMessage()
    ]);
} 