<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

error_log("TEST: Script iniciado");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_log("TEST: Session usuario_id: " . ($_SESSION['usuario_id'] ?? 'NO_SET'));

echo json_encode([
    'test' => 'success',
    'timestamp' => date('Y-m-d H:i:s'),
    'session_id' => session_id(),
    'usuario_id' => $_SESSION['usuario_id'] ?? null,
    'parametros' => $_GET
]);

error_log("TEST: Respuesta enviada");
?> 