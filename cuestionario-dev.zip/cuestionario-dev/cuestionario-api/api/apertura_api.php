<?php
// Prevenir cualquier salida antes de los headers
ob_start();

// Configuración de errores
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Función para enviar respuesta JSON
function sendJsonResponse($data, $statusCode = 200) {
    if (ob_get_length()) ob_clean();
    if (!headers_sent()) {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode($data);
    exit();
}

// Incluir archivos necesarios
require_once 'cors.php';
require_once '../model/conection.php';

// Asegurarse de que la sesión esté iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar si la sesión está activa o si se proporciona un ID de usuario
$usuario_id = isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : null;

// Si no hay sesión, intentar obtener el usuario del parámetro
if (!$usuario_id) {
    if (isset($_GET['usuario_id'])) {
        $usuario_id = $_GET['usuario_id'];
    } elseif (isset($_POST['usuario_id'])) {
        $usuario_id = $_POST['usuario_id'];
    }
}

// Para desarrollo, si aún no hay usuario_id, usar un ID por defecto
if (!$usuario_id) {
    $usuario_id = 3; // ID de usuario para desarrollo
}

// Obtener el contenido de la solicitud
$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

// Si no hay datos JSON pero hay datos POST, usar esos
if (!$data && !empty($_POST)) {
    $data = $_POST;
}

// Si aún no hay datos, verificar si hay datos en GET
if (!$data && !empty($_GET)) {
    $data = $_GET;
}

// Inicializar la conexión a la base de datos
try {
    $conn = Conection::conectar();
} catch (Exception $e) {
    sendJsonResponse([
        'success' => false, 
        'error' => 'Error al conectar con la base de datos',
        'debug' => $e->getMessage()
    ], 500);
}

// Procesar según la acción solicitada
if (isset($data['accion'])) {
    switch ($data['accion']) {
        case 'cargar_datos':
            cargarDatos($conn, $usuario_id);
            break;
        case 'crear_apertura':
            crearApertura($conn, $data, $usuario_id);
            break;
        case 'eliminar_apertura':
            eliminarApertura($conn, $data, $usuario_id);
            break;
        default:
            sendJsonResponse([
                'success' => false, 
                'error' => 'Acción no reconocida'
            ], 400);
    }
} else {
    // Si no se especifica una acción, cargar datos por defecto
    cargarDatos($conn, $usuario_id);
}

// Función para cargar todos los datos necesarios
function cargarDatos($db, $usuario_id) {
    try {
        // Obtener cuestionarios del usuario actual (sin periodo asignado)
        $query_mis_cuestionarios = "
            SELECT 
                rcp.id, 
                c.id as cuestionario_id,
                c.titulo, 
                c.descripcion,
                p.nombre as programa_nombre
            FROM 
                relacion_cuestionario_programa rcp 
            JOIN 
                cuestionario c ON rcp.id_cuestionario = c.id
            JOIN 
                programa p ON rcp.id_programa = p.id
            LEFT JOIN 
                apertura a ON rcp.id = a.id_relacion_cuestionario_programa
            WHERE 
                rcp.id_docente = :docente_id
                AND rcp.activo = 1
                AND a.id IS NULL
        ";
        $stmt_mis = $db->prepare($query_mis_cuestionarios);
        $stmt_mis->bindParam(':docente_id', $usuario_id);
        $stmt_mis->execute();
        $cuestionarios = $stmt_mis->fetchAll(PDO::FETCH_ASSOC);

        // Obtener periodos disponibles
        $query_periodos = "SELECT id, nombre, fecha_inicio, fecha_fin FROM periodo ORDER BY fecha_inicio DESC";
        $stmt_periodos = $db->prepare($query_periodos);
        $stmt_periodos->execute();
        $periodos = $stmt_periodos->fetchAll(PDO::FETCH_ASSOC);

        // Obtener aperturas existentes del usuario
        $query_aperturas = "
            SELECT 
                a.id, 
                c.titulo, 
                c.descripcion,
                p.nombre as programa_nombre,
                per.nombre as periodo_nombre,
                per.fecha_inicio,
                per.fecha_fin
            FROM 
                apertura a
            JOIN 
                relacion_cuestionario_programa rcp ON a.id_relacion_cuestionario_programa = rcp.id
            JOIN 
                cuestionario c ON rcp.id_cuestionario = c.id
            JOIN 
                programa p ON rcp.id_programa = p.id
            JOIN 
                periodo per ON a.id_periodo = per.id
            WHERE 
                rcp.id_docente = :docente_id
            ORDER BY 
                per.fecha_inicio DESC
        ";
        $stmt_aperturas = $db->prepare($query_aperturas);
        $stmt_aperturas->bindParam(':docente_id', $usuario_id);
        $stmt_aperturas->execute();
        $aperturas = $stmt_aperturas->fetchAll(PDO::FETCH_ASSOC);

        // Devolver los datos
        sendJsonResponse([
            'success' => true,
            'cuestionarios' => $cuestionarios,
            'periodos' => $periodos,
            'aperturas' => $aperturas
        ]);
    } catch (PDOException $e) {
        sendJsonResponse([
            'success' => false, 
            'error' => 'Error al cargar los datos',
            'debug' => $e->getMessage()
        ], 500);
    } catch (Exception $e) {
        sendJsonResponse([
            'success' => false, 
            'error' => 'Error inesperado',
            'debug' => $e->getMessage()
        ], 500);
    }
}

// Función para crear una apertura
function crearApertura($db, $data, $usuario_id) {
    try {
        $cuestionario_id = sanitize_input($data['cuestionario_id']);
        $periodo_id = sanitize_input($data['periodo_id']);
        
        if (empty($cuestionario_id) || empty($periodo_id)) {
            sendJsonResponse([
                'success' => false, 
                'error' => 'Debe seleccionar un cuestionario y un periodo'
            ], 400);
        }
        
        // Verificar que el cuestionario pertenezca al usuario actual
        $query_verificar = "
            SELECT 
                rcp.id
            FROM 
                relacion_cuestionario_programa rcp
            WHERE 
                rcp.id = :cuestionario_id
                AND rcp.id_docente = :docente_id
                AND rcp.activo = 1
        ";
        $stmt_verificar = $db->prepare($query_verificar);
        $stmt_verificar->bindParam(':cuestionario_id', $cuestionario_id);
        $stmt_verificar->bindParam(':docente_id', $usuario_id);
        $stmt_verificar->execute();
        
        if ($stmt_verificar->rowCount() > 0) {
            $relacion_id = $stmt_verificar->fetch(PDO::FETCH_ASSOC)['id'];
            
            // Verificar que no exista ya una apertura para este cuestionario
            $query_verificar_apertura = "
                SELECT 
                    id
                FROM 
                    apertura
                WHERE 
                    id_relacion_cuestionario_programa = :relacion_id
            ";
            $stmt_verificar_apertura = $db->prepare($query_verificar_apertura);
            $stmt_verificar_apertura->bindParam(':relacion_id', $relacion_id);
            $stmt_verificar_apertura->execute();
            
            if ($stmt_verificar_apertura->rowCount() > 0) {
                sendJsonResponse([
                    'success' => false, 
                    'error' => 'Este cuestionario ya tiene una apertura asignada'
                ], 400);
            }
            
            // Crear la apertura
            $query_crear_apertura = "
                INSERT INTO apertura 
                    (id_periodo, id_relacion_cuestionario_programa) 
                VALUES 
                    (:periodo_id, :relacion_id)
            ";
            $stmt_crear_apertura = $db->prepare($query_crear_apertura);
            $stmt_crear_apertura->bindParam(':periodo_id', $periodo_id);
            $stmt_crear_apertura->bindParam(':relacion_id', $relacion_id);
            $stmt_crear_apertura->execute();
            
            sendJsonResponse([
                'success' => true,
                'message' => 'Apertura creada correctamente'
            ]);
        } else {
            sendJsonResponse([
                'success' => false, 
                'error' => 'No tiene permisos para crear una apertura para este cuestionario o no existe'
            ], 403);
        }
    } catch (PDOException $e) {
        sendJsonResponse([
            'success' => false, 
            'error' => 'Error al crear la apertura',
            'debug' => $e->getMessage()
        ], 500);
    } catch (Exception $e) {
        sendJsonResponse([
            'success' => false, 
            'error' => 'Error inesperado',
            'debug' => $e->getMessage()
        ], 500);
    }
}

// Función para eliminar una apertura
function eliminarApertura($db, $data, $usuario_id) {
    try {
        $apertura_id = sanitize_input($data['apertura_id']);
        
        if (empty($apertura_id)) {
            sendJsonResponse([
                'success' => false, 
                'error' => 'Debe especificar la apertura a eliminar'
            ], 400);
        }
        
        // Verificar que la apertura pertenezca al usuario actual
        $query_verificar = "
            SELECT 
                a.id
            FROM 
                apertura a
            JOIN 
                relacion_cuestionario_programa rcp ON a.id_relacion_cuestionario_programa = rcp.id
            WHERE 
                a.id = :apertura_id
                AND rcp.id_docente = :docente_id
        ";
        $stmt_verificar = $db->prepare($query_verificar);
        $stmt_verificar->bindParam(':apertura_id', $apertura_id);
        $stmt_verificar->bindParam(':docente_id', $usuario_id);
        $stmt_verificar->execute();
        
        if ($stmt_verificar->rowCount() > 0) {
            // Verificar si hay estudiantes asignados a esta apertura
            $query_asignaciones = "
                SELECT COUNT(*) as total_asignaciones
                FROM asignacion 
                WHERE id_apertura = :apertura_id
            ";
            $stmt_asignaciones = $db->prepare($query_asignaciones);
            $stmt_asignaciones->bindParam(':apertura_id', $apertura_id);
            $stmt_asignaciones->execute();
            
            $asignaciones = $stmt_asignaciones->fetch(PDO::FETCH_ASSOC);
            
            if ($asignaciones['total_asignaciones'] > 0) {
                sendJsonResponse([
                    'success' => false, 
                    'error' => 'No se puede eliminar esta apertura porque tiene ' . $asignaciones['total_asignaciones'] . ' estudiante(s) asignado(s). Primero elimine las asignaciones.'
                ], 400);
                return;
            }
            
            // Eliminar la apertura
            $query_eliminar = "DELETE FROM apertura WHERE id = :apertura_id";
            $stmt_eliminar = $db->prepare($query_eliminar);
            $stmt_eliminar->bindParam(':apertura_id', $apertura_id);
            $stmt_eliminar->execute();
            
            sendJsonResponse([
                'success' => true,
                'message' => 'Apertura eliminada correctamente'
            ]);
        } else {
            sendJsonResponse([
                'success' => false, 
                'error' => 'No tiene permisos para eliminar esta apertura o no existe'
            ], 403);
        }
    } catch (PDOException $e) {
        sendJsonResponse([
            'success' => false, 
            'error' => 'Error al eliminar la apertura',
            'debug' => $e->getMessage()
        ], 500);
    } catch (Exception $e) {
        sendJsonResponse([
            'success' => false, 
            'error' => 'Error inesperado',
            'debug' => $e->getMessage()
        ], 500);
    }
}

// Función para sanitizar inputs
function sanitize_input($data) {
    if (is_array($data)) {
        foreach ($data as $key => $value) {
            $data[$key] = sanitize_input($value);
        }
    } else {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
    }
    return $data;
}
?> 