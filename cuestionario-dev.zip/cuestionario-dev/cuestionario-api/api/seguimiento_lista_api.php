<?php
// Asegurarnos de que no se haya enviado ningún output antes
ob_start();

// Para depuración
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Configuración de CORS y headers
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-Requested-With, Authorization");
header('Content-Type: application/json; charset=utf-8');

// Responder inmediatamente a las solicitudes OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(['success' => true]);
    exit();
}

// Función para manejar errores y devolver siempre JSON
function handleError($errno, $errstr, $errfile, $errline) {
    $error = [
        'success' => false,
        'error' => 'Error del servidor: ' . $errstr,
        'details' => [
            'file' => $errfile,
            'line' => $errline
        ]
    ];
    
    // Limpiar cualquier output previo
    if (ob_get_length()) ob_clean();
    
    // Asegurar headers JSON
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($error);
    exit(1);
}

// Establecer el manejador de errores
set_error_handler('handleError');

try {
    require_once __DIR__ . '/cors.php';
    require_once __DIR__ . '/../model/conection.php';

    // Verificar si el usuario está autenticado o si se proporciona un ID de usuario
    $usuario_id = isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : null;

    // Si no hay sesión, intentar obtener el usuario del parámetro
    if (!$usuario_id) {
        if (isset($_GET['usuario_id'])) {
            $usuario_id = $_GET['usuario_id'];
        } elseif (isset($_POST['usuario_id'])) {
            $usuario_id = $_POST['usuario_id'];
        }
    }

    // Para desarrollo, si aún no hay usuario_id, usar un ID por defecto
    if (!$usuario_id) {
        $usuario_id = 3; // ID de usuario para desarrollo
    }

    $conn = Conection::conectar();

    if (!$conn) {
        throw new Exception('Error al conectar con la base de datos');
    }

    // Obtener cuestionarios para seguimiento
    $query_cuestionarios = "
        SELECT 
            a.id as apertura_id,
            c.id as cuestionario_id,
            c.titulo,
            c.descripcion,
            p.nombre as periodo_nombre,
            p.fecha_inicio,
            p.fecha_fin,
            prog.nombre as programa_nombre,
            (SELECT COUNT(*) FROM asignacion WHERE id_apertura = a.id) as total_estudiantes_asignados,
            (SELECT COUNT(DISTINCT re.id_estudiante) 
             FROM respuesta_estudiante re 
             JOIN asignacion asig ON re.id_estudiante = asig.id_estudiante 
             WHERE asig.id_apertura = a.id 
             AND re.id_cuestionario = c.id) as total_estudiantes_completados
        FROM 
            apertura a
        JOIN 
            relacion_cuestionario_programa rcp ON a.id_relacion_cuestionario_programa = rcp.id
        JOIN 
            cuestionario c ON rcp.id_cuestionario = c.id
        JOIN 
            periodo p ON a.id_periodo = p.id
        JOIN 
            programa prog ON rcp.id_programa = prog.id
        WHERE 
            rcp.id_docente = :usuario_id
        ORDER BY 
            p.fecha_inicio DESC
    ";

    $stmt = $conn->prepare($query_cuestionarios);
    $stmt->bindParam(':usuario_id', $usuario_id);
    
    if (!$stmt->execute()) {
        throw new Exception('Error al ejecutar la consulta');
    }
    
    $cuestionarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calcular estadísticas globales
    $total_estudiantes_asignados = 0;
    $total_estudiantes_completados = 0;

    foreach ($cuestionarios as $cuestionario) {
        $total_estudiantes_asignados += intval($cuestionario['total_estudiantes_asignados']);
        $total_estudiantes_completados += intval($cuestionario['total_estudiantes_completados']);
    }

    $porcentaje_global = $total_estudiantes_asignados > 0 
        ? round(($total_estudiantes_completados / $total_estudiantes_asignados) * 100) 
        : 0;

    // Limpiar cualquier output previo
    if (ob_get_length()) ob_clean();
    
    echo json_encode([
        'success' => true,
        'cuestionarios' => $cuestionarios,
        'total_estudiantes_asignados' => $total_estudiantes_asignados,
        'total_estudiantes_completados' => $total_estudiantes_completados,
        'porcentaje_global' => $porcentaje_global
    ]);

} catch (PDOException $e) {
    // Limpiar cualquier output previo
    if (ob_get_length()) ob_clean();
    
    // Asegurar headers JSON
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos',
        'debug' => $e->getMessage()
    ]);
} catch (Exception $e) {
    // Limpiar cualquier output previo
    if (ob_get_length()) ob_clean();
    
    // Asegurar headers JSON
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

// Asegurarse de que todo el output sea enviado y limpiar el buffer
ob_end_flush(); 