<?php
// Asegurarnos de que no se haya enviado ningún output antes
ob_start();

// Para depuración
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Configuración de CORS y headers
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-Requested-With, Authorization");
header('Content-Type: application/json; charset=utf-8');

// Responder inmediatamente a las solicitudes OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(['success' => true]);
    exit();
}

try {
    require_once __DIR__ . '/cors.php';
    require_once __DIR__ . '/../model/conection.php';

    // Verificar si el usuario está autenticado o si se proporciona un ID de usuario
    $usuario_id = isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : null;

    // Si no hay sesión, intentar obtener el usuario del parámetro
    if (!$usuario_id) {
        if (isset($_GET['usuario_id'])) {
            $usuario_id = $_GET['usuario_id'];
        } elseif (isset($_POST['usuario_id'])) {
            $usuario_id = $_POST['usuario_id'];
        }
    }

    // Para desarrollo, si aún no hay usuario_id, usar un ID por defecto
    if (!$usuario_id) {
        $usuario_id = 3; // ID de usuario para desarrollo
    }

    // Verificar si se proporcionó un ID de apertura
    if (!isset($_GET['id'])) {
        throw new Exception('ID de apertura no proporcionado');
    }

    $apertura_id = $_GET['id'];
    $db = Conection::conectar();

    // Obtener información del cuestionario
    $query_cuestionario = "
        SELECT 
            a.id as apertura_id,
            c.id,
            c.titulo,
            c.descripcion,
            p.nombre as periodo_nombre,
            p.fecha_inicio,
            p.fecha_fin,
            prog.nombre as programa_nombre
        FROM 
            apertura a
        JOIN 
            relacion_cuestionario_programa rcp ON a.id_relacion_cuestionario_programa = rcp.id
        JOIN 
            cuestionario c ON rcp.id_cuestionario = c.id
        JOIN 
            periodo p ON a.id_periodo = p.id
        JOIN 
            programa prog ON rcp.id_programa = prog.id
        WHERE 
            a.id = :apertura_id
            AND rcp.id_docente = :usuario_id
    ";

    $stmt_cuestionario = $db->prepare($query_cuestionario);
    $stmt_cuestionario->bindParam(':apertura_id', $apertura_id);
    $stmt_cuestionario->bindParam(':usuario_id', $usuario_id);
    $stmt_cuestionario->execute();
    $cuestionario = $stmt_cuestionario->fetch(PDO::FETCH_ASSOC);

    if (!$cuestionario) {
        throw new Exception('Cuestionario no encontrado');
    }

    // Obtener lista de estudiantes y sus respuestas
    $query_estudiantes = "
        SELECT 
            e.id,
            e.nombre,
            e.identificacion,
            e.email,
            CASE 
                WHEN COUNT(DISTINCT re.id_pregunta) = (
                    SELECT COUNT(*) FROM preguntas WHERE id_cuestionario = :cuestionario_id
                ) THEN 1 
                ELSE 0 
            END as completado,
            MIN(re.fecha_respuesta) as fecha_respuesta,
            COUNT(DISTINCT re.id_pregunta) as total_respuestas,
            SUM(CASE WHEN o.opcion_correcta = 1 THEN 1 ELSE 0 END) as respuestas_correctas,
            SUM(CASE WHEN o.opcion_correcta = 1 THEN p.peso_pregunta ELSE 0 END) as puntaje_obtenido,
            (SELECT SUM(peso_pregunta) FROM preguntas WHERE id_cuestionario = :cuestionario_id) as puntaje_total
        FROM 
            asignacion a
        JOIN 
            estudiante e ON a.id_estudiante = e.id
        LEFT JOIN 
            respuesta_estudiante re ON re.id_estudiante = e.id 
            AND re.id_cuestionario = :cuestionario_id
        LEFT JOIN 
            opcion_respuesta o ON re.id_opcion_seleccionada = o.id
        LEFT JOIN 
            preguntas p ON re.id_pregunta = p.id
        WHERE 
            a.id_apertura = :apertura_id
        GROUP BY 
            e.id, e.nombre, e.identificacion, e.email
        ORDER BY 
            e.nombre ASC
    ";

    $stmt_estudiantes = $db->prepare($query_estudiantes);
    $stmt_estudiantes->bindParam(':apertura_id', $apertura_id);
    $stmt_estudiantes->bindParam(':cuestionario_id', $cuestionario['id']);
    $stmt_estudiantes->execute();
    $estudiantes = $stmt_estudiantes->fetchAll(PDO::FETCH_ASSOC);

    // Calcular estadísticas
    $estudiantes_completados = 0;
    foreach ($estudiantes as &$estudiante) {
        if ($estudiante['completado']) {
            $estudiantes_completados++;
            $estudiante['porcentaje'] = $estudiante['puntaje_total'] > 0 
                ? round(($estudiante['puntaje_obtenido'] / $estudiante['puntaje_total']) * 100) 
                : 0;
        }
    }

    $porcentaje_completado = count($estudiantes) > 0 
        ? round(($estudiantes_completados / count($estudiantes)) * 100) 
        : 0;

    // Limpiar cualquier output previo
    if (ob_get_length()) ob_clean();
    
    echo json_encode([
        'success' => true,
        'cuestionario' => $cuestionario,
        'estudiantes' => $estudiantes,
        'porcentaje_completado' => $porcentaje_completado,
        'estudiantes_completados' => $estudiantes_completados
    ]);

} catch (Exception $e) {
    // Limpiar cualquier output previo
    if (ob_get_length()) ob_clean();
    
    // Asegurar headers JSON
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

// Asegurarse de que todo el output sea enviado y limpiar el buffer
ob_end_flush(); 