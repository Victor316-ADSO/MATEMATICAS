<?php
// Limpiar cualquier salida previa
while (ob_get_level() > 0) {
    ob_end_clean();
}
ob_start();

// Headers de respuesta
header('Content-Type: application/json; charset=utf-8');

// Headers CORS
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: " . $_SERVER['HTTP_ORIGIN']);
} else {
    header("Access-Control-Allow-Origin: http://localhost:5173");
}
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");

// Manejar peticiones OPTIONS (preflight)
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Manejar errores fatales
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Error interno del servidor'
        ], JSON_UNESCAPED_UNICODE);
    }
});

require_once dirname(__DIR__) . '/model/conection.php';

// Verificar si ya hay sesión activa antes de iniciar
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    // Verificar si el usuario está autenticado
    if (!isset($_SESSION['usuario_id'])) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'error' => 'Sesión no iniciada - debes iniciar sesión como estudiante'
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // Verificar si es estudiante
    if (!isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] !== 'estudiante') {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Acceso no autorizado - solo estudiantes pueden ver resultados'
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $db = Conection::conectar();
    $cuestionario_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    // Verificar que se proporcionó un ID válido
    if ($cuestionario_id <= 0) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'ID de cuestionario no válido'
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // Verificar que el cuestionario existe y el estudiante tiene acceso
    $query_verificar_acceso = "
        SELECT 
            c.id as cuestionario_id,
            c.titulo,
            c.descripcion,
            d.nombre as creador_nombre,
            p.nombre as programa_nombre,
            n.nombre as nivel_nombre,
            cam.nombre as campus_nombre
        FROM 
            cuestionario c
        JOIN
            relacion_cuestionario_programa rcp ON c.id = rcp.id_cuestionario
        JOIN
            docente d ON rcp.id_docente = d.id
        JOIN
            estudiante e ON e.id = :usuario_id
        JOIN 
            programa p ON e.id_programa = p.id
        JOIN 
            nivel n ON p.id_nivel = n.id
        JOIN 
            campus cam ON p.id_campus = cam.id
        WHERE 
            c.id = :cuestionario_id
        LIMIT 1
    ";
    
    $stmt_verificar = $db->prepare($query_verificar_acceso);
    $stmt_verificar->bindParam(':cuestionario_id', $cuestionario_id);
    $stmt_verificar->bindParam(':usuario_id', $_SESSION['usuario_id']);
    $stmt_verificar->execute();

    if ($stmt_verificar->rowCount() == 0) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'error' => 'Cuestionario no encontrado o no tienes acceso a él'
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $cuestionario_info = $stmt_verificar->fetch(PDO::FETCH_ASSOC);

    // Obtener información del cuestionario y resultados
    $query_resultado = "
        SELECT 
            :cuestionario_id as cuestionario_id,
            :titulo as titulo,
            :descripcion as descripcion,
            :creador_nombre as creador_nombre,
            :programa_nombre as programa_nombre,
            :nivel_nombre as nivel_nombre,
            :campus_nombre as campus_nombre,
            :usuario_id as estudiante_id,
            COALESCE(COUNT(re.id), 0) as total_respondidas,
            (SELECT COUNT(*) FROM preguntas WHERE id_cuestionario = :cuestionario_id2) as total_preguntas,
            COALESCE((SELECT COUNT(*) FROM respuesta_estudiante re2 
             JOIN opcion_respuesta op ON re2.id_opcion_seleccionada = op.id 
             WHERE re2.id_cuestionario = :cuestionario_id3 
             AND re2.id_estudiante = :usuario_id2 
             AND op.opcion_correcta = 1), 0) as respuestas_correctas,
            COALESCE((SELECT SUM(peso_pregunta) FROM preguntas WHERE id_cuestionario = :cuestionario_id4), 0) as puntaje_total,
            COALESCE((SELECT SUM(p.peso_pregunta) 
             FROM respuesta_estudiante re2 
             JOIN opcion_respuesta op ON re2.id_opcion_seleccionada = op.id 
             JOIN preguntas p ON re2.id_pregunta = p.id
             WHERE re2.id_cuestionario = :cuestionario_id5 
             AND re2.id_estudiante = :usuario_id3 
             AND op.opcion_correcta = 1), 0) as puntaje_obtenido,
            COALESCE(MAX(re.fecha_respuesta), NOW()) as fecha_completado
        FROM 
            respuesta_estudiante re
        WHERE 
            re.id_cuestionario = :cuestionario_id6 AND re.id_estudiante = :usuario_id4
    ";
    
    $stmt_resultado = $db->prepare($query_resultado);
    $stmt_resultado->bindParam(':cuestionario_id', $cuestionario_info['cuestionario_id']);
    $stmt_resultado->bindParam(':titulo', $cuestionario_info['titulo']);
    $stmt_resultado->bindParam(':descripcion', $cuestionario_info['descripcion']);
    $stmt_resultado->bindParam(':creador_nombre', $cuestionario_info['creador_nombre']);
    $stmt_resultado->bindParam(':programa_nombre', $cuestionario_info['programa_nombre']);
    $stmt_resultado->bindParam(':nivel_nombre', $cuestionario_info['nivel_nombre']);
    $stmt_resultado->bindParam(':campus_nombre', $cuestionario_info['campus_nombre']);
    $stmt_resultado->bindParam(':usuario_id', $_SESSION['usuario_id']);
    $stmt_resultado->bindParam(':cuestionario_id2', $cuestionario_id);
    $stmt_resultado->bindParam(':cuestionario_id3', $cuestionario_id);
    $stmt_resultado->bindParam(':usuario_id2', $_SESSION['usuario_id']);
    $stmt_resultado->bindParam(':cuestionario_id4', $cuestionario_id);
    $stmt_resultado->bindParam(':cuestionario_id5', $cuestionario_id);
    $stmt_resultado->bindParam(':usuario_id3', $_SESSION['usuario_id']);
    $stmt_resultado->bindParam(':cuestionario_id6', $cuestionario_id);
    $stmt_resultado->bindParam(':usuario_id4', $_SESSION['usuario_id']);
    $stmt_resultado->execute();

    // Si no hay resultados, crear un resultado vacío
    if ($stmt_resultado->rowCount() == 0) {
        $resultado = [
            'cuestionario_id' => $cuestionario_info['cuestionario_id'],
            'titulo' => $cuestionario_info['titulo'],
            'descripcion' => $cuestionario_info['descripcion'],
            'creador_nombre' => $cuestionario_info['creador_nombre'],
            'programa_nombre' => $cuestionario_info['programa_nombre'],
            'nivel_nombre' => $cuestionario_info['nivel_nombre'],
            'campus_nombre' => $cuestionario_info['campus_nombre'],
            'estudiante_id' => $_SESSION['usuario_id'],
            'total_respondidas' => 0,
            'respuestas_correctas' => 0,
            'puntaje_obtenido' => 0,
            'fecha_completado' => date('Y-m-d H:i:s')
        ];
        
        // Obtener total de preguntas
        $query_total_preguntas = "SELECT COUNT(*) as total, COALESCE(SUM(peso_pregunta), 0) as puntaje_total FROM preguntas WHERE id_cuestionario = :cuestionario_id";
        $stmt_total = $db->prepare($query_total_preguntas);
        $stmt_total->bindParam(':cuestionario_id', $cuestionario_id);
        $stmt_total->execute();
        $total_info = $stmt_total->fetch(PDO::FETCH_ASSOC);
        
        $resultado['total_preguntas'] = $total_info['total'];
        $resultado['puntaje_total'] = $total_info['puntaje_total'];
    } else {
        $resultado = $stmt_resultado->fetch(PDO::FETCH_ASSOC);
    }

    // Calcular porcentaje
    $porcentaje = 0;
    if ($resultado['puntaje_total'] > 0) {
        $porcentaje = round(($resultado['puntaje_obtenido'] / $resultado['puntaje_total']) * 100);
    }
    $resultado['porcentaje'] = $porcentaje;

    // Verificar si fue un intento por timeout
    $query_verificar_timeout = "
        SELECT COUNT(*) as count FROM respuesta_estudiante re
        JOIN opcion_respuesta op ON re.id_opcion_seleccionada = op.id
        WHERE re.id_estudiante = :usuario_id 
        AND re.id_cuestionario = :cuestionario_id
        AND op.texto_opcion = 'INTENTO_TIMEOUT'
    ";
    $stmt_timeout = $db->prepare($query_verificar_timeout);
    $stmt_timeout->bindParam(':usuario_id', $_SESSION['usuario_id']);
    $stmt_timeout->bindParam(':cuestionario_id', $cuestionario_id);
    $stmt_timeout->execute();
    $fue_timeout = $stmt_timeout->fetch(PDO::FETCH_ASSOC)['count'] > 0;

    // Obtener detalles de respuestas (incluir TODAS las preguntas del cuestionario)
    $query_detalles = "
        SELECT 
            p.id as pregunta_id,
            p.texto_pregunta,
            p.orden_pregunta,
            p.peso_pregunta,
            CASE WHEN p.imagen_pregunta IS NOT NULL THEN 1 ELSE 0 END as tiene_imagen_pregunta,
            o_seleccionada.id as opcion_seleccionada_id,
            CASE 
                WHEN o_seleccionada.texto_opcion = 'SIN_RESPUESTA_INTENTO' THEN NULL 
                WHEN o_seleccionada.texto_opcion = 'INTENTO_TIMEOUT' THEN NULL
                ELSE o_seleccionada.texto_opcion 
            END as respuesta_usuario,
            CASE WHEN o_seleccionada.imagen_opcion IS NOT NULL THEN 1 ELSE 0 END as tiene_imagen_respuesta_usuario,
            CASE 
                WHEN o_seleccionada.texto_opcion IN ('SIN_RESPUESTA_INTENTO', 'INTENTO_TIMEOUT') THEN 0
                ELSE COALESCE(o_seleccionada.opcion_correcta, 0) 
            END as usuario_correcto,
            (SELECT texto_opcion FROM opcion_respuesta 
            WHERE id_pregunta = p.id AND opcion_correcta = 1 
            AND texto_opcion NOT IN ('SIN_RESPUESTA_INTENTO', 'INTENTO_TIMEOUT')
            LIMIT 1) as respuesta_correcta,
            (SELECT CASE WHEN imagen_opcion IS NOT NULL THEN 1 ELSE 0 END FROM opcion_respuesta 
            WHERE id_pregunta = p.id AND opcion_correcta = 1 
            AND texto_opcion NOT IN ('SIN_RESPUESTA_INTENTO', 'INTENTO_TIMEOUT')
            LIMIT 1) as tiene_imagen_respuesta_correcta,
            CASE 
                WHEN re.id IS NULL THEN 'No respondida' 
                WHEN o_seleccionada.texto_opcion IN ('SIN_RESPUESTA_INTENTO', 'INTENTO_TIMEOUT') THEN 'No respondida'
                ELSE 'Respondida' 
            END as estado_respuesta
        FROM 
            preguntas p
        LEFT JOIN 
            respuesta_estudiante re ON re.id_pregunta = p.id AND re.id_estudiante = :usuario_id AND re.id_cuestionario = :cuestionario_id
        LEFT JOIN 
            opcion_respuesta o_seleccionada ON re.id_opcion_seleccionada = o_seleccionada.id
        WHERE 
            p.id_cuestionario = :cuestionario_id
        ORDER BY 
            p.orden_pregunta
    ";
    
    $stmt_detalles = $db->prepare($query_detalles);
    $stmt_detalles->bindParam(':usuario_id', $_SESSION['usuario_id']);
    $stmt_detalles->bindParam(':cuestionario_id', $cuestionario_id);
    $stmt_detalles->execute();
    $detalles = $stmt_detalles->fetchAll(PDO::FETCH_ASSOC);

    // Procesar detalles para convertir los flags a boolean/null
    foreach ($detalles as &$detalle) {
        $detalle['imagen_pregunta'] = $detalle['tiene_imagen_pregunta'] ? true : null;
        $detalle['imagen_respuesta_usuario'] = $detalle['tiene_imagen_respuesta_usuario'] ? true : null;
        $detalle['imagen_respuesta_correcta'] = $detalle['tiene_imagen_respuesta_correcta'] ? true : null;
        $detalle['usuario_correcto'] = (bool)$detalle['usuario_correcto'];
        
        // Si no hay respuesta del usuario, marcar apropiadamente
        if ($detalle['estado_respuesta'] === 'No respondida') {
            // Si fue timeout, mostrar "NO RESPONDIDA", si no, mostrar null
            $detalle['respuesta_usuario'] = $fue_timeout ? 'NO RESPONDIDA' : null;
            $detalle['opcion_seleccionada_id'] = null;
            $detalle['imagen_respuesta_usuario'] = null;
            $detalle['usuario_correcto'] = false;
        }
        
        // Limpiar campos temporales
        unset($detalle['tiene_imagen_pregunta']);
        unset($detalle['tiene_imagen_respuesta_usuario']);
        unset($detalle['tiene_imagen_respuesta_correcta']);
        unset($detalle['estado_respuesta']);
    }

    // Agregar información sobre si fue timeout
    $resultado['fue_timeout'] = $fue_timeout;

    // Agregar detalles al resultado
    $resultado['detalles'] = $detalles;

    // Limpiar completamente el buffer y enviar respuesta
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($resultado, JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    error_log("Error en resultado_api.php: " . $e->getMessage());
    
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor'
    ], JSON_UNESCAPED_UNICODE);
}
?> 