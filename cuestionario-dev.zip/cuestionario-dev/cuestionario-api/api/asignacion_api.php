<?php
// Asegurarnos de que no se haya enviado ningún output antes
ob_start();

// Iniciar sesión antes de cualquier salida
session_start();

// Para depuración
error_reporting(E_ALL);
ini_set('display_errors', 0); // Cambiar a 0 para no mostrar errores en la salida
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Configuración de CORS
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-Requested-With, Authorization, Accept");
header('Content-Type: application/json; charset=utf-8');

// Responder inmediatamente a las solicitudes OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(['success' => true]);
    exit();
}

// Función para manejar errores y devolver siempre JSON
function handleError($errno, $errstr, $errfile, $errline) {
    $error = [
        'success' => false,
        'error' => 'Error del servidor: ' . $errstr,
        'details' => [
            'file' => $errfile,
            'line' => $errline
        ]
    ];
    
    // Limpiar cualquier output previo
    if (ob_get_length()) ob_clean();
    
    // Asegurar headers JSON
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($error);
    exit(1);
}

// Establecer el manejador de errores
set_error_handler('handleError');

try {
    // Incluir archivos necesarios
    require_once __DIR__ . '/cors.php';
    require_once __DIR__ . '/api.php';
    require_once __DIR__ . '/../model/conection.php';
    require_once __DIR__ . '/../config/urls.php';

    // Verificar si el usuario está autenticado
    $usuario_id = isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : null;

    // Si no hay sesión, intentar obtener el usuario del localStorage a través de un parámetro
    if (!$usuario_id && isset($_GET['usuario_id'])) {
        $usuario_id = $_GET['usuario_id'];
    }

    // Para desarrollo, si aún no hay usuario_id, usar un ID por defecto
    if (!$usuario_id) {
        $usuario_id = 3; // ID de usuario para desarrollo
    }

    // Log para depuración
    error_log("asignacion_api.php - Usuario ID: " . $usuario_id);

    // Crear conexión a la base de datos
    $conn = Conection::conectar();

    // Procesar solicitudes GET
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = isset($_GET['action']) ? $_GET['action'] : '';
        
        switch ($action) {
            case 'get_aperturas':
                // Obtener aperturas de cuestionarios disponibles
                $sql_aperturas = "SELECT a.id, c.titulo, c.descripcion, p.nombre as periodo_nombre, 
                                p.fecha_inicio, p.fecha_fin, pr.nombre as programa_nombre
                                FROM apertura a
                                JOIN relacion_cuestionario_programa rcp ON a.id_relacion_cuestionario_programa = rcp.id
                                JOIN cuestionario c ON rcp.id_cuestionario = c.id
                                JOIN periodo p ON a.id_periodo = p.id
                                JOIN programa pr ON rcp.id_programa = pr.id
                                WHERE rcp.id_docente = :docente_id";

                try {
                    $stmt = $conn->prepare($sql_aperturas);
                    $stmt->bindParam(':docente_id', $usuario_id, PDO::PARAM_INT);
                    $stmt->execute();
                    $aperturas = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    // Registrar para depuración
                    error_log("Usuario ID: " . $usuario_id . ", Aperturas encontradas: " . count($aperturas));
                    
                    echo json_encode(['success' => true, 'aperturas' => $aperturas]);
                } catch (PDOException $e) {
                    error_log("Error en get_aperturas: " . $e->getMessage());
                    throw new Exception('Error al obtener aperturas: ' . $e->getMessage());
                }
                break;
                
            case 'get_estudiantes':
                // Obtener estudiantes
                
                try {
                    // Variables por defecto
                    $programa_docente = null;
                    $es_admin = false;
                    
                    try {
                        // Verificar si el usuario tiene un programa asignado
                        $sql_programa = "SELECT usuario_programa FROM usuario WHERE id = :usuario_id";
                        $stmt = $conn->prepare($sql_programa);
                        $stmt->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
                        $stmt->execute();
                        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
                        $programa_docente = $resultado && isset($resultado['usuario_programa']) ? $resultado['usuario_programa'] : null;
                        
                        // Verificar si es admin
                        $sql_email = "SELECT email FROM usuario WHERE id = :usuario_id";
                        $stmt = $conn->prepare($sql_email);
                        $stmt->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
                        $stmt->execute();
                        $resultado_email = $stmt->fetch(PDO::FETCH_ASSOC);
                        $es_admin = ($resultado_email && $resultado_email['email'] === 'admin');
                    } catch (PDOException $e) {
                        // Si hay error al consultar la tabla usuario, continuamos con los valores por defecto
                        error_log("Error al consultar tabla usuario: " . $e->getMessage());
                    }
                    
                    // Si es admin o no tiene programa asignado, muestra todos los estudiantes
                    if ($es_admin || $programa_docente === null) {
                        $sql_estudiantes = "SELECT e.id, e.nombre, e.email, e.identificacion, p.nombre as programa_nombre
                                        FROM estudiante e
                                        JOIN programa p ON e.id_programa = p.id
                                        ORDER BY e.nombre";
                        $stmt = $conn->prepare($sql_estudiantes);
                    } else {
                        $sql_estudiantes = "SELECT e.id, e.nombre, e.email, e.identificacion, p.nombre as programa_nombre
                                        FROM estudiante e
                                        JOIN programa p ON e.id_programa = p.id
                                        WHERE e.id_programa = :programa_id
                                        ORDER BY e.nombre";
                    $stmt = $conn->prepare($sql_estudiantes);
                        $stmt->bindParam(':programa_id', $programa_docente, PDO::PARAM_INT);
                    }
                    
                    $stmt->execute();
                    $estudiantes = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    // Registrar para depuración
                    error_log("Usuario ID: " . $usuario_id . ", Programa: " . $programa_docente . ", Es admin: " . ($es_admin ? 'Sí' : 'No'));
                    error_log("Estudiantes encontrados: " . count($estudiantes));
                    
                    echo json_encode(['success' => true, 'estudiantes' => $estudiantes]);
                } catch (PDOException $e) {
                    error_log("Error en get_estudiantes: " . $e->getMessage());
                    throw new Exception('Error al obtener estudiantes: ' . $e->getMessage());
                }
                break;
                
            case 'get_asignaciones':
                // Obtener asignaciones existentes
                $sql_asignaciones = "SELECT a.id, a.id_apertura, a.id_estudiante, 
                                e.nombre as estudiante_nombre, e.email,
                                c.titulo as cuestionario_titulo, p.nombre as periodo_nombre
                                FROM asignacion a
                                JOIN estudiante e ON a.id_estudiante = e.id
                                JOIN apertura ap ON a.id_apertura = ap.id
                                JOIN relacion_cuestionario_programa rcp ON ap.id_relacion_cuestionario_programa = rcp.id
                                JOIN cuestionario c ON rcp.id_cuestionario = c.id
                                JOIN periodo p ON ap.id_periodo = p.id
                                WHERE rcp.id_docente = :docente_id";

                try {
                    $stmt = $conn->prepare($sql_asignaciones);
                    $stmt->bindParam(':docente_id', $usuario_id, PDO::PARAM_INT);
                    $stmt->execute();
                    $asignaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    // Registrar para depuración
                    error_log("Usuario ID: " . $usuario_id . ", Asignaciones encontradas: " . count($asignaciones));
                    
                    echo json_encode(['success' => true, 'asignaciones' => $asignaciones]);
                } catch (PDOException $e) {
                    error_log("Error en get_asignaciones: " . $e->getMessage());
                    throw new Exception('Error al obtener asignaciones: ' . $e->getMessage());
                }
                break;
                
            case 'eliminar':
                // Verificar que se haya proporcionado un ID
                if (isset($_GET['id'])) {
                    $id = $_GET['id'];
                    
                    // Eliminar la asignación
                    $sql_eliminar = "DELETE FROM asignacion WHERE id = :id";
                    
                    try {
                        $stmt = $conn->prepare($sql_eliminar);
                        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
                        $stmt->execute();
                        
                        if ($stmt->rowCount() > 0) {
                            echo json_encode(['success' => true, 'message' => 'Asignación eliminada con éxito']);
                        } else {
                            http_response_code(404);
                            echo json_encode(['success' => false, 'error' => 'No se encontró la asignación con el ID proporcionado']);
                        }
                    } catch (PDOException $e) {
                        throw new Exception('Error al eliminar la asignación: ' . $e->getMessage());
                    }
                } else {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Debe proporcionar el ID de la asignación a eliminar']);
                }
                break;
                
            default:
                throw new Exception('Acción no válida');
        }
    } 

    // Procesar solicitudes POST
    else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Para solicitudes JSON
        $contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
        
        if (strpos($contentType, 'application/json') !== false) {
            $rawData = file_get_contents("php://input");
            
            $data = json_decode($rawData, true);
            
            $action = isset($data['action']) ? $data['action'] : '';
            
            switch ($action) {
                case 'asignar':
                    $apertura_id = isset($data['apertura_id']) ? $data['apertura_id'] : null;
                    $estudiante_ids = isset($data['estudiante_ids']) ? $data['estudiante_ids'] : [];
                    
                    if (!empty($estudiante_ids) && !empty($apertura_id)) {
                        // Preparar la consulta para insertar asignaciones
                        $stmt = $conn->prepare("INSERT IGNORE INTO asignacion (id_apertura, id_estudiante) VALUES (:apertura_id, :estudiante_id)");
                        
                        $exito = true;
                        $conn->beginTransaction();
                        
                        try {
                            foreach ($estudiante_ids as $estudiante_id) {
                                $stmt->bindParam(':apertura_id', $apertura_id, PDO::PARAM_INT);
                                $stmt->bindParam(':estudiante_id', $estudiante_id, PDO::PARAM_INT);
                                $stmt->execute();
                            }
                            
                            // Obtener información del cuestionario para el link
                            $sql_info = "SELECT c.id as cuestionario_id, c.titulo, e.email, e.nombre 
                                   FROM apertura a 
                                   JOIN relacion_cuestionario_programa rcp ON a.id_relacion_cuestionario_programa = rcp.id 
                                   JOIN cuestionario c ON rcp.id_cuestionario = c.id 
                                   JOIN estudiante e ON e.id = :estudiante_id 
                                   WHERE a.id = :apertura_id";
                        
                        $stmt_info = $conn->prepare($sql_info);
                        $stmt_info->bindParam(':apertura_id', $apertura_id, PDO::PARAM_INT);
                        $stmt_info->bindParam(':estudiante_id', $estudiante_id, PDO::PARAM_INT);
                        $stmt_info->execute();
                        $info = $stmt_info->fetch(PDO::FETCH_ASSOC);
                        
                        if ($info) {
                            // Usar la nueva función para generar el link
                            $link = getUrlCuestionario($info['cuestionario_id']);
                            
                            // Aquí iría el código para enviar el email con el nuevo link
                            // ...
                            }
                            
                            $conn->commit();
                            
                            echo json_encode(['success' => true, 'message' => 'Asignación realizada con éxito']);
                        } catch (PDOException $e) {
                            $conn->rollBack();
                            throw new Exception('Error al realizar las asignaciones: ' . $e->getMessage());
                        }
                    } else {
                        http_response_code(400);
                        echo json_encode(['success' => false, 'error' => 'Debe seleccionar al menos un estudiante y un cuestionario']);
                    }
                    break;
                    
                default:
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Acción no válida']);
                    break;
            }
        }
        // Para solicitudes multipart/form-data (importar estudiantes)
        else if (isset($_POST['action']) && $_POST['action'] === 'importar_estudiantes') {
            
            if (!isset($_FILES['archivo_estudiantes']) || $_FILES['archivo_estudiantes']['error'] !== UPLOAD_ERR_OK) {
                
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Error al subir el archivo']);
                exit;
            }
            
            // Verificar que sea un archivo CSV
            $archivo_tmp = $_FILES['archivo_estudiantes']['tmp_name'];
            $nombre_archivo = $_FILES['archivo_estudiantes']['name'];
            $extension = pathinfo($nombre_archivo, PATHINFO_EXTENSION);
            
            if (strtolower($extension) !== 'csv') {
                
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'El archivo debe ser CSV']);
                exit;
            }
            
            // Abrir el archivo
            if (($handle = fopen($archivo_tmp, "r")) === FALSE) {
                
                http_response_code(500);
                echo json_encode(['success' => false, 'error' => 'No se pudo abrir el archivo']);
                exit;
            }
            
            // Iniciar transacción
            $conn->beginTransaction();
            
            try {
                // Preparar la consulta para insertar estudiantes
                $stmt = $conn->prepare("INSERT INTO estudiante (nombre, email, identificacion, id_programa) VALUES (:nombre, :email, :identificacion, :id_programa)");
                
                // Contador de estudiantes importados
                $contador = 0;
                $errores = [];
                
                // Leer la primera línea (encabezados) y descartarla
                fgetcsv($handle, 1000, ",");
                
                // Leer cada línea del CSV
                while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                    // Si hay menos de 4 columnas, intentar con punto y coma como delimitador
                    if (count($data) < 4) {
                        // Volver al inicio del archivo
                        rewind($handle);
                        // Descartar la primera línea
                        fgetcsv($handle, 1000, ";");
                        
                        // Leer con punto y coma como delimitador
                        while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
                            if (count($data) >= 4) {
                                $nombre = trim($data[0]);
                                $email = trim($data[1]);
                                $identificacion = trim($data[2]);
                                $id_programa = trim($data[3]);
                                
                                // Validar datos
                                if (empty($nombre) || empty($email) || empty($identificacion) || empty($id_programa)) {
                                    $errores[] = "Fila con datos incompletos: " . implode(", ", $data);
                                    continue;
                                }
                                
                                try {
                                    $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
                                    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
                                    $stmt->bindParam(':identificacion', $identificacion, PDO::PARAM_STR);
                                    $stmt->bindParam(':id_programa', $id_programa, PDO::PARAM_INT);
                                    $stmt->execute();
                                    $contador++;
                                } catch (PDOException $e) {
                                    // Si es un error de duplicado, ignorarlo y continuar
                                    if ($e->getCode() == 23000) {
                                        $errores[] = "Estudiante duplicado: $email o $identificacion";
                                    } else {
                                        throw $e;
                                    }
                                }
                            } else {
                                $errores[] = "Fila con formato incorrecto: " . implode(", ", $data);
                            }
                        }
                        break; // Salir del primer bucle while
                    } else {
                        $nombre = trim($data[0]);
                        $email = trim($data[1]);
                        $identificacion = trim($data[2]);
                        $id_programa = trim($data[3]);
                        
                        // Validar datos
                        if (empty($nombre) || empty($email) || empty($identificacion) || empty($id_programa)) {
                            $errores[] = "Fila con datos incompletos: " . implode(", ", $data);
                            continue;
                        }
                        
                        try {
                            $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
                            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
                            $stmt->bindParam(':identificacion', $identificacion, PDO::PARAM_STR);
                            $stmt->bindParam(':id_programa', $id_programa, PDO::PARAM_INT);
                            $stmt->execute();
                            $contador++;
                        } catch (PDOException $e) {
                            // Si es un error de duplicado, ignorarlo y continuar
                            if ($e->getCode() == 23000) {
                                $errores[] = "Estudiante duplicado: $email o $identificacion";
                            } else {
                                throw $e;
                            }
                        }
                    }
                }
                
                // Cerrar el archivo
                fclose($handle);
                
                // Confirmar la transacción
                $conn->commit();
                
                // Respuesta
                $mensaje = "Se importaron $contador estudiantes correctamente.";
                if (!empty($errores)) {
                    $mensaje .= " Hubo " . count($errores) . " errores.";
                }
                
                echo json_encode([
                    'success' => true, 
                    'message' => $mensaje,
                    'importados' => $contador,
                    'errores' => $errores
                ]);
                
            } catch (Exception $e) {
                // Revertir la transacción
                $conn->rollBack();
                
                throw new Exception('Error al importar estudiantes: ' . $e->getMessage());
            }
        }
        else {
            
            echo json_encode(['success' => false, 'error' => 'Tipo de contenido no soportado']);
        }
    } 
} catch (Exception $e) {
    // Limpiar cualquier output previo
    if (ob_get_length()) ob_clean();
    
    // Asegurar headers JSON
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

// Asegurarse de que todo el output sea enviado y limpiar el buffer
ob_end_flush(); 