<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');
// Configuración de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Configurar y iniciar sesión
if (session_status() === PHP_SESSION_NONE) {
    // Configurar parámetros de la sesión para consistencia
    ini_set('session.cookie_secure', 'false'); // false para desarrollo local sin HTTPS
    ini_set('session.cookie_httponly', 'true');
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.cookie_domain', 'localhost');
    ini_set('session.cookie_path', '/');
    ini_set('session.use_cookies', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', '86400'); // 24 horas de duración de sesión
    
    session_start();
}

// Log de depuración mínimo
error_log("Verificando sesión para usuario ID: " . ($_SESSION['usuario_id'] ?? 'no definido'));

// Si es una solicitud OPTIONS (preflight), terminar aquí
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

try {
    // Verificar si hay sesión activa
    if (!isset($_SESSION['usuario_id'])) {
        error_log("No hay usuario_id en la sesión");
        echo json_encode([
            'success' => false,
            'autenticado' => false,
            'error' => "No has iniciado sesión o tu sesión ha expirado"
        ]);
        exit;
    }



    // Construir objeto de usuario completo
    $usuario = [
        'id' => $_SESSION['usuario_id'],
        'nombre' => $_SESSION['usuario_nombre'] ?? '',
        'email' => $_SESSION['usuario_email'] ?? '',
        'rol' => $_SESSION['usuario_rol'] ?? ''
    ];

    echo json_encode([
        'success' => true,
        'autenticado' => true,
        'message' => 'Sesión activa',
        'usuario' => $usuario
    ]);

} catch (Exception $e) {
    error_log("Error en verificar_sesion.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'autenticado' => false,
        'error' => $e->getMessage()
    ]);
} 