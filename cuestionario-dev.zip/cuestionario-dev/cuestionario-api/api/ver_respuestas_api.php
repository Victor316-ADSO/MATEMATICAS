<?php
// Incluir configuración CORS centralizada
require_once __DIR__ . "/cors.php";

if (!isset($_SESSION["usuario_id"])) {
    http_response_code(401);
    echo json_encode(["error" => "No autenticado"]);
    exit;
}

require_once __DIR__ . "/../model/conection.php";

try {
    $db = Conection::conectar();
    $estudiante_id = isset($_GET["estudiante_id"]) ? (int)$_GET["estudiante_id"] : 0;
    $cuestionario_id = isset($_GET["cuestionario_id"]) ? (int)$_GET["cuestionario_id"] : 0;

    if ($estudiante_id <= 0 || $cuestionario_id <= 0) {
        throw new Exception("Parametros no validos");
    }

    $query_estudiante = "SELECT e.id, e.nombre, e.email, e.identificacion, p.nombre as programa_nombre FROM estudiante e JOIN programa p ON e.id_programa = p.id WHERE e.id = :estudiante_id";
    $stmt_estudiante = $db->prepare($query_estudiante);
    $stmt_estudiante->bindParam(":estudiante_id", $estudiante_id);
    $stmt_estudiante->execute();
    $estudiante = $stmt_estudiante->fetch(PDO::FETCH_ASSOC);

    if (!$estudiante) {
        throw new Exception("Estudiante no encontrado");
    }

    $query_cuestionario = "SELECT c.id, c.titulo, c.descripcion FROM cuestionario c JOIN relacion_cuestionario_programa rcp ON c.id = rcp.id_cuestionario WHERE c.id = :cuestionario_id AND rcp.id_docente = :usuario_id";
    $stmt_cuestionario = $db->prepare($query_cuestionario);
    $stmt_cuestionario->bindParam(":cuestionario_id", $cuestionario_id);
    $stmt_cuestionario->bindParam(":usuario_id", $_SESSION["usuario_id"]);
    $stmt_cuestionario->execute();
    $cuestionario = $stmt_cuestionario->fetch(PDO::FETCH_ASSOC);

    if (!$cuestionario) {
        throw new Exception("Cuestionario no encontrado o sin permisos");
    }

    // Obtener las respuestas del estudiante
    $query_respuestas = "
        SELECT 
            re.id_pregunta,
            re.id_opcion_seleccionada,
            re.fecha_respuesta,
            p.texto_pregunta,
            p.peso_pregunta,
            CASE WHEN p.imagen_pregunta IS NOT NULL THEN 1 ELSE 0 END as tiene_imagen_pregunta,
            o_sel.opcion_correcta as respuesta_es_correcta
        FROM respuesta_estudiante re
        JOIN preguntas p ON re.id_pregunta = p.id
        JOIN opcion_respuesta o_sel ON re.id_opcion_seleccionada = o_sel.id
        WHERE re.id_estudiante = :estudiante_id 
        AND re.id_cuestionario = :cuestionario_id
        ORDER BY p.orden_pregunta
    ";
    $stmt_respuestas = $db->prepare($query_respuestas);
    $stmt_respuestas->bindParam(":estudiante_id", $estudiante_id);
    $stmt_respuestas->bindParam(":cuestionario_id", $cuestionario_id);
    $stmt_respuestas->execute();
    $respuestas_estudiante = $stmt_respuestas->fetchAll(PDO::FETCH_ASSOC);

    if (empty($respuestas_estudiante)) {
        throw new Exception("No se encontraron respuestas para este estudiante en este cuestionario");
    }

    // Obtener todas las opciones para cada pregunta respondida
    $preguntas_ids = array_column($respuestas_estudiante, 'id_pregunta');
    $preguntas_ids_str = implode(',', $preguntas_ids);
    
    $query_opciones = "
        SELECT 
            o.id,
            o.id_pregunta,
            o.texto_opcion,
            o.opcion_correcta as es_correcta,
            CASE WHEN o.imagen_opcion IS NOT NULL THEN 1 ELSE 0 END as tiene_imagen_opcion,
            o.orden
        FROM opcion_respuesta o
        WHERE o.id_pregunta IN ($preguntas_ids_str)
        ORDER BY o.id_pregunta, o.orden
    ";
    $stmt_opciones = $db->prepare($query_opciones);
    $stmt_opciones->execute();
    $opciones_todas = $stmt_opciones->fetchAll(PDO::FETCH_ASSOC);

    // Agrupar opciones por pregunta
    $opciones_por_pregunta = [];
    foreach ($opciones_todas as $opcion) {
        $opciones_por_pregunta[$opcion['id_pregunta']][] = [
            'id' => (int)$opcion['id'],
            'texto_opcion' => $opcion['texto_opcion'],
            'es_correcta' => (bool)$opcion['es_correcta'],
            'imagen_opcion' => $opcion['tiene_imagen_opcion'] ? true : null,
            'nombre_imagen_opcion' => null
        ];
    }

    // Construir respuestas detalladas
    $respuestas_detalladas = [];
    $total_preguntas = count($respuestas_estudiante);
    $respuestas_correctas = 0;
    $puntaje_total = 0;
    $puntaje_obtenido = 0;
    $fecha_respuesta = null;

    foreach ($respuestas_estudiante as $respuesta) {
        $pregunta_id = (int)$respuesta['id_pregunta'];
        $opciones_pregunta = $opciones_por_pregunta[$pregunta_id] ?? [];
        $es_correcta = (bool)$respuesta['respuesta_es_correcta'];
        $peso_pregunta = (float)$respuesta['peso_pregunta'];
        
        if ($es_correcta) {
            $respuestas_correctas++;
            $puntaje_obtenido += $peso_pregunta;
        }
        $puntaje_total += $peso_pregunta;
        
        if (!$fecha_respuesta) {
            $fecha_respuesta = $respuesta['fecha_respuesta'];
        }

        $respuestas_detalladas[] = [
            'pregunta_id' => $pregunta_id,
            'texto_pregunta' => $respuesta['texto_pregunta'],
            'peso_pregunta' => $peso_pregunta,
            'imagen_pregunta' => $respuesta['tiene_imagen_pregunta'] ? true : null,
            'nombre_imagen_pregunta' => null,
            'id_opcion_seleccionada' => (int)$respuesta['id_opcion_seleccionada'],
            'es_correcta' => $es_correcta,
            'opciones' => $opciones_pregunta
        ];
    }

    // Calcular estadísticas
    $porcentaje = $puntaje_total > 0 ? round(($puntaje_obtenido / $puntaje_total) * 100, 2) : 0;

    $estadisticas = [
        "fecha_respuesta" => $fecha_respuesta,
        "total_respondidas" => $total_preguntas,
        "total_preguntas" => $total_preguntas,
        "respuestas_correctas" => $respuestas_correctas,
        "puntaje_total" => $puntaje_total,
        "puntaje_obtenido" => $puntaje_obtenido,
        "porcentaje" => $porcentaje
    ];

    echo json_encode([
        "estudiante" => $estudiante,
        "cuestionario" => $cuestionario,
        "estadisticas" => $estadisticas,
        "respuestas" => $respuestas_detalladas
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["error" => $e->getMessage()]);
}
?>
