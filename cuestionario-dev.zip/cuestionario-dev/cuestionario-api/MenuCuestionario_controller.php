<?php
// Iniciar sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Incluir la conexión a la base de datos
require_once 'model/conection.php';

$database = new Database();
$db = $database->connect();

// Obtener cuestionarios del usuario actual
$query_mis_cuestionarios = "SELECT rcp.*, c.titulo, c.descripcion FROM relacion_cuestionario_programa rcp 
JOIN cuestionario c ON rcp.id_cuestionario = c.id
WHERE id_docente = :docente_id";
$stmt_mis = $db->prepare($query_mis_cuestionarios);
$stmt_mis->bindParam(':docente_id', $_SESSION['usuario_id']);
$stmt_mis->execute();
$mis_cuestionarios = $stmt_mis->fetchAll();

// Obtener cuestionarios abiertos (con periodo asignado)
$query_cuestionarios_abiertos = "
    SELECT 
        a.id as apertura_id,
        c.id as cuestionario_id,
        c.titulo,
        c.descripcion,
        p.id as periodo_id,
        p.nombre as periodo_nombre,
        p.fecha_inicio,
        p.fecha_fin,
        d.nombre as creador_nombre,
        prog.nombre as programa_nombre
    FROM 
        apertura a
    JOIN 
        relacion_cuestionario_programa rcp ON a.id_relacion_cuestionario_programa = rcp.id
    JOIN 
        cuestionario c ON rcp.id_cuestionario = c.id
    JOIN 
        periodo p ON a.id_periodo = p.id
    JOIN 
        docente d ON rcp.id_docente = d.id
    JOIN 
        programa prog ON rcp.id_programa = prog.id
    WHERE 
        rcp.activo = 1
        AND rcp.id_docente = :usuario_id
    ORDER BY 
        p.fecha_inicio DESC, c.titulo ASC
";
$stmt_abiertos = $db->prepare($query_cuestionarios_abiertos);
$stmt_abiertos->bindParam(':usuario_id', $_SESSION['usuario_id']);
$stmt_abiertos->execute();
$cuestionarios_abiertos = $stmt_abiertos->fetchAll();

// Obtener cuestionarios de otros usuarios (que no ha resuelto)
$query_otros_cuestionarios = "
    SELECT 
    c.id,
    c.titulo,
    c.descripcion,
    rcp.id as relacion_id,
    rcp.id_docente,
    d.nombre AS creador_nombre,
    p.nombre AS programa_nombre,
    n.nombre AS nivel_nombre,
    cam.nombre AS campus_nombre
FROM 
    relacion_cuestionario_programa rcp
JOIN 
    cuestionario c ON rcp.id_cuestionario = c.id
JOIN 
    docente d ON rcp.id_docente = d.id
JOIN 
    programa p ON rcp.id_programa = p.id
JOIN 
    nivel n ON p.id_nivel = n.id
JOIN 
    campus cam ON p.id_campus = cam.id
LEFT JOIN 
    respuesta_estudiante re ON (
        re.id_estudiante = :usuario_id 
        AND re.id_cuestionario = c.id
    )
WHERE 
    rcp.activo = 1
    AND rcp.id_docente != :docente_id
    AND re.id IS NULL
ORDER BY 
    rcp.id DESC
";
$stmt_otros = $db->prepare($query_otros_cuestionarios);
$stmt_otros->bindParam(':docente_id', $_SESSION['usuario_id']);
$stmt_otros->bindParam(':usuario_id', $_SESSION['usuario_id']);
$stmt_otros->execute();
$otros_cuestionarios = $stmt_otros->fetchAll();

// Obtener resultados de cuestionarios resueltos
$query_resultados = "
    SELECT 
        re.id,
        re.id_cuestionario,
        re.fecha_respuesta,
        c.titulo as cuestionario_titulo,
        d.nombre as creador_nombre,
        p.nombre as programa_nombre,
        COUNT(re.id) as total_respondidas,
        (SELECT COUNT(*) FROM preguntas WHERE id_cuestionario = c.id) as total_preguntas,
        (SELECT COUNT(*) FROM respuesta_estudiante re2 
         JOIN opcion_respuesta op ON re2.id_opcion_seleccionada = op.id 
         WHERE re2.id_cuestionario = re.id_cuestionario 
         AND re2.id_estudiante = re.id_estudiante 
         AND op.opcion_correcta = 1) as respuestas_correctas,
        (SELECT SUM(peso_pregunta) FROM preguntas WHERE id_cuestionario = c.id) as puntaje_total,
        (SELECT SUM(p.peso_pregunta) 
         FROM respuesta_estudiante re2 
         JOIN opcion_respuesta op ON re2.id_opcion_seleccionada = op.id 
         JOIN preguntas p ON re2.id_pregunta = p.id
         WHERE re2.id_cuestionario = re.id_cuestionario 
         AND re2.id_estudiante = re.id_estudiante 
         AND op.opcion_correcta = 1) as puntaje_obtenido,
        CASE 
            WHEN (SELECT SUM(peso_pregunta) FROM preguntas WHERE id_cuestionario = c.id) > 0 
            THEN ROUND(((SELECT SUM(p.peso_pregunta) 
                FROM respuesta_estudiante re2 
                JOIN opcion_respuesta op ON re2.id_opcion_seleccionada = op.id 
                JOIN preguntas p ON re2.id_pregunta = p.id
                WHERE re2.id_cuestionario = re.id_cuestionario 
                AND re2.id_estudiante = re.id_estudiante 
                AND op.opcion_correcta = 1) / 
                (SELECT SUM(peso_pregunta) FROM preguntas WHERE id_cuestionario = c.id)) * 100)
            ELSE 0
        END as porcentaje
    FROM 
        respuesta_estudiante re
    JOIN 
        cuestionario c ON re.id_cuestionario = c.id
    JOIN
        relacion_cuestionario_programa rcp ON c.id = rcp.id_cuestionario
    JOIN 
        docente d ON rcp.id_docente = d.id
    JOIN 
        programa p ON rcp.id_programa = p.id
    WHERE 
        re.id_estudiante = :usuario_id
        AND rcp.activo = 1
    GROUP BY 
        re.id_estudiante, re.id_cuestionario
    ORDER BY 
        re.fecha_respuesta DESC
";
$stmt_resultados = $db->prepare($query_resultados);
$stmt_resultados->bindParam(':usuario_id', $_SESSION['usuario_id']);
$stmt_resultados->execute();
$resultados = $stmt_resultados->fetchAll();