 <?php /*
define('BASE_PATH', dirname(dirname(__FILE__)));

// Incluir archivos necesarios usando rutas absolutas
require_once __DIR__ . '/api/cors.php'; // Bien si es solo una vez
require_once __DIR__ . '/api/api.php';
require_once __DIR__ . '/model/conection.php';

// Asegurarse de que la sesión esté iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Establecer el tipo de contenido como JSON
header('Content-Type: application/json');

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode([
        'success' => false,
        'error' => 'No autorizado'
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $database = new Database();
        $db = $database->connect();

        // Obtener cuestionarios creados por el usuario
        $query = "SELECT id, titulo, descripcion, fecha_creacion FROM cuestionario WHERE creador_id = :usuario_id ORDER BY fecha_creacion DESC";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':usuario_id', $_SESSION['usuario_id']);
        $stmt->execute();
        $misCuestionarios = $stmt->fetchAll();

        // Obtener cuestionarios disponibles para resolver
        $query = "SELECT c.id, c.titulo, c.descripcion, c.fecha_creacion, c.fecha_inicio, c.fecha_fin, 
                         d.nombre as creador_nombre
                  FROM cuestionario c
                  JOIN docente d ON c.creador_id = d.id
                  WHERE c.creador_id != :usuario_id
                  ORDER BY c.fecha_creacion DESC";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':usuario_id', $_SESSION['usuario_id']);
        $stmt->execute();
        $cuestionariosDisponibles = $stmt->fetchAll();

        // Obtener resultados de cuestionarios resueltos
        $query = "SELECT r.id, c.titulo as cuestionario_titulo, r.puntaje_obtenido, 
                         r.puntaje_total, r.porcentaje, r.fecha_completado,
                         d.nombre as creador_nombre
                  FROM resultado r
                  JOIN cuestionario c ON r.cuestionario_id = c.id
                  JOIN docente d ON c.creador_id = d.id
                  WHERE r.usuario_id = :usuario_id
                  ORDER BY r.fecha_completado DESC";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':usuario_id', $_SESSION['usuario_id']);
        $stmt->execute();
        $resultados = $stmt->fetchAll();

        echo json_encode([
            'success' => true,
            'misCuestionarios' => $misCuestionarios,
            'cuestionariosDisponibles' => $cuestionariosDisponibles,
            'resultados' => $resultados
        ]);
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'error' => 'Error en el servidor: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido'
    ]);
} */ ?>