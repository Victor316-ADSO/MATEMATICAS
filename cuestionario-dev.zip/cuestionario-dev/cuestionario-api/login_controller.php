<?php
// ==== CORS HEADERS ====
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// ==== PREVENT OPTIONS ====
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// ==== ERRORES ====
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// ==== INICIAR SESIÓN ====
// Configurar parámetros de la sesión antes de iniciarla
$domain = 'localhost';
ini_set('session.cookie_secure', 'false'); // false para desarrollo local sin HTTPS
ini_set('session.cookie_httponly', 'true');
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.cookie_domain', $domain);
ini_set('session.cookie_path', '/');
ini_set('session.use_cookies', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.gc_maxlifetime', '86400'); // 24 horas

session_start();

// Registrar información de depuración
error_log("Login iniciado - Session ID: " . session_id());
error_log("Cookies recibidas: " . print_r($_COOKIE, true));

// ==== OBTENER JSON ====
$input = json_decode(file_get_contents('php://input'), true);
$email = $input['email'] ?? '';
$passwordOrId = $input['password'] ?? ''; // será identificación para estudiante

if (empty($email) || empty($passwordOrId)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Email y contraseña/identificación requeridos']);
    exit();
}

// ==== CONEXIÓN ====
require_once './model/conection.php';
$db = Conection::conectar();

// ==== BUSCAR EN ESTUDIANTE (email + identificación) ====
$query = "SELECT id, nombre, email, identificacion FROM estudiante WHERE email = :email AND identificacion = :identificacion";
$stmt = $db->prepare($query);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':identificacion', $passwordOrId);
$stmt->execute();

if ($stmt->rowCount() === 1) {
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $_SESSION['usuario_id'] = $user['id'];
    $_SESSION['usuario_nombre'] = $user['nombre'];
    $_SESSION['usuario_email'] = $user['email'];
    $_SESSION['usuario_rol'] = 'estudiante';
    
    // Forzar escritura de la sesión
    session_write_close();
    session_start();
    
    error_log("Login exitoso (estudiante) - Session ID: " . session_id());
    error_log("Datos de sesión: " . print_r($_SESSION, true));

    echo json_encode([
        'success' => true,
        'usuario' => [
            'id' => $user['id'],
            'nombre' => $user['nombre'],
            'email' => $user['email'],
            'rol' => 'estudiante'
        ]
    ]);
    exit();
}

// ==== BUSCAR EN DOCENTE (email + password) ====
$query = "SELECT id, nombre, email, password, programa_id FROM docente WHERE email = :email";
$stmt = $db->prepare($query);
$stmt->bindParam(':email', $email);
$stmt->execute();

if ($stmt->rowCount() === 1) {
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (password_verify($passwordOrId, $user['password'])) {
        $_SESSION['usuario_id'] = $user['id'];
        $_SESSION['usuario_nombre'] = $user['nombre'];
        $_SESSION['usuario_email'] = $user['email'];
        $_SESSION['usuario_programa'] = $user['programa_id'];
        $_SESSION['usuario_rol'] = 'docente';
        
        // Forzar escritura de la sesión
        session_write_close();
        session_start();
        
        error_log("Login exitoso (docente) - Session ID: " . session_id());
        error_log("Datos de sesión: " . print_r($_SESSION, true));

        echo json_encode([
            'success' => true,
            'usuario' => [
                'id' => $user['id'],
                'nombre' => $user['nombre'],
                'email' => $user['email'],
                'rol' => 'docente'
            ]
        ]);
        exit();
    }
}

// ==== SI FALLA ====
http_response_code(401);
echo json_encode(['success' => false, 'error' => 'Credenciales incorrectas']);
exit();
