<?php
// Configurar registro de errores
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', '../controller_errors.log');

try {
    // Configurar encabezados CORS
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    header("Access-Control-Allow-Credentials: true");

    // Manejar la solicitud OPTIONS (preflight)
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
        // Responder exitosamente a la solicitud preflight
        header("HTTP/1.1 200 OK");
        exit;
    }

    // Registrar la solicitud para depuración
    $log_message = "Solicitud recibida: " . date('Y-m-d H:i:s') . "\n";
    $log_message .= "Método: " . $_SERVER['REQUEST_METHOD'] . "\n";
    $log_message .= "URL: " . $_SERVER['REQUEST_URI'] . "\n";
    file_put_contents('../controller_debug.log', $log_message, FILE_APPEND);

    // Definir función sanitize_input localmente por si no está disponible
    if (!function_exists('sanitize_input')) {
        function sanitize_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
    }

    // Incluir archivos necesarios
    include_once '../api/api.php';
    require_once '../model/conection.php';

    $response = array('success' => false);

    // Obtener la lista de programas de la base de datos
    try {
        $db = Conection::conectar();
        $query_programas = "SELECT id, nombre FROM programa ORDER BY nombre";
        $stmt_programas = $db->prepare($query_programas);
        $stmt_programas->execute();
        $programas = $stmt_programas->fetchAll(PDO::FETCH_ASSOC);
        
        // Registrar éxito de conexión
        file_put_contents('../controller_debug.log', "Conexión a BD exitosa\n", FILE_APPEND);
    } catch (PDOException $e) {
        // Registrar error de conexión
        file_put_contents('../controller_debug.log', "Error de conexión a BD: " . $e->getMessage() . "\n", FILE_APPEND);
        $response['error'] = "Error de conexión a la base de datos: " . $e->getMessage();
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Registrar datos POST
        file_put_contents('../controller_debug.log', "Datos POST recibidos\n", FILE_APPEND);
        
        // Obtener datos del cuerpo de la solicitud
        $input = file_get_contents('php://input');
        file_put_contents('../controller_debug.log', "Input raw: " . $input . "\n", FILE_APPEND);
        
        $data = json_decode($input, true);
        
        if ($data) {
            file_put_contents('../controller_debug.log', "Datos JSON decodificados: " . json_encode($data) . "\n", FILE_APPEND);
            $nombre = isset($data['nombre']) ? sanitize_input($data['nombre']) : '';
            $email = isset($data['email']) ? sanitize_input($data['email']) : '';
            $identificacion = isset($data['identificacion']) ? sanitize_input($data['identificacion']) : '';
            $password = isset($data['password']) ? $data['password'] : '';
            $confirmar_password = isset($data['confirmar_password']) ? $data['confirmar_password'] : '';
            $programa_id = isset($data['programa_id']) ? intval($data['programa_id']) : 0;
        } else {
            file_put_contents('../controller_debug.log', "Usando datos POST tradicionales\n", FILE_APPEND);
            // Fallback a POST tradicional si no hay JSON
            $nombre = isset($_POST['nombre']) ? sanitize_input($_POST['nombre']) : '';
            $email = isset($_POST['email']) ? sanitize_input($_POST['email']) : '';
            $identificacion = isset($_POST['identificacion']) ? sanitize_input($_POST['identificacion']) : '';
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            $confirmar_password = isset($_POST['confirmar_password']) ? $_POST['confirmar_password'] : '';
            $programa_id = isset($_POST['programa_id']) ? intval($_POST['programa_id']) : 0;
        }

        file_put_contents('../controller_debug.log', "Datos procesados: nombre=$nombre, email=$email, id=$identificacion, programa=$programa_id\n", FILE_APPEND);

        if (empty($nombre) || empty($email) || empty($identificacion) || empty($password) || empty($confirmar_password)) {
            $response['error'] = 'Todos los campos son obligatorios';
        } elseif ($password !== $confirmar_password) {
            $response['error'] = 'Las contraseñas no coinciden';
        } elseif (strlen($password) < 8) {
            $response['error'] = 'La contraseña debe tener al menos 8 caracteres';
        } elseif ($programa_id <= 0) {
            $response['error'] = 'Debes seleccionar un programa';
        } else {
            try {
                // Verificar si el email ya existe
                $query_verificar = "SELECT id FROM docente WHERE email = :email";
                $stmt_verificar = $db->prepare($query_verificar);
                $stmt_verificar->bindParam(':email', $email);
                $stmt_verificar->execute();

                if ($stmt_verificar->rowCount() > 0) {
                    $response['error'] = 'El email ya está registrado';
                } else {
                    // Crear nuevo usuario
                    $password_hash = password_hash($password, PASSWORD_DEFAULT);

                    $query_insertar = "INSERT INTO docente (nombre, email, identificacion, password, programa_id) VALUES (:nombre, :email, :identificacion, :password, :programa_id)";
                    $stmt_insertar = $db->prepare($query_insertar);
                    $stmt_insertar->bindParam(':nombre', $nombre);
                    $stmt_insertar->bindParam(':email', $email);
                    $stmt_insertar->bindParam(':identificacion', $identificacion);
                    $stmt_insertar->bindParam(':password', $password_hash);
                    $stmt_insertar->bindParam(':programa_id', $programa_id);

                    if ($stmt_insertar->execute()) {
                        $response['success'] = true;
                        $response['message'] = 'Usuario registrado exitosamente';
                        file_put_contents('../controller_debug.log', "Usuario registrado con éxito\n", FILE_APPEND);
                    } else {
                        $response['error'] = 'Error al registrar el usuario';
                        file_put_contents('../controller_debug.log', "Error al insertar usuario\n", FILE_APPEND);
                    }
                }
            } catch (PDOException $e) {
                $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
                file_put_contents('../controller_debug.log', "Error de BD: " . $e->getMessage() . "\n", FILE_APPEND);
            }
        }
    } else if ($_SERVER['REQUEST_METHOD'] == 'GET') {
        // Devolver la lista de programas para el formulario de registro
        $response['success'] = true;
        $response['programas'] = $programas;
        file_put_contents('../controller_debug.log', "Devolviendo lista de programas: " . count($programas) . " encontrados\n", FILE_APPEND);
    }

    // Devolver respuesta como JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    
} catch (Exception $e) {
    // Capturar cualquier excepción no manejada
    $error_message = "Error no controlado: " . $e->getMessage() . "\n" . $e->getTraceAsString();
    error_log($error_message);
    file_put_contents('../controller_debug.log', $error_message, FILE_APPEND);
    
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Error interno del servidor']);
} 