<?php
// Asegurar que no se envíen errores PHP al navegador
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Iniciar sesión antes de cualquier salida
session_start();

// Configuración de CORS
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

// Si es una solicitud OPTIONS (preflight), terminar aquí
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// Incluir dependencias
require_once __DIR__ . '/api/api.php';
require_once __DIR__ . '/model/conection.php';

try {
    // Para solicitudes API JSON
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $jsonData = handle_json_request();
        
        if ($jsonData && isset($jsonData['action']) && $jsonData['action'] === 'getProgramas') {
            $db = Conection::conectar();
            
            // Obtener programas con puntaje máximo
            $query_programas = "SELECT p.id, p.nombre, n.nombre as nivel_nombre, n.puntaje_maximo as nivel_puntaje_maximo, cam.nombre as campus_nombre
                            FROM programa p 
                            JOIN nivel n ON p.id_nivel = n.id 
                            JOIN campus cam ON p.id_campus = cam.id";
            $stmt_programas = $db->prepare($query_programas);
            $stmt_programas->execute();
            $programas = $stmt_programas->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'programas' => $programas]);
            exit;
        }
    }
    
    // Si no es una solicitud válida, devolver error
    echo json_encode(['success' => false, 'error' => 'Solicitud no válida']);
    exit;
    
} catch (Exception $e) {
    // Log del error para debugging
    error_log("Error en crearCuestionario_controller.php: " . $e->getMessage());
    
    // Devolver respuesta de error
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor',
        'debug_message' => $e->getMessage()
    ]);
    exit;
}
?>