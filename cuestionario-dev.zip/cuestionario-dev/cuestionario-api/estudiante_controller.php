<?php
// Prevenir cualquier salida antes de los headers
ob_start();

// Para depuración
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Incluir configuración CORS antes de cualquier salida
require_once 'api/cors.php';

// Iniciar sesión
session_start();

// Función para enviar respuesta JSON
function sendJsonResponse($data, $statusCode = 200) {
    if (ob_get_length()) ob_clean();
    if (!headers_sent()) {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode($data);
    exit();
}

// Verificar la sesión o el parámetro usuario_id
$usuario_id = isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : null;

// Si no hay sesión, intentar obtener el usuario del parámetro
if (!$usuario_id && isset($_GET['usuario_id'])) {
    $usuario_id = $_GET['usuario_id'];
}

// Para desarrollo, si aún no hay usuario_id, usar un ID por defecto
if (!$usuario_id) {
    $usuario_id = 3; // ID de usuario para desarrollo
}

// Manejo de errores PHP
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    if (error_reporting() === 0) {
        return false;
    }
    sendJsonResponse([
        'error' => 'Error interno del servidor',
        'debug' => $errstr
    ], 500);
    return true;
});

try {
    require_once 'model/conection.php';

    // Crear conexión a la base de datos usando la clase existente
    $conn = Conection::conectar();

    // Consultar información del usuario
    $sql_usuario = "SELECT id, nombre, email, programa_id FROM docente WHERE id = :usuario_id";
    $stmt_usuario = $conn->prepare($sql_usuario);
    $stmt_usuario->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
    $stmt_usuario->execute();
    $usuario = $stmt_usuario->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        sendJsonResponse(['error' => 'Usuario no encontrado'], 404);
    }

    // Verificar si la variable de sesión usuario_programa existe
    $programa_docente = $usuario['programa_id'] ?? null;
    $es_admin = isset($usuario['email']) && $usuario['email'] === 'admin';

    // Manejar la adición de estudiantes (POST)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar_estudiante'])) {
        // Validar datos requeridos
        if (empty($_POST['nombre']) || empty($_POST['email']) || empty($_POST['identificacion']) || empty($_POST['programa_id'])) {
            sendJsonResponse([
                'success' => false,
                'mensaje' => 'Todos los campos son obligatorios'
            ], 400);
        }

        $nombre = trim($_POST['nombre']);
        $email = trim($_POST['email']);
        $identificacion = trim($_POST['identificacion']);
        $programa_id = (int)$_POST['programa_id'];

        // Verificar si el docente tiene permiso para agregar estudiantes a este programa
        if (!$es_admin && $programa_docente !== null && $programa_id != $programa_docente) {
            sendJsonResponse([
                'success' => false,
                'mensaje' => 'No tiene permisos para agregar estudiantes a este programa'
            ], 403);
        }

        // Verificar si el email o la identificación ya existen
        $check_sql = "SELECT COUNT(*) FROM estudiante WHERE email = :email OR identificacion = :identificacion";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bindParam(':email', $email);
        $check_stmt->bindParam(':identificacion', $identificacion);
        $check_stmt->execute();

        if ($check_stmt->fetchColumn() > 0) {
            sendJsonResponse([
                'success' => false,
                'mensaje' => 'Ya existe un estudiante con este email o identificación'
            ], 409);
        }

        // Insertar el nuevo estudiante
        $insert_sql = "INSERT INTO estudiante (nombre, email, identificacion, id_programa) VALUES (:nombre, :email, :identificacion, :programa_id)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bindParam(':nombre', $nombre);
        $insert_stmt->bindParam(':email', $email);
        $insert_stmt->bindParam(':identificacion', $identificacion);
        $insert_stmt->bindParam(':programa_id', $programa_id);
        $insert_stmt->execute();

        if ($insert_stmt->rowCount() > 0) {
            sendJsonResponse([
                'success' => true,
                'mensaje' => 'Estudiante agregado correctamente',
                'estudiante_id' => $conn->lastInsertId()
            ]);
        } else {
            sendJsonResponse([
                'success' => false,
                'mensaje' => 'No se pudo agregar el estudiante'
            ]);
        }
    }

    // Manejar la eliminación de estudiantes
    if (isset($_GET['eliminar']) && is_numeric($_GET['eliminar'])) {
        $id_estudiante = (int)$_GET['eliminar'];
        
        // Verificar si el estudiante existe y pertenece al programa del docente (si no es admin)
        if (!$es_admin && $programa_docente !== null) {
            $check_sql = "SELECT COUNT(*) FROM estudiante WHERE id = :id AND id_programa = :programa_id";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bindParam(':id', $id_estudiante, PDO::PARAM_INT);
            $check_stmt->bindParam(':programa_id', $programa_docente, PDO::PARAM_INT);
            $check_stmt->execute();
            
            if ($check_stmt->fetchColumn() == 0) {
                sendJsonResponse([
                    'success' => false,
                    'mensaje' => 'No tiene permisos para eliminar este estudiante o no existe'
                ], 403);
            }
        }
        
        // Eliminar el estudiante
        $delete_sql = "DELETE FROM estudiante WHERE id = :id";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bindParam(':id', $id_estudiante, PDO::PARAM_INT);
        $delete_stmt->execute();
        
        if ($delete_stmt->rowCount() > 0) {
            sendJsonResponse([
                'success' => true,
                'mensaje' => 'Estudiante eliminado correctamente'
            ]);
        } else {
            sendJsonResponse([
                'success' => false,
                'mensaje' => 'No se pudo eliminar el estudiante o no existe'
            ]);
        }
    }

    // Obtener estudiantes
    if ($es_admin || $programa_docente === null) {
        $sql_estudiantes = "SELECT e.id, e.nombre, e.email, e.identificacion, p.nombre as programa_nombre
                          FROM estudiante e
                          JOIN programa p ON e.id_programa = p.id
                          ORDER BY e.nombre";
        $stmt = $conn->prepare($sql_estudiantes);
    } else {
        $sql_estudiantes = "SELECT e.id, e.nombre, e.email, e.identificacion, p.nombre as programa_nombre
                          FROM estudiante e
                          JOIN programa p ON e.id_programa = p.id
                          WHERE e.id_programa = :programa_id
                          ORDER BY e.nombre";
        $stmt = $conn->prepare($sql_estudiantes);
        $stmt->bindParam(':programa_id', $programa_docente, PDO::PARAM_INT);
    }

    $stmt->execute();
    $estudiantes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obtener programas
    $sql_programas = "SELECT id, nombre FROM programa ORDER BY nombre";
    $stmt = $conn->prepare($sql_programas);
    $stmt->execute();
    $programas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Enviar respuesta exitosa
    sendJsonResponse([
        'success' => true,
        'estudiantes' => $estudiantes,
        'programas' => $programas
    ]);

} catch (PDOException $e) {
    sendJsonResponse([
        'error' => 'Error de base de datos',
        'debug' => $e->getMessage()
    ], 500);
} catch (Exception $e) {
    sendJsonResponse([
        'error' => 'Error del servidor',
        'debug' => $e->getMessage()
    ], 500);
}

// Restaurar el manejador de errores y limpiar cualquier salida pendiente
restore_error_handler();
if (ob_get_length()) ob_end_clean();
