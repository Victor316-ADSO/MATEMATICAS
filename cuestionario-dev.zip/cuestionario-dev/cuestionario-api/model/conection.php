<?php
class Conection {
    private $host = 'localhost';
    private $db_name = 'testv2';
    private $username = 'root'; 
    private $password = '';
    private $conn;
    
    public static function conectar() {
        $instance = new self();
        return $instance->connect();
    }

    private function connect() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password,
                array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return $this->conn;
        } catch(PDOException $e) {
            throw new PDOException("Error de conexión: " . $e->getMessage());
        }
    }
}