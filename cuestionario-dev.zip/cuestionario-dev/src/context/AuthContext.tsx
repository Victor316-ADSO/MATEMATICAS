import { createContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import Swal from 'sweetalert2';
import { API_ENDPOINTS, fetchApi } from '../config/api';

interface User {
  id: number;
  nombre: string;
  email: string;
  rol: string;
}

interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string, redirectUrl?: string) => Promise<void>;
  logout: () => Promise<void>;
  register: (userData: { nombre: string; email: string; password: string }) => Promise<void>;
  checkSession: () => Promise<void>;
}

export const AuthContext = createContext<AuthState | null>(null);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Función para verificar sesión
  const checkSession = async () => {
    try {
      console.log('🔍 Verificando sesión...');
      const data = await fetchApi(API_ENDPOINTS.verificarSesion);
      console.log('📄 Respuesta de verificar sesión:', data);
      
      if (data && data.success && data.autenticado) {
        console.log('✅ Sesión válida, usuario:', data.usuario);
        setUser(data.usuario);
        setIsAuthenticated(true);
      } else {
        console.log('❌ Sesión inválida o no autenticado');
        setUser(null);
        setIsAuthenticated(false);
      }
    } catch (error) {
      console.error('💥 Error al verificar sesión:', error);
      setUser(null);
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkSession();
    
    // Verificar sesión cada 5 minutos
    const intervalId = setInterval(() => {
      checkSession();
    }, 5 * 60 * 1000);
    
    return () => clearInterval(intervalId);
  }, []);

  const login = async (email: string, password: string, redirectUrl?: string) => {
    try {
      const data = await fetchApi(API_ENDPOINTS.login, {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });

      if (data && data.success) {
        setUser(data.usuario);
        setIsAuthenticated(true);
        
        // Si hay una URL de redirección específica, usarla
        if (redirectUrl) {
          window.location.href = redirectUrl;
          return;
        }
        
        // Si no hay redirección específica, usar la redirección por defecto según el rol
        if (data.usuario.rol === 'estudiante') {
          // Obtener el ID del cuestionario de la URL actual
          const urlParams = new URLSearchParams(window.location.search);
          const cuestionarioId = urlParams.get('id');
          
          if (cuestionarioId) {
            // Si hay un ID de cuestionario, redirigir a realizar-cuestionario
            window.location.href = `/realizar-cuestionario/${cuestionarioId}`;
          } else {
            // Si no hay ID, redirigir al dashboard del estudiante
            window.location.href = '/dashboard';
          }
          return;
        }
        // Los profesores van al dashboard
        window.location.href = '/principal';
      } else {
        // Verificar si hay una respuesta HTML en lugar de JSON
        if (data.rawResponse) {
          console.error('El servidor devolvió HTML en lugar de JSON:', data.rawResponse);
          
          Swal.fire({
            icon: 'error',
            title: 'Error del servidor',
            html: `El servidor devolvió un formato inválido:<br><pre style="text-align:left;max-height:300px;overflow:auto">${data.rawResponse.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>`,
            width: '80%'
          });
          
          throw new Error('Error del servidor: formato de respuesta inválido');
        } else {
          // Error normal con mensaje
          const errorMsg = data?.error || data?.message || 'Error en el inicio de sesión';
          console.error('Error de login:', errorMsg);
          
          Swal.fire({
            icon: 'error',
            title: 'Error de inicio de sesión',
            text: errorMsg
          });
          
          throw new Error(errorMsg);
        }
      }
    } catch (error) {
      console.error('Error completo:', error);
      
      Swal.fire({
        icon: 'error',
        title: 'Error de conexión',
        text: 'No se pudo conectar con el servidor. Por favor, inténtelo de nuevo más tarde.'
      });
      
      throw error;
    }
  };

  const logout = async () => {
    try {
      await fetchApi(API_ENDPOINTS.logout, {
        method: 'POST'
      });
    } catch (error) {
      console.error('Error al cerrar sesión:', error);
    } finally {
      setUser(null);
      setIsAuthenticated(false);
      // Redirigir a login después de cerrar sesión
      window.location.href = '/login';
    }
  };

  const register = async (userData: { nombre: string; email: string; password: string }) => {
    try {
      const data = await fetchApi(API_ENDPOINTS.registro, {
        method: 'POST',
        body: JSON.stringify(userData)
      });

      if (!data || !data.success) {
        throw new Error(data?.message || 'Error en el registro');
      }

      await login(userData.email, userData.password);
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error instanceof Error ? error.message : 'Error en el registro'
      });
      throw error;
    }
  };

  const value: AuthState = {
    isAuthenticated,
    user,
    isLoading,
    login,
    logout,
    register,
    checkSession
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}; 