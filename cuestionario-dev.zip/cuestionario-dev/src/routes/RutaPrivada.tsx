import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import useAuth from '../hooks/useAuth';

const LoadingSpinner = () => (
  <div style={{
    minHeight: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f9fa'
  }}>
    <div style={{
      width: '50px',
      height: '50px',
      border: '3px solid #f3f3f3',
      borderTop: '3px solid #e67e22',
      borderRadius: '50%',
      animation: 'spin 1s linear infinite'
    }} />
    <style>
      {`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}
    </style>
  </div>
);

const RutaPrivada = () => {
  const { isAuthenticated, isLoading, user, checkSession } = useAuth();
  const location = useLocation();

  // Eliminado useEffect problemático que causaba loop de redirección



  if (isLoading) {
    return <LoadingSpinner />;
  }

  // Si no está autenticado, redirigir a login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Si es estudiante, no permitir acceso a rutas privadas de docente
  if (user?.rol === 'estudiante') {
    return <Navigate to="/linksystem" replace />;
  }

  // Si es docente, permitir acceso a rutas privadas
  if (user?.rol === 'docente') {
    return <Outlet />;
  }

  // Si el rol no está definido o es desconocido, redirigir a login
  return <Navigate to="/login" replace />;
};

export default RutaPrivada;
