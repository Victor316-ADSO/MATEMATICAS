/**
 * FormActions - Componente para los botones de acción del formulario
 * 
 * Propósito:
 * - Contiene los botones principales de acción (Guardar, Cancelar)
 * - Maneja el estado habilitado/deshabilitado según validaciones
 * - Proporciona feedback visual sobre el estado del formulario
 * - Incluye navegación de cancelar hacia el dashboard
 * 
 * Beneficios:
 * - Separación clara de la lógica de acciones del formulario
 * - Reutilizable en otros formularios que necesiten acciones similares
 * - Validación visual integrada
 * - Consistencia en botones de acción
 */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import styles from '../CrearCuestionario.module.css';

interface FormActionsProps {
  puntajeTotal: number;
  puntajeMaximo: number;
  onSubmit: (e: React.FormEvent) => void;
}

const FormActions: React.FC<FormActionsProps> = ({
  puntajeTotal,
  puntajeMaximo,
  onSubmit
}) => {
  const navigate = useNavigate();
  
  const isDisabled = puntajeTotal !== puntajeMaximo;
  
  const getTooltipText = () => {
    if (puntajeTotal !== puntajeMaximo) {
      if (puntajeTotal > puntajeMaximo) {
        return `Puntaje excedido: ${puntajeTotal % 1 === 0 ? puntajeTotal.toFixed(0) : puntajeTotal.toFixed(1)}/${puntajeMaximo}`;
      } else {
        return `Puntaje insuficiente: ${puntajeTotal % 1 === 0 ? puntajeTotal.toFixed(0) : puntajeTotal.toFixed(1)}/${puntajeMaximo}`;
      }
    }
    return 'Puntaje correcto - Listo para crear';
  };

  return (
    <div className={styles.formActions}>
      <button 
        type="submit" 
        className={`${styles.btnSubmit} ${isDisabled ? styles.btnDisabled : ''}`}
        disabled={isDisabled}
        onClick={(e) => {
          e.preventDefault();
          console.log('Botón submit clickeado');
          onSubmit(e);
        }}
        title={getTooltipText()}
      >
        <i className="fas fa-save"></i> Guardar Cuestionario
      </button>
      <button
        type="button"
        onClick={() => navigate('/dashboard')}
        className={styles.btnCancel}
      >
        <i className="fas fa-times"></i> Cancelar
      </button>
    </div>
  );
};

export default FormActions; 