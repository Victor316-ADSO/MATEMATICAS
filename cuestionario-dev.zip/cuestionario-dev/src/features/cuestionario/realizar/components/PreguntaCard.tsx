/**
 * PreguntaCard - Componente para mostrar una pregunta individual
 *
 * Propósito:
 * - Renderiza el texto, imagen y opciones de una pregunta
 * - Permite seleccionar una opción
 *
 * Beneficios:
 * - Reutilizable para cualquier cuestionario
 * - Separación clara de la lógica de pregunta
 * - Fácil de testear y mantener
 */

import React from 'react';
import styles from '../RealizarCuestionario.module.css';
import type { Pregunta, RespuestasUsuario } from '../types';

interface PreguntaCardProps {
  pregunta: Pregunta;
  respuestaSeleccionada: number | undefined;
  onChange: (preguntaId: number, opcionId: number) => void;
  getImageUrl: (tipo: 'pregunta' | 'opcion', id: number) => string;
}

const PreguntaCard: React.FC<PreguntaCardProps> = ({
  pregunta,
  respuestaSeleccionada,
  onChange,
  getImageUrl
}) => (
  <div className={styles.preguntaCard}>
    <div className={styles.preguntaHeader}>
      <h3>{pregunta.texto_pregunta}</h3>
      <span className={styles.peso}>Peso: {pregunta.peso_pregunta}</span>
    </div>
    <div className={styles.preguntaContenido}>
      {pregunta.imagen_pregunta && (
        <div className={styles.imagenContainer}>
          <img
            src={getImageUrl('pregunta', pregunta.id)}
            alt={`Imagen de la pregunta`}
            className={styles.imagen}
          />
        </div>
      )}
      <div className={styles.opcionesContainer}>
        {pregunta.opciones.map((opcion, oIndex) => (
          <div
            key={opcion.id}
            className={`${styles.opcionItem} ${respuestaSeleccionada === opcion.id ? styles.opcionSeleccionada : ''}`}
          >
            <label className={styles.opcionLabel}>
              <input
                type="radio"
                name={`pregunta-${pregunta.id}`}
                value={opcion.id}
                checked={respuestaSeleccionada === opcion.id}
                onChange={() => onChange(pregunta.id, opcion.id)}
                className={styles.radioInput}
              />
              <div className={styles.opcionTexto}>
                <span className={styles.opcionLetra}>{String.fromCharCode(65 + oIndex)}</span>
                <p>{opcion.texto_opcion}</p>
              </div>
              {opcion.imagen_opcion && (
                <div className={styles.imagenOpcionContainer}>
                  <img
                    src={getImageUrl('opcion', opcion.id)}
                    alt={`Imagen de la opción ${String.fromCharCode(65 + oIndex)}`}
                    className={styles.imagenOpcion}
                  />
                </div>
              )}
            </label>
          </div>
        ))}
      </div>
    </div>
  </div>
);

export default PreguntaCard; 