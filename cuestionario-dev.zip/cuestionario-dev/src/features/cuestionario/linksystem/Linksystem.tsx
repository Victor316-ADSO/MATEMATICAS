import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import styles from './Linksystem.module.css';
import PageTransition from '../../../components/PageTransition';
import useAuth from '../../../hooks/useAuth';

const Linksystem = () => {
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState('');
  const [documento, setDocumento] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const cuestionarioId = searchParams.get('id');
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();

  useEffect(() => {
    // Si hay ID pero no está autenticado, limpiar errores para mostrar formulario
    if (cuestionarioId && !isAuthenticated) {
      setError(null);
      return;
    }

    // Si es estudiante autenticado sin ID, mostrar mensaje informativo
    if (isAuthenticated && user?.rol === 'estudiante' && !cuestionarioId) {
      setError('Necesitas un enlace válido para acceder al cuestionario');
      return;
    }
  }, [cuestionarioId, isAuthenticated, user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      // Intentar login directo como estudiante
      const loginResponse = await fetch('http://localhost/cuestionario-api/api/linksystem_api.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          email,
          documento,
          id: cuestionarioId
        })
      });

      const loginData = await loginResponse.json();

      if (!loginData.success) {
        throw new Error(loginData.error || 'Error al iniciar sesión');
      }

      // Si el login fue exitoso, mostrar mensaje y redirigir
      await Swal.fire({
        icon: 'success',
        title: '¡Acceso concedido!',
        text: `Bienvenido(a) ${loginData.estudiante.nombre}`,
        timer: 1500,
        showConfirmButton: false
      });

      // Redirigir al cuestionario
      navigate(`/realizar-cuestionario/${cuestionarioId}`);

    } catch (error) {
      console.error('Error:', error);
      setError('Error al conectar con el servidor');
      Swal.fire({
        icon: 'error',
        title: 'Error de conexión',
        text: error instanceof Error ? error.message : 'No se pudo conectar con el servidor. Por favor, intenta de nuevo.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Si es estudiante autenticado sin ID válido
  if (isAuthenticated && user?.rol === 'estudiante' && !cuestionarioId) {
    return (
      <PageTransition>
        <div className={styles.principalRoot}>
          <div className={styles.mainAnimatedContainer}>
            <div className={styles.principalHeader}>
              <h1>Enlace de Cuestionario Requerido</h1>
              <h2>Hola {user.nombre || user.email}</h2>
              <p className={styles.helpText}>
                Para acceder a un cuestionario, necesitas usar el enlace específico que te fue enviado por tu docente.
                <br />
                <br />
                Si no tienes el enlace, contacta a tu docente para que te lo proporcione nuevamente.
              </p>
            </div>
          </div>
        </div>
      </PageTransition>
    );
  }

  if (error && !cuestionarioId) {
    return (
      <PageTransition>
        <div className={styles.principalRoot}>
          <div className={styles.mainAnimatedContainer}>
            <div className={styles.principalHeader}>
              <h1>Link Inválido</h1>
              <h2>{error}</h2>
              <p className={styles.helpText}>
                Si recibiste este link por correo, por favor verifica que la URL esté completa o contacta a tu docente.
              </p>
            </div>
          </div>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div className={styles.principalRoot}>
        <div className={styles.mainAnimatedContainer}>
          <div className={styles.principalHeader}>
            <h1>Acceso Estudiantes</h1>
            <h2>Ingresa tus datos para realizar el cuestionario</h2>
            <p className={styles.helpText}>
              Solo estudiantes asignados podrán acceder al cuestionario.
              <br />
              Usa el correo y documento con el que estás registrado.
            </p>
          </div>

          <div className={styles.contentCard}>
            <div className={styles.formSection}>
              <form onSubmit={handleSubmit} className={styles.form}>
                <div className={styles.formGroup}>
                  <label htmlFor="email">Correo Electrónico Institucional</label>
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className={styles.formControl}
                    placeholder="ejemplo@email.com"
                  />
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="documento">Documento de Identidad</label>
                  <input
                    type="text"
                    id="documento"
                    value={documento}
                    onChange={(e) => setDocumento(e.target.value)}
                    required
                    className={styles.formControl}
                    placeholder="Ingresa tu número de documento"
                  />
                </div>

                {error && (
                  <div className={styles.errorMessage}>
                    <i className="fas fa-exclamation-circle"></i> {error}
                  </div>
                )}

                <div className={styles.formActions}>
                  <button 
                    type="submit" 
                    className={styles.submitButton}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <i className="fas fa-spinner fa-spin"></i> Validando...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-sign-in-alt"></i> Ingresar al Cuestionario
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default Linksystem; 