import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { navigateWithLoading } from '../../utils/navigation';
import './login.css';
import { API_ENDPOINTS } from '../../config/api';
import useAuth from '../../hooks/useAuth';

// Interfaces para tipado
interface LoginData {
  email: string;
  password: string;
}

const Login: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const cuestionarioId = searchParams.get('id');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { login, isAuthenticated, checkSession } = useAuth();

  // Verificar si ya está autenticado
  useEffect(() => {
    const verificarAutenticacion = async () => {
      await checkSession();
      
      if (isAuthenticated) {
        if (cuestionarioId) {
          navigate(`/realizar-cuestionario/${cuestionarioId}`);
        } else {
          navigate('/principal');
        }
      }
    };
    
    verificarAutenticacion();
  }, [isAuthenticated, cuestionarioId, navigate, checkSession]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    setIsLoading(true);

    try {
      console.log('Intentando iniciar sesión con:', { email });
      
      // Usar el método login del contexto de autenticación
      await login(email, password, cuestionarioId ? `/realizar-cuestionario/${cuestionarioId}` : undefined);
      
      // Si llegamos aquí y no hay cuestionarioId, mostrar mensaje de éxito
      if (!cuestionarioId) {
        await Swal.fire({
        icon: 'success',
        title: '¡Bienvenido!',
        text: 'Inicio de sesión exitoso',
        timer: 2000,
        showConfirmButton: false,
      });
      navigateWithLoading('/principal', 2000);
      }
    } catch (err) {
      console.error('Error completo durante login:', err);
      setIsLoading(false);
    }
  };

  // Método alternativo directo (por si hay problemas con el contexto)
  const handleDirectLogin = async () => {
    setIsLoading(true);
    
    try {
      console.log('Intentando login directo con:', { email });
      
      const response = await fetch(API_ENDPOINTS.login, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ email, password })
      });
      
      console.log('Respuesta del servidor:', response);
      
      // Obtener el texto de la respuesta para diagnóstico
      const responseText = await response.text();
      console.log('Texto de respuesta completo:', responseText);
      
      // Intentar parsear como JSON si es posible
      try {
        const data = JSON.parse(responseText);
        console.log('Datos de respuesta JSON:', data);
        
        if (data && data.success) {
          // Actualizar el contexto de autenticación
          await checkSession();
          
          if (cuestionarioId) {
            window.location.href = `/realizar-cuestionario/${cuestionarioId}`;
          } else {
            await Swal.fire({
            icon: 'success',
            title: '¡Bienvenido!',
            text: `Inicio de sesión exitoso`,
            timer: 2000,
            showConfirmButton: false,
          });
          navigateWithLoading('/principal', 2000);
          }
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: data.error || 'Credenciales incorrectas',
          });
        }
      } catch (parseError) {
        console.error('Error al parsear JSON:', parseError);
        
        // Mostrar el HTML de error para diagnóstico
        Swal.fire({
          icon: 'error',
          title: 'Error del servidor',
          html: `El servidor devolvió un formato inválido:<br><pre style="text-align:left;max-height:300px;overflow:auto">${responseText.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>`,
          width: '80%'
        });
      }
    } catch (err) {
      console.error('Error completo durante login directo:', err);
      
      Swal.fire({
        icon: 'error',
        title: 'Error de conexión',
        text: 'No se pudo conectar al servidor. Por favor, intente de nuevo más tarde.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="principalRoot">
      <div className="mainAnimatedContainer">
        <main className="principalContent">
          <section className="principalContentArea">
            <div className="contentCard">
              <div className="sidebarCardHeader">
                <h3>Iniciar Sesión</h3>
              </div>
              <div className="sidebarCardBody">
                <form className="loginForm" onSubmit={handleSubmit}>
                  <div className="formGroup">
                    <label className="formLabel">Correo electrónico</label>
                    <input
                      type="email"
                      className="formControl"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      disabled={isLoading}
                    />
                  </div>
                  <div className="formGroup">
                    <label className="formLabel">Contraseña</label>
                    <input
                      type="password"
                      className="formControl"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      disabled={isLoading}
                    />
                  </div>
                  <button type="submit" className="crearBtn submitBtn" disabled={isLoading}>
                    {isLoading ? 'Iniciando sesión...' : 'Iniciar sesión'}
                  </button>
                  
                  <div style={{ marginTop: '10px', textAlign: 'center' }}>
                    <button 
                      type="button" 
                      className="linkBtn" 
                      onClick={handleDirectLogin}
                      disabled={isLoading}
                      style={{
                        background: 'none',
                        border: 'none',
                        color: '#0056b3',
                        textDecoration: 'underline',
                        cursor: 'pointer',
                        padding: '5px'
                      }}
                    >
                      ¿Problemas para iniciar sesión? Intenta este método alternativo
                    </button>
                  </div>
                </form>
                <div className="linkContainer">
                  <p>
                    ¿No tienes cuenta?{' '}
                    <a href="/registro" className="linkText">
                      Regístrate aquí
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
};

export default Login;