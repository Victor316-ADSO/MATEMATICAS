// Configuración de la API
export const API_BASE_URL = 'http://localhost/cuestionario-api';

// Función para realizar peticiones a la API
export const fetchApi = async (url: string, options: RequestInit = {}) => {
  try {
    // Configuración por defecto para todas las solicitudes
    const defaultOptions: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      credentials: 'include',  // Enviar cookies en solicitudes cross-origin
      mode: 'cors',           // Asegurar que se use CORS
    };

    // Combinar opciones
    const fetchOptions: RequestInit = {
      ...defaultOptions,
      ...options,
      headers: {
        ...defaultOptions.headers,
        ...(options.headers || {})
      }
    };

    const response = await fetch(url, fetchOptions);

    // Manejar respuestas según el código de estado
    if (!response.ok) {
      if (response.status === 401) {
        // Manejar específicamente los errores de autenticación
        return { success: false, error: 'Sesión no iniciada o expirada' };
      }
    }
    
    // Obtener el texto de la respuesta
    const responseText = await response.text();
    
    // Intentar parsear como JSON
    try {
      const data = JSON.parse(responseText);
      return data;
    } catch (parseError) {
      console.error('Error al parsear respuesta como JSON:', parseError);
      console.error('Contenido de la respuesta:', responseText);
      
      // Devolver un objeto de error con el texto de la respuesta
      return {
        success: false,
        error: 'Error al parsear respuesta del servidor',
        rawResponse: responseText
      };
    }
  } catch (error) {
    console.error('Error en fetchApi:', error);
    throw error;
  }
};

// URLs específicas
export const API_ENDPOINTS = {
  login: `${API_BASE_URL}/login_controller.php`,
  logout: `${API_BASE_URL}/logout_controller.php`,
  registro: `${API_BASE_URL}/registro_controller.php`,
  principal: `${API_BASE_URL}/principal_controller.php`,
  verCuestionario: (id: string) => `${API_BASE_URL}/ver_controller.php?id=${id}`,
  crearCuestionario: `${API_BASE_URL}/crearCuestionario_controller.php`,
  crearCuestionarioApi: `${API_BASE_URL}/api/crearCuestionario_api.php`,
  realizarCuestionario: (id: string) => `${API_BASE_URL}/api/resolver_api.php?id=${id}`,
  cuestionariosDisponibles: `${API_BASE_URL}/api/resolver_api.php`,
  resultadoCuestionario: (id: string) => `${API_BASE_URL}/resultado_controller.php?id=${id}`,
  resultado: (id: string) => `${API_BASE_URL}/api/resultado_api.php?id=${id}`,
  periodos: `${API_BASE_URL}/periodoManage_controller.php`,
  verificarSesion: `${API_BASE_URL}/api/verificar_sesion.php`,
  estudiantes: `${API_BASE_URL}/estudiante_controller.php`,
  seguimiento: {
    lista: `${API_BASE_URL}/api/seguimiento_lista_api.php`,
    detalle: (id: string) => `${API_BASE_URL}/api/seguimiento_detalle_api.php?id=${id}`
  }
}; 