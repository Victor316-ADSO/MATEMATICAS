import { Link, useLocation } from 'react-router-dom';
import styles from './Sidebar.module.css';
import { 
  FaBook, 
  FaClipboardList, 
  FaChartLine,
  FaHome,
  FaCalendarAlt
} from 'react-icons/fa';

const Sidebar = () => {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname.startsWith(path) ? styles.active : '';
  };

  return (
    <div className={styles.sidebar}>
      <div className={styles.logo}>
        <FaBook className={styles.logoIcon} />
        <span>Quiz System</span>
      </div>

      <nav className={styles.nav}>
        <div className={styles.section}>
          <h3 className={styles.sectionTitle}>Principal</h3>
          <Link to="/dashboard" className={`${styles.link} ${isActive('/dashboard')}`}>
            <FaHome />
            <span>Cuestionarios</span>
          </Link>
        </div>

        <div className={styles.section}>
          <h3 className={styles.sectionTitle}>Gestión</h3>
          <Link to="/asignar" className={`${styles.link} ${isActive('/asignar')}`}>
            <FaClipboardList />
            <span>Asignar Cuestionario</span>
          </Link>
          <Link to="/periodos" className={`${styles.link} ${isActive('/periodos')}`}>
            <FaCalendarAlt />
            <span>Periodos</span>
          </Link>
        </div>

        <div className={styles.section}>
          <h3 className={styles.sectionTitle}>Análisis</h3>
          <Link to="/seguimiento" className={`${styles.link} ${isActive('/seguimiento')}`}>
            <FaChartLine />
            <span>Seguimiento</span>
          </Link>
        </div>
      </nav>
    </div>
  );
};

export default Sidebar; 