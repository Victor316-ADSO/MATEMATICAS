import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';

// Autenticación
import Login from './features/auth/Login';
import Registro from './features/auth/Registro';
import RutaPrivada from './routes/RutaPrivada';
import RutaPublica from './routes/RutaPublica';

// Layout
import DashboardLayout from './components/Layout/DashboardLayout';

// Dashboard
import Principal from './features/dashboard/Principal';

// Cuestionarios
import VerCuestionario from './features/cuestionario/ver/VerCuestionario';
import RealizarCuestionario from './features/cuestionario/realizar/RealizarCuestionario';
import CrearCuestionario from './features/cuestionario/crear/CrearCuestionario';
import Linksystem from './features/cuestionario/linksystem/Linksystem';

// Gestión
import PeriodoManage from './features/admin/periodos/PeriodoManage';
import Asignacion from './features/cuestionario/asignacion/Asignacion';
import Estudiantes from './features/cuestionario/estudiantes/Estudiantes';
import Apertura from './features/cuestionario/apertura/Apertura';

// Análisis y Seguimiento
import Seguimiento from './features/cuestionario/seguimiento/Seguimiento';
import SeguimientoDetalle from './features/cuestionario/detalles/SeguimientoDetalle';
import Resultado from './features/cuestionario/resultado/Resultado';
import VerRespuesta from './features/cuestionario/VerRespuesta/VerRespuesta';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Rutas Públicas */}
          <Route element={<RutaPublica />}>
            <Route path="/login" element={<Login />} />
            <Route path="/registro" element={<Registro />} />
          </Route>

          {/* Linksystem - Accesible para todos */}
          <Route path="/linksystem" element={<Linksystem />} />

          {/* Rutas de Cuestionario para Estudiantes */}
          <Route path="/realizar-cuestionario/:id" element={<RealizarCuestionario />} />
          <Route path="/resultado/:id" element={<Resultado />} />
          
          {/* Ruta de fallback para realizar-cuestionario sin ID */}
          <Route path="/realizar-cuestionario/*" element={<Navigate to="/linksystem" replace />} />

          {/* Rutas Privadas - Solo para profesores */}
          <Route element={<RutaPrivada />}>
            <Route element={<DashboardLayout />}>
              <Route path="/principal" element={<Principal />} />
              <Route path="/dashboard" element={<Principal />} />
              <Route path="/crear-cuestionario" element={<CrearCuestionario />} />
              <Route path="/ver/:id" element={<VerCuestionario />} />
              <Route path="/asignar" element={<Asignacion />} />
              <Route path="/asignacion/:id" element={<Asignacion />} />
              <Route path="/periodos" element={<PeriodoManage />} />
              <Route path="/estudiantes" element={<Estudiantes />} />
              <Route path="/apertura" element={<Apertura />} />
              <Route path="/seguimiento" element={<Seguimiento />} />
              <Route path="/seguimiento/detalle/:id" element={<SeguimientoDetalle />} />
              <Route path="/ver-respuesta/:estudianteId/:cuestionarioId" element={<VerRespuesta />} />
            </Route>
          </Route>

          {/* Redirecciones */}
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="/realizar-cuestionario" element={<Navigate to="/linksystem" replace />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;