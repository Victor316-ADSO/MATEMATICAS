import Swal from 'sweetalert2';

/**
 * Navigate to a new route with a loading screen
 * @param url The URL to navigate to
 * @param loadingTime The time in milliseconds to show the loading screen (default: 1000ms)
 */
export const navigateWithLoading = (url: string, loadingTime: number = 1000) => {
  Swal.fire({
    title: 'Cargando...',
    html: 'Por favor espere',
    timer: loadingTime,
    timerProgressBar: true,
    didOpen: () => {
      Swal.showLoading();
    },
    allowOutsideClick: false,
    allowEscapeKey: false,
    allowEnterKey: false,
  }).then(() => {
    window.location.href = url;
  });
}; 